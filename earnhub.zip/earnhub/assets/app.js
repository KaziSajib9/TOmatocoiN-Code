const tg=window.Telegram?.WebApp;tg?.ready();tg?.expand();tg?.setHeaderColor?.('#ffffff');try{tg?.setBackgroundColor?.('#F3F5F9');tg?.setBottomBarColor?.('#ffffff');tg?.disableVerticalSwipes?.()}catch{}
const $=s=>document.querySelector(s),$$=s=>document.querySelectorAll(s),f=n=>Number(n).toLocaleString('en-US',{maximumFractionDigits:2}),
esc=s=>String(s??'').replace(/[&<>"']/g,c=>'&#'+c.charCodeAt(0)+';'),set=(i,v)=>{const e=$(i);if(e)e.textContent=v},sleep=ms=>new Promise(r=>setTimeout(r,ms)),
P={app:'<rect x="6" y="2.5" width="12" height="19" rx="3"/><path d="M12 8v6m-2.5-2.5L12 14l2.5-2.5M10.5 18.5h3"/>',globe:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3.2 3 14.8 0 18M12 3c-3 3.2-3 14.8 0 18"/>',bot:'<rect x="4" y="8" width="16" height="11" rx="3.5"/><path d="M12 4v4M9 13v1.5M15 13v1.5M2.5 13v2M21.5 13v2"/>',play:'<path d="M8 5v14l11-7z"/>',flash:'<path d="M13 2 4 14h7l-1 8 9-12h-7z"/>',gift:'<path d="M20 12v9H4v-9M2 7h20v5H2zM12 22V7M12 7H8a2.5 2.5 0 1 1 0-5c3 0 4 5 4 5zM12 7h4a2.5 2.5 0 1 0 0-5c-3 0-4 5-4 5z"/>',
link:'<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/>',channel:'<path d="M22 3 2 11l6 2 2 7 4-5 5 4z"/>',
check:'<path d="M5 12l5 5L20 7"/>',users:'<path d="M16 11a3 3 0 1 0 0-6M8 11a3 3 0 1 0 0-6M2 20a6 6 0 0 1 12 0M14 14a6 6 0 0 1 8 6"/>',
coin:'<circle cx="12" cy="12" r="9"/><path d="M12 7v10M9.5 9.5c0-1 1.1-1.7 2.5-1.7s2.5.7 2.5 1.7-1.1 1.5-2.5 2-2.5 1-2.5 2 1.1 1.7 2.5 1.7 2.5-.7 2.5-1.7"/>',
trophy:'<path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0zM17 5h3v2a3 3 0 0 1-3 3M7 5H4v2a3 3 0 0 0 3 3"/>',wallet:'<path d="M3 7h18v12H3zM3 7l3-3h12l3 3M16 13h2"/>',
star:'<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/>',medal:'<circle cx="12" cy="15" r="5"/><path d="M8.5 3h7l-2 6M8.5 3l2 6"/>'},
icon=(k,c='')=>`<span class="ic ${c}"><svg viewBox="0 0 24 24">${P[k]}</svg></span>`,
PRE=[['#059669','M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z'],['#2563EB','M13 2 4 14h7l-1 8 9-12h-7z'],['#DB2777','M12 21s-7-4.6-9.3-9A5.2 5.2 0 0 1 12 6.6 5.2 5.2 0 0 1 21.3 12C19 16.4 12 21 12 21z'],['#7C3AED','M12 3l8 6-8 12L4 9z'],
['#0891B2','M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z'],['#D97706','M3 8l4.5 4L12 5l4.5 7L21 8l-2 11H5z'],['#DC2626','M12 2c1 4 5 6 5 11a5 5 0 0 1-10 0c0-2 1-3 2-4 0 2 1 3 2 3 0-4-1-6 1-10z'],['#475569','M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z']],
TIERS=[['Bronze','#92400E','#FEF3C7'],['Silver','#475569','#E2E8F0'],['Gold','#B45309','#FDE68A'],['Diamond','#6D28D9','#EDE9FE']],
BG={starter:['Newcomer','Joined the platform','star'],early:['Early Member','One of our first members','medal'],ads10:['Viewer','Watch 10 ads','play'],ads100:['Ad Master','Watch 100 ads','flash'],tasks5:['Task Runner','Complete 5 special tasks','check'],
refs3:['Networker','Invite 3 friends','users'],earner:['High Earner','Earn 1,000 points','coin'],paid:['Cash Out','First paid withdrawal','wallet'],top10:['Top 10','Reach the top 10','trophy']},
SG=['Pending','Processing','Withdraw Verify','Paid'],SI={Pending:0,Processing:1,Verifying:2,Paid:3};
let D=null,chg=false;
const hs=t=>{let h=0;for(const c of t)h=(h*31+c.charCodeAt(0))|0;return h},dur=s=>{const h=Math.floor(s/3600),m=Math.floor(s%3600/60);return h?`${h}h ${m}m`:`${m}m`},
SH='<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/>',vbadge=ok=>`<span class="vb ${ok?'ok':'no'}"><svg viewBox="0 0 24 24">${SH}${ok?'<path d="M9 12l2 2 4-4"/>':'<path d="M12 8v4M12 16h.01"/>'}</svg>${ok?'Account Verified':'Account Not Verified'}</span>`;
function av(x,size=48){const a=x.avatar||x.av||'tg',ph=x.photo||x.ph,nm=esc(String(x.name||x.n||'?')[0].toUpperCase());let inner;
 if(a.startsWith('u:'))inner=`<img src="uploads/avatars/${esc(a.slice(2))}.jpg" alt="">`;
 else if(a[0]==='p'&&PRE[a.slice(1)-1]){const p=PRE[a.slice(1)-1];inner=`<svg viewBox="0 0 48 48"><rect width="48" height="48" fill="${p[0]}"/><path transform="translate(12 12)" fill="#fff" d="${p[1]}"/></svg>`}
 else inner=`<b>${nm}</b>${ph?`<img src="${esc(ph)}" alt="" referrerpolicy="no-referrer" onerror="this.remove()">`:''}`;
 return `<span class="av" style="width:${size}px;height:${size}px;font-size:${size*.4}px">${inner}</span>`}
const tier=l=>TIERS[Math.min(l,4)-1],tierPill=(l,n)=>{const t=tier(l);return `<span class="tier" style="color:${t[1]};background:${t[2]}"><svg viewBox="0 0 24 24">${P.medal}</svg>${esc(n||t[0])}</span>`},
row=(ic,t,s,n,l,b)=>`<li>${icon(ic)}<div><b>${t}</b><small>${s}</small><div class="pr"><i class="bar"><u style="width:${l?Math.min(100,n/l*100):0}%"></u></i><span>${f(n)}/${f(l)}</span></div></div>${b}</li>`;
const DEV=(()=>{const rd=()=>{let v='';try{v=localStorage.getItem('dvid')||''}catch{}if(!v){const m=document.cookie.match(/(?:^|; )dvid=([a-f0-9]{32})/);v=m?m[1]:''}return v};let id=rd();
 if(!/^[a-f0-9]{32}$/.test(id))id=[...crypto.getRandomValues(new Uint8Array(16))].map(b=>b.toString(16).padStart(2,'0')).join('');
 try{localStorage.setItem('dvid',id)}catch{}try{document.cookie='dvid='+id+';max-age=63072000;path=/;SameSite=Lax'}catch{}return id})();
const FP=(()=>{let s=[screen.width,screen.height,devicePixelRatio,screen.colorDepth,Intl.DateTimeFormat().resolvedOptions().timeZone,navigator.language,navigator.hardwareConcurrency,navigator.deviceMemory,navigator.platform,navigator.maxTouchPoints].join('|');
 try{const g=document.createElement('canvas').getContext('webgl'),x=g&&g.getExtension('WEBGL_debug_renderer_info');if(x)s+='|'+g.getParameter(x.UNMASKED_VENDOR_WEBGL)+'|'+g.getParameter(x.UNMASKED_RENDERER_WEBGL)}catch{}
 let a=0xdeadbeef,b=0x41c6ce57,c=0x9e3779b9,d=0x85ebca6b;for(let i=0;i<s.length;i++){const k=s.charCodeAt(i);a=Math.imul(a^k,2654435761);b=Math.imul(b^k,1597334677);c=Math.imul(c^k,2246822507);d=Math.imul(d^k,3266489909)}
 a^=b>>>7;c^=d>>>11;b=Math.imul(b^a,2246822507);d=Math.imul(d^c,3266489909);const h=n=>(n>>>0).toString(16).padStart(8,'0');return h(a)+h(b)+h(c)+h(d)})();
async function api(a,b){try{const r=await fetch('api.php?a='+a,{method:b?'POST':'GET',headers:{'X-Init-Data':tg?.initData||'','X-Device':DEV+'.'+FP},body:b?new URLSearchParams(b):null});return await r.json()}catch{return{error:'Connection failed. Check your internet.'}}}
function toast(t,ok){const e=$('#toast');e.textContent=t;e.className='show '+(ok?'ok':'bad');clearTimeout(toast.t);toast.t=setTimeout(()=>e.className='',3000)}
function gate(h,p,r){$('main').innerHTML=`<div class="gate"><h2>${h}</h2><p>${esc(p)}</p>${r?'<button class="btn" onclick="location.reload()">Try again</button>':''}</div>`}
async function busy(b,fn){b.classList.add('busy');try{return await fn()}finally{b.classList.remove('busy')}}
const go=u=>/^https:\/\/t\.me\//.test(u)&&tg?.openTelegramLink?tg.openTelegramLink(u):tg?.openLink?tg.openLink(u):window.open(u,'_blank');
const adErr=x=>toast('Please watch the whole ad'+(x?.description?` (${x.description})`:''),0);
async function adFlow(kind){
 if(!window.Adsgram)return toast('Ad failed to load, please try again',0);
 const s=await api(kind==='ad'?'adstart':'bstart',{});if(!s.ok)return toast(s.error,0);
 try{await window.Adsgram.init({blockId:D.ad.block}).show()}catch(x){return adErr(x)}
 if(D.ad.strict){for(let i=0;i<8;i++){await sleep(1500);const d=await api('me');if(d.ad&&(kind==='ad'?d.ad.n>D.ad.n:!d.bonus.ready))return toast('Reward added',1)}return toast('Verifying, check your balance shortly',0)}
 let r=await api('adclaim',{});if(r.wait){await sleep(r.wait*1000);r=await api('adclaim',{})}
 toast(r.ok?`+${f(r.reward)} points`:r.error,r.ok)}
async function intFlow(){
 if(!window.Adsgram)return toast('Ad failed to load, please try again',0);
 const s=await api('istart',{});if(!s.ok)return toast(s.error,0);
 try{await window.Adsgram.init({blockId:D.int.block}).show()}catch(x){return adErr(x)}
 let r=await api('iclaim',{});if(r.wait){await sleep(r.wait*1000);r=await api('iclaim',{})}
 toast(r.ok?`+${f(r.reward)} points`:r.error,r.ok)}
function dailyList(){const a=D.ad,n=D.int,g=D.agt,L=[],btn=(k,x)=>{const full=x.n>=x.limit,w=x.cd_left>0;return `<button class="btn sm" data-ad="${k}" ${full||w?'disabled':''}>${full?'Done':w?x.cd_left+'s':'Watch'}</button>`};
 if(a.on)L.push(row('play','Reward ad',`+${f(a.reward)} points each`,a.n,a.limit,btn('ad',a)));
 if(n.on)L.push(row('flash','Interstitial ad',`+${f(n.reward)} points each`,n.n,n.limit,btn('int',n)));
 if(g.on)L.push(row('gift','Sponsored task',`+${f(g.reward)} points each`,g.n,g.limit,''));
 $('#dt').innerHTML=L.length?L.join(''):'<li><div><small>No daily tasks right now</small></div></li>'}
function bonusCard(){const b=D.bonus,lock=b.done<b.total,off=!b.ready||lock||b.amt<=0;
 const sub=b.amt<=0?'The daily bonus is currently disabled':!b.ready?'Claimed today. Come back tomorrow!':lock?`Complete all daily tasks to unlock (${b.done}/${b.total})`:`Claim +${f(b.amt)} points${b.needad?' by watching a short ad':''}`;
 $('#bn').className='bonus '+(!b.ready?'done':lock?'lock':'rdy');
 {const pp=D.paid_pub,pb=$('#paidbox');if(pb){pb.hidden=!(pp&&pp.n>0);if(pp&&pp.n>0)pb.innerHTML=`<b>${f(pp.ton)} USDT</b><small>paid out to members in ${pp.n} withdrawal${pp.n>1?'s':''}</small>`}}
 $('#bn').innerHTML=`<div class="bi">${icon('gift','gold')}</div><div class="bt"><b>Daily Bonus</b><small>${sub}</small><i class="bar"><u style="width:${b.total?b.done/b.total*100:100}%"></u></i></div><button class="btn sm" id="bnb" ${off?'disabled':''}>${!b.ready?'Claimed':lock?'Locked':'Claim'}</button>`}
const TG=[['app','App installs','Install, open once, earn','app','gA'],['link','Website visits','Stay on the page for the timer','globe','gW'],['channel','Telegram channels','Join and stay a member','channel','gC'],['bot','Bots & Mini Apps','Open it and start using it','bot','gB']];
let tFilter='all';
function taskRow(t,g){const b=t.kind==='app'&&t.st===3?'<button class="btn sm" disabled>In review</button>':t.kind==='app'&&t.st===1?(t.verify==='proof'?`<button class="btn sm" data-a="proof" data-id="${t.id}">Submit</button>`:`<button class="btn sm" data-a="claim" data-id="${t.id}">Check</button>`):t.st===2?'<button class="btn sm" disabled>Done</button>':t.st===0&&t.retry>0?`<button class="btn sm" disabled>Wait ${t.retry}s</button>`:t.st===0?`<button class="btn sm" data-a="start" data-id="${t.id}">Start</button>`:t.left>0?`<button class="btn sm" disabled>${t.left}s</button>`:`<button class="btn sm" data-a="claim" data-id="${t.id}">${t.verify==='conv'?'Check':'Claim'}</button>`;
 return `<li class="${t.st===2?'dn':''}">${t.icon?`<img class="ti" src="${esc(t.icon)}" alt="" loading="lazy">`:icon(g[3],g[4])}<div><b>${esc(t.title)}</b><span class="rwp">+${f(t.reward)} pts</span>${t.kind==='link'&&t.st===0&&t.wait>0?`<small class="mu">Stay on the website for ${t.wait}s</small>`:''}${t.kind==='app'&&t.st===0?`<small class="mu">Install the app and open it once</small>`:''}${t.kind==='app'&&t.st===1?(t.verify==='proof'?`${t.rej?'<small class="mu" style="color:#DC2626">Proof rejected, please try again</small>':''}<input class="pf" data-pf="${t.id}" maxlength="100" placeholder="Your username or ID in the app">`:'<small class="mu">Confirmation is automatic after install. Tap Check in a few minutes.</small>'):''}${t.kind==='bot'&&t.st===1?'<small class="mu">Open the bot, use it, then tap Check</small>':''}${t.kind==='bot'&&t.st===0?'<small class="mu">Open the bot or mini app and start it</small>':''}${t.kind==='channel'&&t.st===0?'<small class="mu">Join the channel, then tap Check</small>':''}${t.kind==='app'&&t.st===3?'<small class="mu">Waiting for review</small>':''}${t.st===2&&t.next>0?`<small class="mu">Available again in ${dur(t.next)}</small>`:''}</div>${b}</li>`}
function tasks(){const keep={};$$('input[data-pf]').forEach(i=>keep[i.dataset.pf]=i.value);
 const by={};D.tasks.forEach(t=>{const k=TG.some(g=>g[0]===t.kind)?t.kind:'link';(by[k]=by[k]||[]).push(t)});
 const G=TG.filter(g=>by[g[0]]&&by[g[0]].length);if(tFilter!=='all'&&!G.some(g=>g[0]===tFilter))tFilter='all';
 const open=a=>a.filter(t=>t.st!==2).length;
 let h='';
 if(G.length>1)h+=`<div class="chips" role="tablist"><button type="button" class="${tFilter==='all'?'on':''}" data-tf="all">All<i>${open(D.tasks)}</i></button>${G.map(g=>`<button type="button" class="${tFilter===g[0]?'on':''}" data-tf="${g[0]}">${g[1]}<i>${open(by[g[0]])}</i></button>`).join('')}</div>`;
 G.filter(g=>tFilter==='all'||tFilter===g[0]).forEach(g=>{const L=by[g[0]].slice().sort((a,b)=>(a.st===2)-(b.st===2));const n=open(L);
  h+=`<section class="tg ${g[4]}"><div class="tgh">${icon(g[3],g[4])}<div><b>${g[1]}</b><small>${g[2]}</small></div><span class="cnt">${n} available</span></div><ul class="list">${L.map(t=>taskRow(t,g)).join('')}</ul></section>`});
 $('#tasks').innerHTML=G.length?h:'<ul class="list"><li><div><small>No tasks available. Check back later.</small></div></li></ul>';
 $$('input[data-pf]').forEach(i=>{if(keep[i.dataset.pf])i.value=keep[i.dataset.pf]})}
document.addEventListener('click',e=>{const b=e.target.closest('[data-tf]');if(!b)return;tFilter=b.dataset.tf;try{tg?.HapticFeedback?.selectionChanged()}catch{}tasks()});
let agBuilt=false;
function agTask(){const g=D.agt,box=$('#agbox');box.hidden=!(g.on&&g.n<g.limit);if(box.hidden||agBuilt)return;if(!customElements.get('adsgram-task'))return;agBuilt=true;
 const el=document.createElement('adsgram-task');el.setAttribute('data-block-id',g.block);el.setAttribute('block-id',g.block);el.className='agtask';
 el.innerHTML=`<span slot="reward">+${f(g.reward)} points</span><button slot="button" class="btn sm">Go</button><span slot="done">Done</span>`;
 let goAt=0;el.addEventListener('click',()=>{if(!goAt||Date.now()-goAt>1800000){goAt=Date.now();api('agt_go',{})}});
 el.addEventListener('reward',async()=>{const w=(D.agt.wait||0)*1000;if(w&&(!goAt||Date.now()-goAt<w)){goAt=0;return toast(`You came back too early. Stay on the task page for ${D.agt.wait} seconds to earn points.`,0)}goAt=0;const n0=D.agt.n;toast('Verifying reward…',1);for(let i=0;i<8;i++){await sleep(1500);const d=await api('me');if(d.agt&&d.agt.n>n0){D=d;render();return toast(`+${f(d.agt.reward)} points`,1)}}toast('Verifying, check your balance shortly',0)});
 el.addEventListener('onBannerNotFound',()=>{box.hidden=true});box.appendChild(el)}
const short=a=>a.length>14?a.slice(0,6)+'…'+a.slice(-6):a;
function steps(s){if(s==='Rejected')return '<div class="rej">Rejected. Points were refunded.</div>';const n=SI[s]??0;
 return `<div class="steps">${SG.map((l,i)=>`<div class="st ${i<n||n===3?'done':i===n?'cur':''}"><i></i><span>${l}</span></div>`).join('')}</div>`}
function render(){const B=D.bonus,est=D.ton_rate>0?`≈ ${f(D.balance/D.ton_rate)} USDT`:'';
 ['#bal','#bal2','#bal3'].forEach(i=>set(i,f(D.balance)));set('#est2',est);set('#est3',est);set('#tot',f(D.total));set('#lv2',D.rank_label);set('#dp2',`${B.done}/${B.total}`);
 set('#dp',`${B.done}/${B.total} completed`);$('#dpb').style.width=(B.total?B.done/B.total*100:0)+'%';
 $('#who').innerHTML=`${av(D,52)}<div class="wn"><b>${esc(D.name)}</b><div class="wb">${tierPill(D.level,D.rank_label)}<span class="rk">Rank #${f(D.rank)}</span>${vbadge(D.email_ok)}</div></div>`;
  $('#ann').hidden=!D.ann;set('#annt',D.ann||'');
 $('#bdot').hidden=!D.unread;$('#bdot').textContent=D.unread>9?'9+':D.unread;$('#hdot').hidden=!D.help.answered;$('#vwarn').hidden=D.email_ok;$('#vb').innerHTML=vbadge(D.email_ok);
 $('#vstat').innerHTML=D.email_ok?`Verified Gmail: <b>${esc(D.email)}</b> <button class="lnk" id="mchg" type="button">Change</button>`:'Add your Gmail to verify your account. Verification is required to withdraw.';
 $('#vform').hidden=D.email_ok&&!chg;set('#cmail',D.email_ok?`A confirmation code will be sent to ${D.email}.`:'');
 if(!$('#addr').dataset.t&&!$('#addr').value)$('#addr').value=D.ton_addr||'';if(!$('#memo').dataset.t&&!$('#memo').value)$('#memo').value=D.ton_memo||'';$('#devp').hidden=!D.dev_on;dailyList();bonusCard();agTask();tasks();
 set('#min','Minimum '+f(D.min)+' points.');$('#rl').value=D.link||'Invite link is not available yet';set('#rc',`${f(D.refs)} friends invited · ${f(D.ref_earn)} points earned · ${f(D.pct)}% commission`);
 $('#pav').innerHTML=av(D,96);set('#pn',D.name);$('#ptier').innerHTML=tierPill(D.level,D.rank_label);
 set('#lvt',D.rank_label);$('#pips').innerHTML=[1,2,3].map(i=>`<i class="${i<=D.sub?'on':''}"></i>`).join('');set('#lvn',D.next_cost===null?'Max level':`Next: ${D.next_name}`);$('#lvbar').style.width=(D.next_cost?Math.min(100,Math.max(0,(D.total-D.from)/Math.max(1,D.next_cost-D.from)*100)):100)+'%';
 set('#lt',D.next_cost===null?'You have reached the highest level':`${f(Math.min(D.total,D.next_cost))} / ${f(D.next_cost)} total points earned to reach ${D.next_name}. Levels upgrade automatically.`);const nl=D.nextlv;$('#lbn').innerHTML=nl?'<li>'+esc(D.next_name)+' unlocks:</li>'+[D.ad.on&&`Reward ads: ${f(nl.ad_reward)} pts each, ${f(nl.ad_limit)} per day`,D.int.on&&`Interstitial ads: ${f(nl.int_reward)} pts each, ${f(nl.int_limit)} per day`,D.agt.on&&`Sponsored tasks: ${f(nl.agt_reward)} pts each, ${f(nl.agt_limit)} per day`,`Special task rewards: ${f(nl.task_pct)}%`,D.bonus.amt>0&&`Daily bonus: ${f(nl.bonus)} pts`].filter(Boolean).map(t=>`<li>${t}</li>`).join(''):'';
 set('#s1',f(D.total));set('#s2',f(D.stats.ads));set('#s3',f(D.stats.tasks));set('#s4',f(D.refs));
 $('#badges').innerHTML=Object.entries(BG).map(([k,[t,d,i]])=>`<div class="bd ${D.badges[k]?'on':''}"><span><svg viewBox="0 0 24 24">${P[i]}</svg></span><b>${t}</b><small>${d}</small></div>`).join('');
 $('#hist').innerHTML=D.hist.length?D.hist.map(h=>`<li class="wi"><div class="wh"><b>${f(h.amount)} pts${h.ton>0?` · ${+h.ton} USDT`:''}</b><span class="mu">${esc(h.created_at.slice(0,16))}</span></div><small>${esc(short(h.number))}</small>${steps(h.status)}${h.tx?`<small>TX: ${esc(short(h.tx))}</small>`:''}${h.note?`<small>${esc(h.note)}</small>`:''}</li>`).join(''):'<li><div><small>No withdrawals yet</small></div></li>';
 $('#agrid').innerHTML=`<button class="at ${D.avatar==='tg'?'sel':''}" data-c="tg">${av({avatar:'tg',photo:D.photo,name:D.name},56)}<small>Telegram</small></button>`+PRE.map((_,i)=>`<button class="at ${D.avatar==='p'+(i+1)?'sel':''}" data-c="p${i+1}">${av({avatar:'p'+(i+1)},56)}</button>`).join('')}
function podium(L){const c=(x,r)=>x?`<div class="pc r${r}">${r===1?`<svg class="crown" viewBox="0 0 24 24"><path d="M3 8l4.5 4L12 5l4.5 7L21 8l-2 11H5z"/></svg>`:''}<div class="ring">${av(x,r===1?84:64)}<em>${r}</em></div><b>${esc(x.n)}${x.dm?' <i class="you">Demo</i>':''}</b><small>${f(x.p)} pts</small><div class="pd"></div></div>`:'<div class="pc"></div>';
 return `<div class="podium">${c(L[1],2)}${c(L[0],1)}${c(L[2],3)}</div>`}
async function load(){const d=await api('me');if(d.blocked)return blockScreen(d);if(d.error)return gate('Something went wrong',d.error,true);if(D&&(d.level>D.level||(d.level===D.level&&d.sub>D.sub)))toast('Congratulations! You reached '+d.rank_label,1);D=d;render()}
let pollT=null;setInterval(()=>{if(document.hidden||!D||!D.tasks)return;if(D.tasks.some(t=>t.camp&&t.st===1&&t.kind==='link'&&!(t.left>0)))load()},6000);
async function loadTop(){const d=await api('top'),L=d.top||[];$('#podium').innerHTML=L.length?podium(L):'<p class="mu" style="text-align:center;padding:30px 0">No rankings yet</p>';
 $('#board').innerHTML=L.slice(3).map((x,i)=>`<li class="${x.me?'me':''}"><em>${i+4}</em>${av(x,38)}<span>${esc(x.n)}${x.me?' <i class="you">You</i>':''}${x.dm?' <i class="you">Demo</i>':''}</span><b>${f(x.p)}</b></li>`).join('')}
$('#dt').addEventListener('click',async e=>{const b=e.target.closest('button[data-ad]');if(!b)return;await busy(b,()=>b.dataset.ad==='int'?intFlow():adFlow('ad'));load()});
$('#bn').addEventListener('click',async e=>{const b=e.target.closest('#bnb');if(!b)return;await busy(b,async()=>{if(D.bonus.needad)await adFlow('bonus');else{const r=await api('bonus',{});toast(r.ok?`+${f(r.reward)} bonus points`:r.error,r.ok)}});load()});
$('#tasks').addEventListener('click',async e=>{const b=e.target.closest('button[data-a]');if(!b)return;const id=b.dataset.id,t=D.tasks.find(x=>x.id==id);
 await busy(b,async()=>{if(b.dataset.a==='proof'){const inp=document.querySelector('input[data-pf="'+id+'"]');const r=await api('app_proof',{id,proof:inp?inp.value:''});toast(r.ok?'Submitted. We will review it soon.':r.error,r.ok);if(r.ok)await load();return}
  const r=await api(b.dataset.a,{id});
  if(b.dataset.a==='start'){if(!r.ok)return toast(r.error,0);if(t.kind==='link'&&Number(t.wait)>0)visit={id:t.id,wait:Number(t.wait),at:Date.now(),hid:null};if(r.click&&navigator.clipboard)navigator.clipboard.writeText(r.click).catch(()=>{});go(r.url);t.st=1;t.left=t.kind==='link'?Number(t.wait):0;tasks()}
  else{toast(r.ok?`+${f(r.reward)} points`:r.error,r.ok);if(r.failed){t.st=0;t.left=0;t.retry=Number(r.retry)||0;tasks();return}if(r.ok||t.kind==='app'||t.camp)await load()}})});
$('#wd').addEventListener('submit',async e=>{e.preventDefault();await busy(e.target.querySelector('button'),async()=>{const r=await api('withdraw',Object.fromEntries(new FormData(e.target)));
 toast(r.ok?'Withdrawal requested':r.error,r.ok);if(r.ok){$('#code').value='';$('#amount').value='';set('#est','');await load()}})});
$('#amount').addEventListener('input',e=>set('#est',D?.ton_rate>0&&e.target.value?`≈ ${f(e.target.value/D.ton_rate)} USDT`:''));
$('#addr').oninput=e=>e.target.dataset.t=1;$('#memo').oninput=e=>e.target.dataset.t=1;
$('#sendc').onclick=async e=>{await busy(e.target,async()=>{const r=await api('wdcode',Object.fromEntries(new FormData($('#wd'))));toast(r.ok?`Code sent to ${D.email}. If it is not in your Inbox, check Spam`:r.error,r.ok)})};
$('#msend').onclick=async e=>{await busy(e.target,async()=>{const r=await api('email_send',{email:$('#mail').value});toast(r.ok?'Code sent. Check your Gmail Inbox, and the Spam folder if you do not see it':r.error,r.ok)})};
$('#mver').onclick=async e=>{await busy(e.target,async()=>{const r=await api('email_verify',{email:$('#mail').value,code:$('#mcode').value});toast(r.ok?'Gmail verified':r.error,r.ok);if(r.ok){$('#mcode').value='';chg=false;await load()}})};
document.addEventListener('click',e=>{const g=e.target.closest('[data-go]');if(g)$(`nav button[data-t="${g.dataset.go}"]`).click();if(e.target.id==='mchg'){chg=true;$('#vform').hidden=false}});
$('#bell').onclick=async()=>{$('#nsheet').hidden=false;const d=await api('notices');$('#nlist').innerHTML=(d.list||[]).length?d.list.map(n=>`<li class="${n.read_at?'':'unr'}"><div><b>${esc(n.title)}</b><small class="pw">${esc(n.body)}</small><small class="mu">${esc(n.created_at.slice(0,16))}</small></div></li>`).join(''):'<li><div><small>No notifications yet</small></div></li>';if(D.unread){await api('notice_read',{});D.unread=0;$('#bdot').hidden=true}};
$('#nx').onclick=()=>$('#nsheet').hidden=true;$('#nsheet').onclick=e=>{if(e.target.id==='nsheet')e.target.hidden=true};
setInterval(()=>{if(!document.hidden&&D)api('ping')},60000);
$('#cp').onclick=()=>{navigator.clipboard?.writeText($('#rl').value);toast('Link copied',1)};
$('#edav').onclick=()=>$('#sheet').hidden=false;$('#shx').onclick=()=>$('#sheet').hidden=true;$('#sheet').onclick=e=>{if(e.target.id==='sheet')e.target.hidden=true};
$('#agrid').addEventListener('click',async e=>{const b=e.target.closest('button[data-c]');if(!b)return;const r=await api('avatar',{choice:b.dataset.c});if(r.ok){$('#sheet').hidden=true;toast('Photo updated',1);load()}else toast(r.error,0)});
$('#file').onchange=async e=>{const fl=e.target.files[0];e.target.value='';if(!fl)return;try{const im=new Image();im.src=URL.createObjectURL(fl);await im.decode();
 const c=document.createElement('canvas');c.width=c.height=256;const s=Math.min(im.width,im.height);c.getContext('2d').drawImage(im,(im.width-s)/2,(im.height-s)/2,s,s,0,0,256,256);
 const r=await api('avatar_up',{img:c.toDataURL('image/jpeg',.85)});if(r.ok){$('#sheet').hidden=true;toast('Photo updated',1);load()}else toast(r.error,0)}catch{toast('Could not read that image',0)}};
$$('nav button').forEach(b=>b.onclick=()=>{$$('nav button').forEach(x=>x.classList.toggle('on',x===b));$$('.tab').forEach(s=>s.classList.toggle('on',s.id==='t-'+b.dataset.t));scrollTo(0,0);if(b.dataset.t==='top')loadTop()});
let tk=0;setInterval(()=>{if(!D)return;tk++;let c=0,d=0;D.tasks.forEach(t=>{if(t.st===1&&t.left>0){t.left--;c=1}if(t.st===0&&t.retry>0){t.retry--;c=1}if(t.st===2&&t.next>0){t.next--;if(t.next<=0){t.st=0;c=1}else if(tk%20===0)c=1}});if(D.ad.cd_left>0){D.ad.cd_left--;d=1}if(D.int.cd_left>0){D.int.cd_left--;d=1}if(c)tasks();if(d)dailyList()},1000);
const TS={Open:'Waiting for support',Answered:'Support replied',Closed:'Closed'};let cur=0;
const hv=n=>{[1,2,3].forEach(i=>$('#hv'+i).hidden=i!==n);$('#htt').textContent=['','Help Desk','New ticket','Ticket'][n]},rs=t=>t.reason==='Others'&&t.custom?'Others: '+t.custom:t.reason;
async function hList(){hv(1);const d=await api('tickets');$('#hlist').innerHTML=(d.list||[]).length?d.list.map(t=>`<li class="tk" data-id="${t.id}"><div><b>#${t.id} · ${esc(rs(t))}</b><small>${esc((t.last||'').slice(0,80))}</small><small class="mu">${esc(String(t.updated_at||t.created_at).slice(0,16))}</small></div><span class="tag ${t.status}">${TS[t.status]||t.status}</span></li>`).join(''):'<li><div><small>No tickets yet</small></div></li>'}
async function hThread(id){cur=id;hv(3);const d=await api('ticket',{id});if(d.error)return toast(d.error,0);const c=d.t.status==='Closed';$('#hrep').hidden=c;$('#hratt').hidden=!D.help.img;hrshot='';$('#hrprevw').hidden=true;$('#hclosed').hidden=!c;
 $('#hthr').innerHTML=`<div class="mu" style="text-align:center">#${d.t.id} · ${esc(rs(d.t))}</div>`+d.msgs.map(m=>`<div class="m ${m.sender}">${m.body?`<p>${esc(m.body)}</p>`:''}${m.img?`<a href="uploads/help/${esc(m.img)}" target="_blank" rel="noopener"><img class="mimg" src="uploads/help/${esc(m.img)}" alt="Screenshot" loading="lazy"></a>`:''}<small>${m.sender==='admin'?'Support · ':''}${esc(m.created_at.slice(0,16))}</small></div>`).join('');$('#hthr').scrollTop=1e6}
function hNew(pre){hv(2);hshot='';$('#hprevw').hidden=true;$('#hfile').value='';$('#hreason').innerHTML='<option value="">Select a reason…</option>'+D.help.reasons.filter(r=>D.help.dev||!/^Developer/.test(r)).map(r=>`<option>${esc(r)}</option>`).join('');$('#hwdid').innerHTML='<option value="">None</option>'+D.hist.map(h=>`<option value="${h.id}">#${h.id} · ${f(h.amount)} pts · ${h.status}</option>`).join('');
 if(pre)$('#hreason').value=pre;hrs()}
let hshot='',hrshot='';
const shot=file=>new Promise((ok,no)=>{const r=new FileReader();r.onerror=()=>no();r.onload=()=>{const im=new Image();im.onerror=()=>no();im.onload=()=>{const k=Math.min(1,1280/Math.max(im.width,im.height)),cv=document.createElement('canvas');cv.width=Math.round(im.width*k);cv.height=Math.round(im.height*k);const x=cv.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,cv.width,cv.height);x.drawImage(im,0,0,cv.width,cv.height);ok(cv.toDataURL('image/jpeg',.8))};im.src=r.result};r.readAsDataURL(file)});
const hrs=()=>{const v=$('#hreason').value;$('#himg').hidden=!D.help.img;const tp=(D.help.tips||{})[v];$('#htip').hidden=!tp;$('#htip').textContent=tp||'';$('#hcl').hidden=v!=='Others';$('#hcustom').required=v==='Others';$('#hwl').hidden=!/withdraw|payment|ton/i.test(v)};
$('#hbtn').onclick=()=>{$('#hsheet').hidden=false;hList()};$('#hwd').onclick=()=>{$('#hsheet').hidden=false;hNew('Withdrawal not processed')};
$('#hx').onclick=()=>$('#hsheet').hidden=true;$('#hsheet').onclick=e=>{if(e.target.id==='hsheet')e.target.hidden=true};$('#hnew').onclick=()=>hNew();$('#hback').onclick=hList;$('#hback2').onclick=()=>{hList();load()};$('#hreason').onchange=hrs;
$('#hfile').onchange=async e=>{const f=e.target.files[0];if(!f)return;try{hshot=await shot(f);$('#hprev').src=hshot;$('#hprevw').hidden=false}catch{toast('This image could not be read',0)}};$('#hrmv').onclick=()=>{hshot='';$('#hfile').value='';$('#hprevw').hidden=true};
$('#hrf').onchange=async e=>{const f=e.target.files[0];if(!f)return;try{hrshot=await shot(f);$('#hrprev').src=hrshot;$('#hrprevw').hidden=false}catch{toast('This image could not be read',0)}};$('#hrrmv').onclick=()=>{hrshot='';$('#hrf').value='';$('#hrprevw').hidden=true};
$('#hlist').addEventListener('click',e=>{const l=e.target.closest('li[data-id]');if(l)hThread(+l.dataset.id)});
$('#hv2').addEventListener('submit',async e=>{e.preventDefault();await busy(e.target.querySelector('button'),async()=>{const r=await api('ticket_new',{reason:$('#hreason').value,custom:$('#hcustom').value,wd_id:$('#hwdid').value,body:$('#hbody').value,img:hshot});
 toast(r.ok?'Sent to support. We will reply soon.':r.error,r.ok);if(r.ok){$('#hbody').value='';$('#hcustom').value='';hshot='';$('#hprevw').hidden=true;await hList();load()}})});
$('#hrep').addEventListener('submit',async e=>{e.preventDefault();await busy(e.target.querySelector('button'),async()=>{if(!$('#hrt').value.trim()&&!hrshot)return toast('Write a message or add a screenshot',0);const r=await api('ticket_reply',{id:cur,body:$('#hrt').value,img:hrshot});if(r.ok){$('#hrt').value='';hrshot='';$('#hrprevw').hidden=true;await hThread(cur)}else toast(r.error,0)})});
let visit=null;
const away=()=>{if(!visit||visit.hid!==null)return;if(Date.now()-visit.at>6000){visit=null;return}visit.hid=Date.now()};
async function back(){if(!visit||visit.hid===null)return;const v=visit;visit=null;const s=Math.round((Date.now()-v.hid)/1000);
 if(s<v.wait-1){await api('task_fail',{id:v.id});const t=D.tasks.find(x=>x.id==v.id);if(t){t.st=0;t.left=0}tasks();toast(`You came back after ${s}s. You must stay on the website for the full ${v.wait} seconds to earn points. Please start the task again.`,0)}
 else{await api('task_back',{id:v.id,away:s});await load();toast('Great! Your time on the website is complete. Tap Claim to get your points.',1)}}
document.addEventListener('visibilitychange',()=>document.hidden?away():back());tg?.onEvent?.('deactivated',away);tg?.onEvent?.('activated',back);
function blockScreen(d){document.body.classList.add('blocked');let left=d.left;
 $('main').innerHTML=`<div class="gate bk"><div class="bki"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M5.6 5.6l12.8 12.8"/></svg></div><h2>${left===null?'Your account is blocked':'Your account is temporarily blocked'}</h2><div class="rsn"><small>Reason</small><p>${esc(d.reason||'No reason was given.')}</p></div>${left===null?'<p>This block has no end date. If you think this is a mistake, please contact the admin.</p>':'<div class="cd"><small>Time remaining</small><b id="bkt"></b></div><p>You will be able to use the app again automatically when the timer ends.</p>'}</div>`;
 if(left===null)return;const t=()=>{const h=Math.floor(left/3600),m=Math.floor(left%3600/60),s=left%60,dd=Math.floor(h/24);$('#bkt').textContent=(dd?dd+'d ':'')+String(h%24).padStart(2,'0')+':'+String(m).padStart(2,'0')+':'+String(s).padStart(2,'0')};
 t();const iv=setInterval(()=>{left--;if(left<=0){clearInterval(iv);location.reload()}else t()},1000)}
if(!tg?.initData)gate('Open from Telegram','This app only works inside Telegram. Open it from your bot menu.');else load();

// Add to Home Screen (Telegram Mini Apps, Bot API 8.0+). Hidden when unsupported, already added, or turned off by the admin.
(()=>{if(!tg||typeof tg.addToHomeScreen!=='function'||typeof tg.checkHomeScreenStatus!=='function')return;
 let st='';const K=k=>{try{return localStorage.getItem(k)}catch{return null}},S=(k,v)=>{try{localStorage.setItem(k,v)}catch{}};
 const need=()=>D&&D.home_need?D.home_need:'';
 const claim=async()=>{const r=await api('home_claim',{x:1});if(r.ok){if(D){D.home_claimed=true}toast('+'+f(r.reward)+' points for adding to Home Screen',1);load()}else if(D&&/already/i.test(r.error||''))D.home_claimed=true;else toast(r.error||'Not available yet',0);show()};
 const show=()=>{const pts=D?Number(D.home_pts||0):0,can=!!(D&&D.home_add)&&pts>0&&!D.home_claimed&&st==='added';const ok=!!(D&&D.home_add)&&(st==='missed'||st==='unknown');
  $('#hsp').hidden=!(ok||can);$('#hsbtn').textContent=can?'Claim +'+f(pts)+' points':ok?(pts>0&&!D.home_claimed?'Add to Home Screen (+'+f(pts)+' points)':'Add to Home Screen'):'';$('#hsbtn').dataset.hs=can?'claim':'add';
  $('#hscard').hidden=!((ok||can)&&(can||Number(K('hs_n')||0)>=2)&&K('hs_x')!=='1');$('#hscard small').textContent=pts>0&&!D.home_claimed?'Add it and get +'+f(pts)+' points (one time).'+(need()?' '+need():''):'Open it like any other app, in one tap.';const b=$('#hscard [data-hs=add],#hscard [data-hs=claim]');if(b){b.dataset.hs=can?'claim':'add';b.textContent=can?'Claim':'Add'}};
 const chk=()=>{try{tg.checkHomeScreenStatus(s=>{st=s||'';show()})}catch{}};
 const t=setInterval(()=>{if(!D)return;clearInterval(t);S('hs_n',String(Number(K('hs_n')||0)+1));chk()},400);
 try{tg.onEvent('homeScreenAdded',()=>{st='added';show();if(D&&D.home_pts>0&&!D.home_claimed)claim();else toast('Added to your Home Screen',1)})}catch{}
 document.addEventListener('click',e=>{const b=e.target.closest('[data-hs]');if(!b)return;if(b.dataset.hs==='no'){S('hs_x','1');$('#hscard').hidden=true;return}if(b.dataset.hs==='claim'){claim();return}try{tg.addToHomeScreen();setTimeout(chk,1500)}catch{}})})();
