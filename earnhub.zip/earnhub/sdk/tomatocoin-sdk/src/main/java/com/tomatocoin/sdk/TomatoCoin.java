package com.tomatocoin.sdk;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.view.ViewTreeObserver;

import com.android.installreferrer.api.InstallReferrerClient;
import com.android.installreferrer.api.InstallReferrerStateListener;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * TomatoCoin install confirmation SDK.
 *
 * Call {@link #init(Context, String, int, String)} once when your app starts (for example in your launcher Activity's onCreate).
 * On the first launch after an install that came from an TomatoCoin campaign, the SDK tells TomatoCoin that the app was installed
 * and opened. TomatoCoin then pays the member and charges your campaign balance. Works from Kotlin and Java.
 *
 * It collects no personal data. It sends only the campaign id, your public SDK key, the TomatoCoin member id and the one-time
 * token that were in the install link, and the SDK version.
 */
public final class TomatoCoin {

    public static final String VERSION = "1.0.0";
    private static final String TAG = "TomatoCoin";
    private static final String PREFS = "tomatocoin_sdk";
    private static final Pattern CLIP = Pattern.compile("^EHT1:(\\d{1,20})\\.([a-f0-9]{16})\\.(\\d{1,10})$");
    private static final Pattern UID = Pattern.compile("^\\d{1,20}$");
    private static final Pattern TOK = Pattern.compile("^[a-f0-9]{16}$");

    /** Optional callback with the result. It is called on a background thread. */
    public interface Listener {
        void onResult(boolean confirmed, String message);
    }

    private static final ExecutorService IO = Executors.newSingleThreadExecutor(new ThreadFactory() {
        @Override
        public Thread newThread(Runnable r) {
            Thread t = new Thread(r, "tomatocoin-sdk");
            t.setDaemon(true);
            return t;
        }
    });

    private static volatile boolean clipboardEnabled = true;

    private TomatoCoin() {
    }

    private static final class Cfg {
        final String site;
        final int campaignId;
        final String key;
        final Listener listener;

        Cfg(String site, int campaignId, String key, Listener listener) {
            this.site = site;
            this.campaignId = campaignId;
            this.key = key;
            this.listener = listener;
        }
    }

    private static final class Found {
        final String uid;
        final String token;

        Found(String uid, String token) {
            this.uid = uid;
            this.token = token;
        }
    }

    private static volatile Cfg current;

    /**
     * Starts install confirmation.
     *
     * @param context    your Activity (preferred) or Application
     * @param site       your TomatoCoin address, for example "https://earn.example.com"
     * @param campaignId the campaign number shown in the Developer Programme
     * @param publicKey  the public SDK key of that campaign
     */
    public static void init(Context context, String site, int campaignId, String publicKey) {
        init(context, site, campaignId, publicKey, null);
    }

    public static void init(Context context, String site, int campaignId, String publicKey, Listener listener) {
        if (context == null || site == null || publicKey == null || campaignId <= 0) {
            Log.w(TAG, "init ignored: missing parameters");
            return;
        }
        final Context app = appContext(context);
        final Cfg c = new Cfg(site.trim().replaceAll("/+$", ""), campaignId, publicKey.trim(), listener);
        current = c;
        if (prefs(app).getBoolean(key("done", c), false)) {
            return;
        }
        final Context origin = context;
        IO.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    start(app, origin, c);
                } catch (Throwable t) {
                    Log.w(TAG, "init failed: " + t);
                }
            }
        });
    }

    /**
     * Optional. Call from your launcher Activity's onCreate and onNewIntent if you open the app from a link that carries
     * eh_uid and eh_t (for example when you pass the install link parameters through your own download page).
     */
    public static void handleIntent(Context context, Intent intent) {
        if (context == null || intent == null || intent.getData() == null) {
            return;
        }
        Uri u = intent.getData();
        String uid = u.getQueryParameter("eh_uid");
        String tok = u.getQueryParameter("eh_t");
        if (uid == null || tok == null || !UID.matcher(uid).matches() || !TOK.matcher(tok).matches()) {
            return;
        }
        final Context app = appContext(context);
        final Cfg c = current;
        if (c == null) {
            return;
        }
        String cid = u.getQueryParameter("eh_c");
        if (cid != null && !cid.equals(String.valueOf(c.campaignId))) {
            return;
        }
        final Found f = new Found(uid, tok);
        IO.execute(new Runnable() {
            @Override
            public void run() {
                send(app, c, f);
            }
        });
    }

    /** Confirms an install manually when you received the member id and token yourself. */
    public static void confirm(Context context, final String uid, final String token) {
        final Cfg c = current;
        if (context == null || c == null || uid == null || token == null || !UID.matcher(uid).matches() || !TOK.matcher(token).matches()) {
            return;
        }
        final Context app = appContext(context);
        IO.execute(new Runnable() {
            @Override
            public void run() {
                send(app, c, new Found(uid, token));
            }
        });
    }

    /** By default the SDK also looks for a one-time code on the clipboard (used for apps installed outside Google Play). Call with false to turn this off. */
    public static void setClipboardEnabled(boolean enabled) {
        clipboardEnabled = enabled;
    }

    /** True when this install was already confirmed. */
    public static boolean isConfirmed(Context context) {
        Cfg c = current;
        return context != null && c != null && prefs(appContext(context)).getBoolean(key("confirmed", c), false);
    }

    // ------------------------------------------------------------------ internals

    private static void start(Context app, Context origin, Cfg c) {
        SharedPreferences sp = prefs(app);
        int tries = sp.getInt(key("tries", c), 0);
        if (tries >= 30) {
            return;
        }
        sp.edit().putInt(key("tries", c), tries + 1).apply();

        // 1. Google Play install referrer
        String raw = readReferrer(app);
        if (raw != null) {
            Found f = fromQuery(raw, c);
            if (f != null) {
                send(app, c, f);
                return;
            }
        }
        // 2. Clipboard code (apps installed outside Google Play). Only the first launches are checked.
        if (clipboardEnabled && tries < 3 && origin instanceof Activity) {
            final Activity act = (Activity) origin;
            final Context fapp = app;
            final Cfg fc = c;
            final boolean referrerOk = raw != null;
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override
                public void run() {
                    readClipboardWhenFocused(act, fapp, fc, referrerOk);
                }
            });
            return;
        }
        if (raw != null) {
            finish(app, c, false, "No TomatoCoin campaign information found for this install");
        }
    }

    private static Found fromQuery(String query, Cfg c) {
        try {
            Uri u = Uri.parse("https://x.invalid/?" + query);
            String uid = u.getQueryParameter("eh_uid");
            String tok = u.getQueryParameter("eh_t");
            String cid = u.getQueryParameter("eh_c");
            if (uid != null && tok != null && UID.matcher(uid).matches() && TOK.matcher(tok).matches()
                    && (cid == null || cid.equals(String.valueOf(c.campaignId)))) {
                return new Found(uid, tok);
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    /** Returns the raw referrer string, "" if Google Play has none, or null if the service is not available. */
    private static String readReferrer(Context app) {
        final String[] out = new String[]{null};
        final CountDownLatch latch = new CountDownLatch(1);
        try {
            final InstallReferrerClient client = InstallReferrerClient.newBuilder(app).build();
            client.startConnection(new InstallReferrerStateListener() {
                @Override
                public void onInstallReferrerSetupFinished(int code) {
                    try {
                        if (code == InstallReferrerClient.InstallReferrerResponse.OK) {
                            String r = client.getInstallReferrer().getInstallReferrer();
                            out[0] = r == null ? "" : r;
                        }
                    } catch (Throwable ignored) {
                    } finally {
                        try {
                            client.endConnection();
                        } catch (Throwable ignored) {
                        }
                        latch.countDown();
                    }
                }

                @Override
                public void onInstallReferrerServiceDisconnected() {
                    latch.countDown();
                }
            });
            latch.await(10, TimeUnit.SECONDS);
        } catch (Throwable ignored) {
        }
        return out[0];
    }

    private static void readClipboardWhenFocused(final Activity act, final Context app, final Cfg c, final boolean referrerOk) {
        try {
            final View v = act.getWindow().getDecorView();
            if (v.hasWindowFocus()) {
                readClipboard(act, app, c, referrerOk);
                return;
            }
            v.getViewTreeObserver().addOnWindowFocusChangeListener(new ViewTreeObserver.OnWindowFocusChangeListener() {
                @Override
                public void onWindowFocusChanged(boolean hasFocus) {
                    if (!hasFocus) {
                        return;
                    }
                    v.getViewTreeObserver().removeOnWindowFocusChangeListener(this);
                    readClipboard(act, app, c, referrerOk);
                }
            });
        } catch (Throwable t) {
            Log.w(TAG, "clipboard check failed: " + t);
        }
    }

    private static void readClipboard(Context ctx, final Context app, final Cfg c, final boolean referrerOk) {
        String text = null;
        try {
            ClipboardManager cm = (ClipboardManager) ctx.getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null && cm.hasPrimaryClip()) {
                ClipData d = cm.getPrimaryClip();
                if (d != null && d.getItemCount() > 0 && d.getItemAt(0).getText() != null) {
                    text = d.getItemAt(0).getText().toString().trim();
                }
            }
        } catch (Throwable ignored) {
        }
        Matcher m = text == null ? null : CLIP.matcher(text);
        if (m != null && m.matches() && m.group(3).equals(String.valueOf(c.campaignId))) {
            final Found f = new Found(m.group(1), m.group(2));
            IO.execute(new Runnable() {
                @Override
                public void run() {
                    send(app, c, f);
                }
            });
        } else if (referrerOk) {
            IO.execute(new Runnable() {
                @Override
                public void run() {
                    finish(app, c, false, "No TomatoCoin campaign information found for this install");
                }
            });
        }
    }

    private static void send(Context app, Cfg c, Found f) {
        for (int attempt = 0; attempt < 4; attempt++) {
            String res = post(c, f);
            if (res == null) {
                notify(c, false, "Network error. The SDK will try again the next time the app starts.");
                return;
            }
            if (Pattern.compile("\"ok\"\\s*:\\s*true").matcher(res).find()) {
                finish(app, c, true, "Install confirmed");
                return;
            }
            String err = error(res);
            if ("too early".equals(err)) {
                try {
                    Thread.sleep(15000);
                } catch (InterruptedException e) {
                    return;
                }
                continue;
            }
            // already counted, wrong key, unknown user ...: nothing more to do
            finish(app, c, "already counted".equals(err), err == null ? "Rejected" : err);
            return;
        }
        notify(c, false, "Not accepted yet. The SDK will try again the next time the app starts.");
    }

    private static String error(String json) {
        Matcher m = Pattern.compile("\"error\"\\s*:\\s*\"([^\"]*)\"").matcher(json);
        return m.find() ? m.group(1) : null;
    }

    private static String post(Cfg c, Found f) {
        HttpURLConnection con = null;
        try {
            String body = "a=install&c=" + c.campaignId
                    + "&key=" + URLEncoder.encode(c.key, "UTF-8")
                    + "&uid=" + URLEncoder.encode(f.uid, "UTF-8")
                    + "&t=" + URLEncoder.encode(f.token, "UTF-8")
                    + "&v=" + VERSION;
            con = (HttpURLConnection) new URL(c.site + "/track.php").openConnection();
            con.setRequestMethod("POST");
            con.setConnectTimeout(10000);
            con.setReadTimeout(15000);
            con.setDoOutput(true);
            con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            OutputStream os = con.getOutputStream();
            os.write(body.getBytes("UTF-8"));
            os.close();
            int code = con.getResponseCode();
            InputStream is = code >= 400 ? con.getErrorStream() : con.getInputStream();
            if (is == null) {
                return "";
            }
            BufferedReader br = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null && sb.length() < 4000) {
                sb.append(line);
            }
            br.close();
            return sb.toString();
        } catch (Throwable t) {
            return null;
        } finally {
            if (con != null) {
                con.disconnect();
            }
        }
    }

    private static void finish(Context app, Cfg c, boolean confirmed, String message) {
        SharedPreferences.Editor e = prefs(app).edit().putBoolean(key("done", c), true);
        if (confirmed) {
            e.putBoolean(key("confirmed", c), true);
        }
        e.apply();
        notify(c, confirmed, message);
    }

    private static void notify(Cfg c, boolean confirmed, String message) {
        Log.d(TAG, (confirmed ? "confirmed: " : "not confirmed: ") + message);
        if (c.listener != null) {
            try {
                c.listener.onResult(confirmed, message);
            } catch (Throwable ignored) {
            }
        }
    }

    private static String key(String name, Cfg c) {
        return name + "_" + c.campaignId;
    }

    private static SharedPreferences prefs(Context app) {
        return app.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private static Context appContext(Context c) {
        Context a = c.getApplicationContext();
        return a != null ? a : c;
    }
}
