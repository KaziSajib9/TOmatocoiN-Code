package com.tomatocoin.sdk.flutter;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.annotation.NonNull;

import com.android.installreferrer.api.InstallReferrerClient;
import com.android.installreferrer.api.InstallReferrerStateListener;

import io.flutter.embedding.engine.plugins.FlutterPlugin;
import io.flutter.plugin.common.MethodCall;
import io.flutter.plugin.common.MethodChannel;
import io.flutter.plugin.common.MethodChannel.MethodCallHandler;
import io.flutter.plugin.common.MethodChannel.Result;

/** Android side of the TomatoCoin Flutter plugin: Google Play install referrer and a few stored flags. */
public class TomatocoinSdkPlugin implements FlutterPlugin, MethodCallHandler {
    private static final String PREFS = "tomatocoin_sdk";
    private MethodChannel channel;
    private Context context;

    @Override
    public void onAttachedToEngine(@NonNull FlutterPluginBinding binding) {
        context = binding.getApplicationContext();
        channel = new MethodChannel(binding.getBinaryMessenger(), "tomatocoin_sdk");
        channel.setMethodCallHandler(this);
    }

    @Override
    public void onDetachedFromEngine(@NonNull FlutterPluginBinding binding) {
        channel.setMethodCallHandler(null);
        channel = null;
        context = null;
    }

    @Override
    public void onMethodCall(@NonNull MethodCall call, @NonNull final Result result) {
        SharedPreferences sp = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String k = call.argument("k");
        switch (call.method) {
            case "getFlag":
                result.success(k != null && sp.getBoolean(k, false));
                break;
            case "setFlag":
                Boolean b = call.argument("v");
                if (k != null) {
                    sp.edit().putBoolean(k, b != null && b).apply();
                }
                result.success(null);
                break;
            case "getInt":
                result.success(k == null ? 0 : sp.getInt(k, 0));
                break;
            case "setInt":
                Integer v = call.argument("v");
                if (k != null && v != null) {
                    sp.edit().putInt(k, v).apply();
                }
                result.success(null);
                break;
            case "installReferrer":
                readReferrer(result);
                break;
            default:
                result.notImplemented();
        }
    }

    private void readReferrer(final Result result) {
        try {
            final InstallReferrerClient client = InstallReferrerClient.newBuilder(context).build();
            client.startConnection(new InstallReferrerStateListener() {
                private boolean replied = false;

                private void reply(String value) {
                    if (replied) {
                        return;
                    }
                    replied = true;
                    result.success(value);
                }

                @Override
                public void onInstallReferrerSetupFinished(int code) {
                    String r = null;
                    try {
                        if (code == InstallReferrerClient.InstallReferrerResponse.OK) {
                            r = client.getInstallReferrer().getInstallReferrer();
                            if (r == null) {
                                r = "";
                            }
                        }
                    } catch (Throwable ignored) {
                    } finally {
                        try {
                            client.endConnection();
                        } catch (Throwable ignored) {
                        }
                    }
                    reply(r);
                }

                @Override
                public void onInstallReferrerServiceDisconnected() {
                    reply(null);
                }
            });
        } catch (Throwable t) {
            result.success(null);
        }
    }
}
