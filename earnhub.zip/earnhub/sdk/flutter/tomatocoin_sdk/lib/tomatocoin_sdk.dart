import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

/// TomatoCoin install confirmation for Flutter (Android).
///
/// Call [TomatoCoin.init] once when your app starts, for example from the `initState`
/// of your first screen (after `runApp`). On the first launch after an install that
/// came from an TomatoCoin campaign, the plugin tells TomatoCoin the app was installed and opened.
class TomatoCoin {
  TomatoCoin._();

  static const String sdkVersion = '1.0.0';
  static const MethodChannel _ch = MethodChannel('tomatocoin_sdk');
  static final RegExp _uid = RegExp(r'^\d{1,20}$');
  static final RegExp _tok = RegExp(r'^[a-f0-9]{16}$');
  static final RegExp _clip = RegExp(r'^EHT1:(\d{1,20})\.([a-f0-9]{16})\.(\d{1,10})$');

  /// [site] is your TomatoCoin address, for example `https://earn.example.com`.
  /// [campaignId] and [publicKey] are shown in the Developer Programme.
  /// [useClipboard] also looks for a one-time code on the clipboard (apps installed outside Google Play).
  /// [onResult] is optional and receives the outcome.
  static Future<bool> init({
    required String site,
    required int campaignId,
    required String publicKey,
    bool useClipboard = true,
    void Function(bool confirmed, String message)? onResult,
  }) async {
    if (!Platform.isAndroid) {
      return false; // Install referrer exists only on Android
    }
    final base = site.trim().replaceAll(RegExp(r'/+$'), '');
    void done(bool ok, String msg) {
      if (kDebugMode) debugPrint('TomatoCoin: $msg');
      onResult?.call(ok, msg);
    }

    try {
      if (await _ch.invokeMethod<bool>('getFlag', {'k': 'done_$campaignId'}) == true) {
        return await _ch.invokeMethod<bool>('getFlag', {'k': 'confirmed_$campaignId'}) == true;
      }
      final tries = (await _ch.invokeMethod<int>('getInt', {'k': 'tries_$campaignId'})) ?? 0;
      if (tries >= 30) return false;
      await _ch.invokeMethod('setInt', {'k': 'tries_$campaignId', 'v': tries + 1});

      // 1. Google Play install referrer
      String? raw;
      try {
        raw = await _ch.invokeMethod<String>('installReferrer');
      } on PlatformException {
        raw = null;
      }
      var found = raw == null ? null : _fromQuery(raw, campaignId);

      // 2. Clipboard code (apps installed outside Google Play). Only the first launches are checked.
      if (found == null && useClipboard && tries < 3) {
        await Future<void>.delayed(const Duration(milliseconds: 1500)); // the app must be in the foreground
        try {
          final data = await Clipboard.getData(Clipboard.kTextPlain);
          final m = _clip.firstMatch((data?.text ?? '').trim());
          if (m != null && m.group(3) == '$campaignId') {
            found = _Found(m.group(1)!, m.group(2)!);
          }
        } catch (_) {}
      }

      if (found == null) {
        if (raw != null) {
          await _ch.invokeMethod('setFlag', {'k': 'done_$campaignId', 'v': true});
          done(false, 'No TomatoCoin campaign information found for this install');
        }
        return false;
      }
      return await _send(base, campaignId, publicKey, found, done);
    } catch (e) {
      done(false, 'TomatoCoin SDK error: $e');
      return false;
    }
  }

  /// Confirms an install manually when you received the member id and token yourself.
  static Future<bool> confirm({
    required String site,
    required int campaignId,
    required String publicKey,
    required String uid,
    required String token,
  }) async {
    if (!_uid.hasMatch(uid) || !_tok.hasMatch(token)) return false;
    return _send(site.trim().replaceAll(RegExp(r'/+$'), ''), campaignId, publicKey, _Found(uid, token), (_, __) {});
  }

  static _Found? _fromQuery(String query, int campaignId) {
    try {
      final p = Uri.splitQueryString(query);
      final uid = p['eh_uid'], tok = p['eh_t'], cid = p['eh_c'];
      if (uid != null && tok != null && _uid.hasMatch(uid) && _tok.hasMatch(tok) && (cid == null || cid == '$campaignId')) {
        return _Found(uid, tok);
      }
    } catch (_) {}
    return null;
  }

  static Future<bool> _send(String base, int cid, String key, _Found f, void Function(bool, String) done) async {
    for (var attempt = 0; attempt < 4; attempt++) {
      final res = await _post(base, cid, key, f);
      if (res == null) {
        done(false, 'Network error. The SDK will try again the next time the app starts.');
        return false;
      }
      if (res['ok'] == true) {
        await _ch.invokeMethod('setFlag', {'k': 'confirmed_$cid', 'v': true});
        await _ch.invokeMethod('setFlag', {'k': 'done_$cid', 'v': true});
        done(true, 'Install confirmed');
        return true;
      }
      final err = '${res['error'] ?? 'Rejected'}';
      if (err == 'too early') {
        await Future<void>.delayed(const Duration(seconds: 15));
        continue;
      }
      await _ch.invokeMethod('setFlag', {'k': 'done_$cid', 'v': true});
      final already = err == 'already counted';
      if (already) await _ch.invokeMethod('setFlag', {'k': 'confirmed_$cid', 'v': true});
      done(already, err);
      return already;
    }
    done(false, 'Not accepted yet. The SDK will try again the next time the app starts.');
    return false;
  }

  static Future<Map<String, dynamic>?> _post(String base, int cid, String key, _Found f) async {
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 10);
    try {
      final req = await client.postUrl(Uri.parse('$base/track.php'));
      req.headers.contentType = ContentType('application', 'x-www-form-urlencoded', charset: 'utf-8');
      req.write(Uri(queryParameters: {
        'a': 'install',
        'c': '$cid',
        'key': key,
        'uid': f.uid,
        't': f.token,
        'v': sdkVersion,
      }).query);
      final res = await req.close().timeout(const Duration(seconds: 15));
      final body = await res.transform(utf8.decoder).join();
      final j = jsonDecode(body);
      return j is Map<String, dynamic> ? j : <String, dynamic>{'ok': false, 'error': 'Rejected'};
    } catch (_) {
      return null;
    } finally {
      client.close(force: true);
    }
  }
}

class _Found {
  _Found(this.uid, this.token);
  final String uid;
  final String token;
}
