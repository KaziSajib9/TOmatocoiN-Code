import 'package:tomatocoin_sdk/tomatocoin_sdk.dart';
import 'package:flutter/material.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});
  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  void initState() {
    super.initState();
    // Replace with the values from the Developer Programme > Integration tab
    TomatoCoin.init(
      site: 'https://earn.example.com',
      campaignId: 12,
      publicKey: 'YOUR_PUBLIC_KEY',
      onResult: (ok, message) => debugPrint('TomatoCoin: $ok $message'),
    );
  }

  @override
  Widget build(BuildContext context) => const MaterialApp(home: Scaffold(body: Center(child: Text('Hello'))));
}
