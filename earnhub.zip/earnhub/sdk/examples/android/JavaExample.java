package com.example.myapp;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.tomatocoin.sdk.TomatoCoin;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Values from Developer Programme > Integration
        TomatoCoin.init(this, "https://earn.example.com", 12, "YOUR_PUBLIC_KEY");

        // Optional: if you open the app from a link that carries eh_uid and eh_t
        TomatoCoin.handleIntent(this, getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        TomatoCoin.handleIntent(this, intent);
    }
}
