# TOmatocoiN SDK

Confirms app installs for TOmatocoiN campaigns, for Android (Kotlin, Java) and Flutter.
Website campaigns use the `track.js` script instead, and Telegram bot / Mini App campaigns use a small
snippet from your Developer dashboard. This repository is only for app installs.

Replace `OWNER/REPO` below with the GitHub address of this repository and `TAG` with a release, for example `v1.0.0`.

## Android (Kotlin and Java)

### Option A. From GitHub with JitPack (no download)

1. In `settings.gradle` (or `settings.gradle.kts`) add JitPack to the repositories:

```gradle
dependencyResolutionManagement {
    repositories {
        google()
        mavenCentral()
        maven { url 'https://jitpack.io' }   // Kotlin DSL: maven("https://jitpack.io")
    }
}
```

2. In `app/build.gradle` add the dependency:

```gradle
dependencies {
    implementation 'com.github.OWNER.REPO:tomatocoin-sdk:TAG'
}
```

(Open https://jitpack.io, paste `OWNER/REPO`, press **Get it** on the tag. The page shows the exact line.)

### Option B. Download the zip

Download `tomatocoin-android-sdk-TAG.zip` from the **Releases** page of this repository (or from the Developer
Programme > Integration page). Unzip it, copy the folder `tomatocoin-sdk` into your project, then:

```gradle
// settings.gradle
include ':tomatocoin-sdk'
// app/build.gradle
dependencies { implementation project(':tomatocoin-sdk') }
```

### Use it

Kotlin:

```kotlin
TomatoCoin.init(this, "https://YOUR-SITE", CAMPAIGN_ID, "PUBLIC_KEY")
```

Java:

```java
TomatoCoin.init(this, "https://YOUR-SITE", CAMPAIGN_ID, "PUBLIC_KEY");
```

Use the values from **Developer Programme > Integration**. Call it once, in your first `Activity.onCreate`.
Full examples are in `examples/android`.

## Flutter

### Option A. From GitHub (no download)

```yaml
dependencies:
  tomatocoin_sdk:
    git:
      url: https://github.com/OWNER/REPO.git
      path: flutter/tomatocoin_sdk
      ref: TAG
```

### Option B. Download the zip

Download `tomatocoin-flutter-sdk-TAG.zip` from the Releases page, unzip it next to your project and use:

```yaml
dependencies:
  tomatocoin_sdk:
    path: ../tomatocoin_sdk-TAG
```

### Use it

```dart
import 'package:tomatocoin_sdk/tomatocoin_sdk.dart';

await TomatoCoin.init(site: 'https://YOUR-SITE', campaignId: CAMPAIGN_ID, publicKey: 'PUBLIC_KEY');
```

## Layout of this repository

* `tomatocoin-sdk/` Android library (Java, works from Kotlin)
* `flutter/tomatocoin_sdk/` Flutter plugin (Android)
* `examples/` Kotlin, Java and Dart examples
* `jitpack.yml` build file for JitPack
* `.github/workflows/release.yml` builds the zips and attaches them to every release

MIT licence.
