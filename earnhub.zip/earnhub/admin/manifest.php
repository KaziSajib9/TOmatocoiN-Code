<?php require __DIR__.'/../inc/core.php'; header('Content-Type: application/manifest+json');
$i=function($k,$s){return ['src'=>'../'.brand($k),'sizes'=>$s.'x'.$s,'type'=>'image/png','purpose'=>'any'];};
echo json_encode(['name'=>setting('site_name','TOmatocoiN').' Admin','short_name'=>'Admin','description'=>'Admin console','start_url'=>'./','scope'=>'./','display'=>'standalone','background_color'=>'#0B1220','theme_color'=>'#0B1220',
 'icons'=>[$i('a192',192),$i('a512',512)],'shortcuts'=>[['name'=>'Withdrawals','url'=>'./?p=wd','icons'=>[$i('a192',192)]],['name'=>'Help desk','url'=>'./?p=help','icons'=>[$i('a192',192)]],['name'=>'Users','url'=>'./?p=users','icons'=>[$i('a192',192)]],['name'=>'Dashboard','url'=>'./','icons'=>[$i('a192',192)]]]],JSON_UNESCAPED_SLASHES);
