<?php require __DIR__.'/inc.php'; csrf_check();
if(isset($_GET['out'])){session_destroy();header('Location: ./');exit;}
if(empty($_SESSION['a'])){$err='';
 if($P){usleep(600000);$a=q('SELECT * FROM te_admins WHERE username=?',[(string)($_POST['u']??'')])->fetch();
  if($a&&password_verify((string)($_POST['p']??''),$a['pass_hash'])){session_regenerate_id(true);$_SESSION['a']=$a['username'];header('Location: ./');exit;}$err='Wrong username or password';}
 echo head_html('Sign in'); ?><body class="login"><form method="post" class="box"><img class="lgi big" src="../<?=brand('admin_logo')?>" alt=""><h1>Admin sign in</h1><p class="mu"><?=e(setting('site_name','TOmatocoiN'))?> console</p>
<?php if($err) echo '<div class="err">'.e($err).'</div>'; echo $tok; ?><label>Username<input name="u" required autofocus autocomplete="username"></label><label>Password<input name="p" type="password" required autocomplete="current-password"></label><button>Sign in</button></form><script src="admin.js?v=<?=(int)@filemtime(__DIR__.'/admin.js')?>"></script></body></html><?php exit;}
$pg=$_GET['p']??'dash'; if(!in_array($pg,['dash','users','user','tasks','wd','risk','ads','lv','notices','help','ticket','brand','set','demo','devices','devs'],true))$pg='dash';
require __DIR__.'/pages/'.$pg.'.php';
