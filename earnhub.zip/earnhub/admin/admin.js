const $=s=>document.querySelector(s);
if('serviceWorker' in navigator)navigator.serviceWorker.register('sw.js').catch(()=>{});
let dp=null;window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();dp=e;const b=$('#inst');if(b)b.hidden=false});
$('#inst')?.addEventListener('click',async()=>{if(!dp)return;dp.prompt();await dp.userChoice;dp=null;$('#inst').hidden=true});
$('#mb')?.addEventListener('click',()=>document.body.classList.toggle('so'));$('#ov')?.addEventListener('click',()=>document.body.classList.remove('so'));
function beep(){try{const c=new (window.AudioContext||window.webkitAudioContext)(),o=c.createOscillator(),g=c.createGain();o.connect(g);g.connect(c.destination);o.frequency.value=880;g.gain.setValueAtTime(.15,c.currentTime);g.gain.exponentialRampToValueAtTime(.001,c.currentTime+.4);o.start();o.stop(c.currentTime+.4)}catch{}}
const vap=document.querySelector('meta[name=vapid]')?.content||'',csrf=document.querySelector('meta[name=csrf]')?.content||'';
const u8=s=>{const b=atob((s+'='.repeat((4-s.length%4)%4)).replace(/-/g,'+').replace(/_/g,'/'));return Uint8Array.from(b,c=>c.charCodeAt(0))};
async function pushOn(){
 if(!('serviceWorker' in navigator&&'PushManager' in window&&'Notification' in window))return alert('This browser does not support push notifications. On iPhone or iPad, first add this app to your Home Screen (iOS 16.4 or newer) and open it from there.');
 if(!vap)return alert('Push keys could not be created on this server (OpenSSL EC support is needed).');
 const p=await Notification.requestPermission();if(p!=='granted')return alert('Notifications are blocked. Please allow them in your browser or app settings, then try again.');
 try{const reg=await navigator.serviceWorker.ready;let sub=await reg.pushManager.getSubscription();if(!sub)sub=await reg.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:u8(vap)});
  const r=await fetch('push.php?a=sub',{method:'POST',headers:{'Content-Type':'application/json','X-CSRF':csrf},body:JSON.stringify(sub)});const d=await r.json();
  if(d.ok){localStorage.setItem('pushsub','1');alert('Push notifications are ON for this device. You will get alerts for new users, withdrawal requests and help desk messages even when the app is closed.');location.reload()}else alert(d.error||'Could not save the subscription')}
 catch(e){alert('Could not turn on push: '+(e&&e.message||e))}}
$('#nbtn')?.addEventListener('click',pushOn);
(async()=>{try{if('serviceWorker' in navigator&&'PushManager' in window&&Notification.permission==='granted'){const r=await navigator.serviceWorker.ready;const s=await r.pushManager.getSubscription();if(s){localStorage.setItem('pushsub','1');$('#nbtn')?.classList.add('on')}else localStorage.removeItem('pushsub')}}catch{}})();
async function note(t,b,url){beep();if('Notification' in window&&Notification.permission==='granted'){const r=await navigator.serviceWorker?.ready;if(r)r.showNotification(t,{body:b,icon:'icons/icon-192.png',badge:'icons/icon-192.png',data:{url}})}}
let st=null;try{st=JSON.parse(localStorage.getItem('adm_st')||'null')}catch{}
async function poll(){if(!$('#sb'))return;try{const d=await (await fetch('live.php',{cache:'no-store'})).json();if(d.error)return;
 document.querySelectorAll('.livec').forEach(e=>e.textContent=d.live);const wb=$('#wdb');if(wb){wb.textContent=d.open;wb.hidden=!d.open}const db=$('#dvb');if(db){db.textContent=d.dv_pen;db.hidden=!d.dv_pen}const hb=$('#hlb');if(hb){hb.textContent=d.help_open;hb.hidden=!d.help_open}
 const pushed=localStorage.getItem('pushsub')==='1';
 if(st&&!pushed){if(d.users>st.users)note('New user joined',(d.users-st.users)+' new user(s). Total: '+d.users,'?p=users');if(d.wd_max>st.wd_max)note('New withdrawal request',d.last,'?p=wd');if(d.tk_max>st.tk_max)note('Help desk','A user sent a new message','?p=help');if(st.dv_n!=null&&d.dv_n>st.dv_n)note('Developer Programme','New developer, deposit or campaign to review ('+d.dv_pen+' waiting)','?p=devs')}
 st={users:d.users,wd_max:d.wd_max,tk_max:d.tk_max,dv_n:d.dv_n};try{localStorage.setItem('adm_st',JSON.stringify(st))}catch{}}catch{}}
poll();setInterval(poll,20000);
