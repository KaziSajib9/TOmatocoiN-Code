<?php require __DIR__.'/inc.php';header('Content-Type: application/json');
if(empty($_SESSION['a'])){http_response_code(401);echo '{"error":"Not signed in"}';exit;}
if(!hash_equals($T,(string)($_SERVER['HTTP_X_CSRF']??''))){http_response_code(419);echo '{"error":"Bad token, reload the page"}';exit;}
$j=json_decode((string)file_get_contents('php://input'),true);
if(($_GET['a']??'')==='sub'&&is_array($j)&&!empty($j['endpoint'])&&!empty($j['keys']['p256dh'])&&!empty($j['keys']['auth'])){
 if(strpos((string)$j['endpoint'],'https://')!==0){echo '{"error":"Invalid endpoint"}';exit;}
 q('INSERT INTO te_push (h,endpoint,p256dh,auth,admin,ua) VALUES (?,?,?,?,?,?) ON DUPLICATE KEY UPDATE p256dh=VALUES(p256dh),auth=VALUES(auth),admin=VALUES(admin),ua=VALUES(ua)',[sha1((string)$j['endpoint']),$j['endpoint'],$j['keys']['p256dh'],$j['keys']['auth'],$_SESSION['a'],mb_substr((string)($_SERVER['HTTP_USER_AGENT']??''),0,120)]);
 echo '{"ok":true}';exit;}
echo '{"error":"Bad request"}';
