<?php if($P&&($_POST['do']??'')==='hset'){q('INSERT INTO te_settings (k,v) VALUES (?,?) ON DUPLICATE KEY UPDATE v=VALUES(v)',['help_img_on',isset($_POST['help_img_on'])?'1':'0']);redir('Saved','?p=help');}
top('Help desk','help');
$st=$_GET['s']??'Open';$TB=['Open'=>'Waiting for support','Answered'=>'Answered','Closed'=>'Closed','All'=>'All'];if(!isset($TB[$st]))$st='Open';
$cn=[];foreach(q('SELECT status,COUNT(*) c FROM te_tickets GROUP BY status') as $r)$cn[$r['status']]=(int)$r['c'];
echo '<div class="f" style="margin-bottom:14px">';foreach($TB as $k=>$l){$c=$k==='All'?array_sum($cn):($cn[$k]??0);echo '<a class="b '.($k===$st?'':'gh').'" href="?p=help&s='.$k.'">'.$l.' ('.$c.')</a>';}
echo '</div><div class="c sc"><table><tr><th>#</th><th>User</th><th>Rank</th><th>Reason</th><th>Withdrawal</th><th>Latest message</th><th>Status</th><th>Updated</th><th></th></tr>';
$sql='SELECT t.*,u.name,u.avatar,u.photo,w.amount wamt,w.status wst,(SELECT COUNT(*)+1 FROM te_users x WHERE x.banned=0 AND x.total>u.total) rk,(SELECT body FROM te_tmsg m WHERE m.ticket_id=t.id ORDER BY m.id DESC LIMIT 1) last
 FROM te_tickets t LEFT JOIN te_users u ON u.tg_id=t.tg_id LEFT JOIN te_wd w ON w.id=t.wd_id '.($st==='All'?'':'WHERE t.status=? ').'ORDER BY (t.status=\'Open\') DESC,t.updated_at DESC LIMIT 100';
foreach($st==='All'?q($sql):q($sql,[$st]) as $r)
 echo '<tr><td><b>#'.$r['id'].'</b></td><td>'.ulink($r,36).'</td><td><b>#'.(int)$r['rk'].'</b></td><td>'.e($r['reason']==='Others'&&$r['custom']?'Others: '.$r['custom']:$r['reason']).'</td><td>'.($r['wd_id']?'#'.(int)$r['wd_id'].'<br><small class="mu">'.number_format((float)$r['wamt']).' pts · '.e($r['wst']).'</small>':'<span class="mu">-</span>').'</td>
 <td style="max-width:260px"><small>'.e(mb_substr((string)$r['last'],0,110)).'</small></td><td><span class="tag '.e($r['status']).'">'.($r['status']==='Open'?'Waiting':e($r['status'])).'</span></td><td><small>'.e($r['updated_at']).'</small></td><td><a class="b" href="?p=ticket&id='.$r['id'].'">Open</a></td></tr>';
echo '</table></div>';
echo '<div class="c"><h2>Help desk settings</h2><form method="post" class="f">'.$tok.'<input type="hidden" name="do" value="hset"><label class="ck"><input type="checkbox" name="help_img_on"'.(setting('help_img_on','1')==='1'?' checked':'').'><span>Let users attach a screenshot to a ticket (images are shrunk to 1280 px and stored in <code>uploads/help</code>)</span></label><button>Save</button></form></div>';bot();
