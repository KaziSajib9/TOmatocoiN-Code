<?php $tid=(int)($_GET['id']??0);
if($P){$d=$_POST['do']??'';$id=(int)($_POST['id']??0);$t=q('SELECT * FROM te_tickets WHERE id=?',[$id])->fetch();
 if($t&&$d==='treply'){$body=mb_substr(trim((string)$_POST['body']),0,1500);if($body==='')redir('Write a reply first','?p=ticket&id='.$id);
  q("INSERT INTO te_tmsg (ticket_id,sender,body) VALUES (?,'admin',?)",[$id,$body]);q('UPDATE te_tickets SET status=?,updated_at=NOW() WHERE id=?',[isset($_POST['close'])?'Closed':'Answered',$id]);
  q('INSERT INTO te_notices (tg_id,title,body) VALUES (?,?,?)',[$t['tg_id'],'Support replied to ticket #'.$id,mb_substr($body,0,600)]);
  if(isset($_POST['tgdm']))tg('sendMessage',['chat_id'=>$t['tg_id'],'text'=>"Support replied to your ticket #$id:\n\n".$body]);
  redir('Reply sent','?p=ticket&id='.$id);}
 if($t&&$d==='tstatus'){q('UPDATE te_tickets SET status=?,updated_at=NOW() WHERE id=?',[($_POST['to']??'')==='Closed'?'Closed':'Open',$id]);redir('Ticket updated','?p=ticket&id='.$id);}
 redir('Ticket not found','?p=help');}
$t=q('SELECT t.*,u.name,u.avatar,u.photo,u.level,u.email_ok,u.balance,(SELECT COUNT(*)+1 FROM te_users x WHERE x.banned=0 AND x.total>u.total) rk FROM te_tickets t LEFT JOIN te_users u ON u.tg_id=t.tg_id WHERE t.id=?',[$tid])->fetch();
top('Ticket #'.$tid,'help');if(!$t){echo '<div class="c">Ticket not found. <a href="?p=help">Back</a></div>';bot();exit;}
$w=$t['wd_id']?q('SELECT * FROM te_wd WHERE id=?',[$t['wd_id']])->fetch():null;
echo '<div class="g3"><div class="c"><div class="hd">'.av_html($t,52).'<div><h2 style="font-size:17px">'.e($t['name']).'</h2><div class="mu">ID '.$t['tg_id'].'</div><div style="margin-top:4px;display:flex;gap:6px;flex-wrap:wrap"><span class="tag bl">Rank #'.(int)$t['rk'].'</span><span class="tag">Level '.(int)$t['level'].'</span>'.($t['email_ok']?'<span class="tag on">Verified</span>':'<span class="tag">Not verified</span>').'</div></div></div>
 <p style="margin-top:12px"><a class="b gh" href="?p=user&id='.$t['tg_id'].'">View user details</a></p></div>
 <div class="c"><h2>Ticket</h2><div class="sg"><div><small>Reason</small><b style="font-size:14px">'.e($t['reason']==='Others'&&$t['custom']?'Others: '.$t['custom']:$t['reason']).'</b></div><div><small>Status</small><b><span class="tag '.e($t['status']).'">'.e($t['status']).'</span></b></div><div><small>Opened</small><b style="font-size:13px">'.e($t['created_at']).'</b></div>'
 .($w?'<div><small>Related withdrawal #'.$w['id'].'</small><b style="font-size:13px">'.number_format((float)$w['amount']).' pts · '.e($w['status']).'</b></div>':'').'</div>'.($w?'<p class="mu" style="margin-top:8px;word-break:break-all">'.e($w['number']).'</p>':'').'</div></div>';
echo '<div class="c"><h2>Conversation</h2><div class="th">';
foreach(q('SELECT * FROM te_tmsg WHERE ticket_id=? ORDER BY id',[$tid]) as $m)echo '<div class="m '.($m['sender']==='admin'?'admin':'').'"><p>'.e($m['body']).'</p>'.(!empty($m['img'])&&preg_match('/^[a-f0-9]{20}\.jpg$/',$m['img'])?'<a href="../uploads/help/'.e($m['img']).'" target="_blank" rel="noopener"><img src="../uploads/help/'.e($m['img']).'" alt="Screenshot" style="max-width:100%;max-height:260px;border-radius:10px;margin-top:6px;display:block"></a>':'').'<small>'.($m['sender']==='admin'?'You':e($t['name'])).' · '.e($m['created_at']).'</small></div>';
echo '</div></div><div class="c"><h2>Reply</h2><form method="post" class="fm" style="max-width:none">'.$tok.'<input type="hidden" name="do" value="treply"><input type="hidden" name="id" value="'.$tid.'"><label>Message<textarea name="body" rows="4" maxlength="1500" required></textarea></label>
 <label class="ck"><input type="checkbox" name="tgdm" checked> Also send as a Telegram message</label><label class="ck"><input type="checkbox" name="close"> Close the ticket after replying</label><div class="f"><button>Send reply</button></div></form>
 <div class="f" style="margin-top:12px">'.($t['status']==='Closed'?F('tstatus','<input type="hidden" name="id" value="'.$tid.'"><input type="hidden" name="to" value="Open">','Reopen ticket','gh'):F('tstatus','<input type="hidden" name="id" value="'.$tid.'"><input type="hidden" name="to" value="Closed">','Close ticket','gh')).'</div></div>';
bot();
