<?php top('Users','users');
$s=trim((string)($_GET['s']??''));$l='%'.$s.'%';
$so=['new'=>'u.created_at DESC','ads'=>'(COALESCE(a.n,0)+COALESCE(a.i,0)+COALESCE(a.t,0)) DESC','earn'=>'u.total DESC','seen'=>'u.last_seen DESC'];$sk=isset($so[$_GET['o']??''])?$_GET['o']:'new';
$il=(int)setting('int_limit','5');$tl=(int)setting('ag_task_limit','5');
echo '<form class="c f"><input type="hidden" name="p" value="users"><label>Search<input name="s" value="'.e($s).'" placeholder="Name or Telegram ID"></label><label>Sort<select name="o">';
foreach(['new'=>'Newest','ads'=>'Most ads today','earn'=>'Top earners','seen'=>'Recently active'] as $k=>$t)echo '<option value="'.$k.'"'.($sk===$k?' selected':'').'>'.$t.'</option>';
echo '</select></label><button>Apply</button></form><div class="c sc"><table><tr><th>User</th><th>Rank</th><th>Level</th><th>Reward ads</th><th>Interstitial</th><th>Sponsored</th><th>Withdrawals</th><th>Balance</th><th>Earned</th><th>Status</th></tr>';
$pc=function($n,$lim){$f=$lim>0&&$n>=$lim;return '<span class="tag'.($f?' on':'').'">'.(int)$n.' / '.(int)$lim.'</span>';};
foreach(q('SELECT u.*,COALESCE(a.n,0) an,COALESCE(a.i,0) ai,COALESCE(a.t,0) tk,COALESCE(l.ad_limit,0) lim,l.int_limit ilim,l.agt_limit tlim,COALESCE(w.req,0) req,COALESCE(w.paid,0) paid,COALESCE(w.rej,0) rej,COALESCE(w.opn,0) opn,(SELECT COUNT(*)+1 FROM te_users x WHERE x.banned=0 AND '.dsql('x.').' AND x.total>u.total) rk
 FROM te_users u LEFT JOIN te_adlog a ON a.tg_id=u.tg_id AND a.d=CURDATE() LEFT JOIN te_levels l ON l.level=u.level
 LEFT JOIN (SELECT tg_id,COUNT(*) req,SUM(status=\'Paid\') paid,SUM(status=\'Rejected\') rej,SUM(status IN (\'Pending\',\'Processing\',\'Verifying\')) opn FROM te_wd GROUP BY tg_id) w ON w.tg_id=u.tg_id
 WHERE u.is_demo=0 AND (u.name LIKE ? OR u.tg_id LIKE ?) ORDER BY '.$so[$sk].' LIMIT 60',[$l,$l]) as $r){
 $live=$r['last_seen']&&strtotime($r['last_seen'])>time()-180;
 echo '<tr><td>'.ulink($r,38).'</td><td><b>#'.(int)$r['rk'].'</b></td><td>'.(int)$r['level'].' <small class="mu">'.tier_name((int)$r['level']).' '.(int)$r['sub'].'</small></td><td>'.$pc($r['an'],$r['lim']).'</td><td>'.$pc($r['ai'],$r['ilim']!==null?$r['ilim']:$il).'</td><td>'.$pc($r['tk'],$r['tlim']!==null?$r['tlim']:$tl).'</td>
 <td><span class="tag gy" title="Requests">'.(int)$r['req'].' req</span> <span class="tag on" title="Paid">'.(int)$r['paid'].' paid</span> <span class="tag off" title="Rejected">'.(int)$r['rej'].' rej</span>'.($r['opn']?' <span class="tag">'.(int)$r['opn'].' open</span>':'').'</td>
 <td>'.number_format((float)$r['balance'],2).'</td><td>'.number_format((float)$r['total'],2).'</td><td>'.($live?'<span class="tag on">Live</span> ':'').($r['email_ok']?'<span class="tag on">Verified</span>':'<span class="tag">Not verified</span>').($r['banned']?' <span class="tag off">Blocked'.($r['ban_until']?' until '.e(substr($r['ban_until'],0,16)):'').'</span>':'').'</td></tr>';}
echo '</table></div>';bot();
