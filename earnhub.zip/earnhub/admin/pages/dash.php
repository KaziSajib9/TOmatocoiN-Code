<?php top('Dashboard','dash');
$n=function($s){return q($s)->fetchColumn();};
$tot=(int)$n('SELECT COUNT(*) FROM te_users WHERE is_demo=0');$new=(int)$n('SELECT COUNT(*) FROM te_users WHERE is_demo=0 AND created_at>=CURDATE()');$live=live_count();$a24=(int)$n('SELECT COUNT(*) FROM te_users WHERE is_demo=0 AND last_seen>=NOW()-INTERVAL 24 HOUR');
$pts=(float)$n('SELECT COALESCE(SUM(balance),0) FROM te_users WHERE is_demo=0');$td=(int)$n('SELECT COUNT(*) FROM te_log WHERE done=1');
$w=[];foreach(q('SELECT status,COUNT(*) c,COALESCE(SUM(amount),0) a,COALESCE(SUM(ton),0) t FROM te_wd GROUP BY status') as $r)$w[$r['status']]=$r;
$open=0;$opp=0;foreach(['Pending','Processing','Verifying'] as $s){$open+=(int)($w[$s]['c']??0);$opp+=(float)($w[$s]['a']??0);}
$ad=q('SELECT COALESCE(SUM(n),0) a,COALESCE(SUM(i),0) b,COALESCE(SUM(t),0) c FROM te_adlog WHERE d=CURDATE()')->fetch();
$k=function($ic,$tn,$lb,$v,$sub='',$cls=''){return '<div class="c k '.$cls.'"><span class="ki '.$tn.'">'.ic($ic).'</span><div><small>'.$lb.'</small><strong>'.$v.'</strong><em>'.$sub.'</em></div></div>';};
echo '<div class="kp">'.$k('live','gr','Live now','<span class="livec">'.$live.'</span>','active in last 3 min','live').$k('users','bl','Total users',number_format($tot),'+'.$new.' today / '.$a24.' active 24h')
 .$k('coin','am','Points in wallets',number_format($pts))
 .$k('wallet','rd','Open withdrawals',$open,number_format($opp).' pts waiting').$k('check','vi','Tasks completed',number_format($td))
 .$k('coin','tl','Paid out (USDT)',rtrim(rtrim(number_format((float)($w['Paid']['t']??0),4),'0'),'.')?:'0',(int)($w['Paid']['c']??0).' payouts').$k('help','am','Open help tickets',(int)$n("SELECT COUNT(*) FROM te_tickets WHERE status='Open'"),'waiting for a reply').'</div>';
$d=[];foreach(q('SELECT DATE(created_at) d,COUNT(*) c FROM te_users WHERE is_demo=0 AND created_at>=CURDATE()-INTERVAL 6 DAY GROUP BY d') as $r)$d[$r['d']]=(int)$r['c'];$mx=max(1,$d?max($d):1);
echo '<div class="g2"><div class="c"><h2>New users, last 7 days</h2><div class="chart">';
for($i=6;$i>=0;$i--){$kk=date('Y-m-d',strtotime("-$i day"));$c=$d[$kk]??0;echo '<div><b>'.$c.'</b><i style="height:'.max(4,(int)($c/$mx*120)).'px"></i><small>'.date('d M',strtotime($kk)).'</small></div>';}
echo '</div></div><div class="c"><h2>Online now</h2>';
$lu=q('SELECT * FROM te_users WHERE is_demo=0 AND last_seen>=NOW()-INTERVAL 3 MINUTE ORDER BY last_seen DESC LIMIT 7')->fetchAll();
if(!$lu)echo '<p class="mu">Nobody is online right now.</p>';else{echo '<div style="display:grid;gap:10px">';foreach($lu as $r)echo ulink($r,32,false);echo '</div>';}
echo '</div></div><div class="g3"><div class="c"><h2>Withdrawal pipeline</h2><div class="pipe"><div class="w"><b>'.(int)($w['Pending']['c']??0).'</b><small>Pending</small></div><div class="w"><b>'.(int)($w['Processing']['c']??0).'</b><small>Processing</small></div><div class="w"><b>'.(int)($w['Verifying']['c']??0).'</b><small>Withdraw Verify</small></div><div class="d"><b>'.(int)($w['Paid']['c']??0).'</b><small>Paid</small></div></div>
 <p class="mu" style="margin-top:10px">Rejected: '.(int)($w['Rejected']['c']??0).'</p></div>';
$mxa=max(1,(int)$ad['a'],(int)$ad['b'],(int)$ad['c']);
echo '<div class="c"><h2>Ads today</h2><div class="mb">';foreach([['Reward ads',$ad['a']],['Interstitial',$ad['b']],['Sponsored tasks',$ad['c']]] as [$l,$v])echo '<div><small><span>'.$l.'</span><b>'.number_format((int)$v).'</b></small><i><u style="width:'.round($v/$mxa*100).'%"></u></i></div>';
echo '</div></div></div><div class="g3"><div class="c"><div class="f" style="justify-content:space-between"><h2>Latest withdrawals</h2><a href="?p=wd">View all</a></div><table>';
foreach(q('SELECT w.*,u.avatar,u.photo FROM te_wd w LEFT JOIN te_users u ON u.tg_id=w.tg_id ORDER BY w.id DESC LIMIT 5') as $r){$r['name']=$r['name'];echo '<tr><td>'.ulink($r,30,false).'</td><td>'.number_format((float)$r['amount']).' pts</td><td><span class="tag '.($r['status']==='Paid'?'on':($r['status']==='Rejected'?'off':'')).'">'.e($r['status']==='Verifying'?'Verify':$r['status']).'</span></td></tr>';}
echo '</table></div><div class="c"><div class="f" style="justify-content:space-between"><h2>Newest users</h2><a href="?p=users">View all</a></div><table>';
foreach(q('SELECT * FROM te_users WHERE is_demo=0 ORDER BY created_at DESC LIMIT 5') as $r)echo '<tr><td>'.ulink($r,30,false).'</td><td class="mu">'.e(substr($r['created_at'],0,16)).'</td></tr>';
echo '</table></div></div>';bot();
