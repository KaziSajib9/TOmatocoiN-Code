<?php if($P&&($_POST['do']??'')==='lv'){
 $st=db()->prepare('INSERT INTO te_levels (level,name,ad_limit,ad_reward,upgrade_cost,rank2_pts,rank3_pts,int_limit,int_reward,agt_limit,agt_reward,task_pct,bonus) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE name=VALUES(name),ad_limit=VALUES(ad_limit),ad_reward=VALUES(ad_reward),upgrade_cost=VALUES(upgrade_cost),rank2_pts=VALUES(rank2_pts),rank3_pts=VALUES(rank3_pts),int_limit=VALUES(int_limit),int_reward=VALUES(int_reward),agt_limit=VALUES(agt_limit),agt_reward=VALUES(agt_reward),task_pct=VALUES(task_pct),bonus=VALUES(bonus)');
 $ex=array_map('strval',q('SELECT level FROM te_levels')->fetchAll(PDO::FETCH_COLUMN));$nn=function($v){$v=trim((string)$v);return $v===''?null:max(0,(float)$v);};
 $in=(array)($_POST['lv']??[]);ksort($in,SORT_NUMERIC);$prev=0;
 foreach($in as $l=>$v){$l=(int)$l;if($l<1)continue;if(!in_array((string)$l,$ex,true)&&trim((string)($v['ad_limit']??''))==='')continue;
  $n1=$l===1?0:max($prev,(float)($nn($v['upgrade_cost']??'')??0));$r2=$nn($v['rank2_pts']??'');$r3=$nn($v['rank3_pts']??'');
  $n2=max($n1,$r2===null?$n1+500:$r2);$n3=max($n2,$r3===null?$n2+500:$r3);$prev=$n3;
  $il=$nn($v['int_limit']??'');$al=$nn($v['agt_limit']??'');$nm=mb_substr(trim((string)($v['name']??'')),0,30);
  $st->execute([$l,$nm!==''?$nm:null,(int)max(0,(float)($v['ad_limit']??0)),max(0,(float)($v['ad_reward']??0)),(int)$n1,(int)$n2,(int)$n3,$il===null?null:(int)$il,$nn($v['int_reward']??''),$al===null?null:(int)$al,$nn($v['agt_reward']??''),trim((string)($v['task_pct']??''))===''?100:(int)max(0,(float)$v['task_pct']),$nn($v['bonus']??'')]);}
 redir('Levels saved. Users move up automatically when they reach the points you set.','?p=lv');}
top('Levels','lv');echo lvForm($tok);bot();
