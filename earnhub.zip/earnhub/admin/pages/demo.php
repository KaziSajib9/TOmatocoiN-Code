<?php
$NAMES=['Alex','Maria','Ravi','Omar','Liam','Sofia','Chen','Anna','Ivan','Fatima','Noah','Mina','Leo','Aisha','Karim','Julia','Hugo','Nadia','Sam','Lina','Tariq','Emma','Diego','Yuki','Zara','Ali','Eva','Max','Rina','Adam'];
$norm=function(array $p){$tot=max(0,round((float)($p['total']??0),2));$bal=max(0,round((float)($p['balance']??0),2));
 if(!empty($p['auto'])||(int)($p['level']??0)<1){[$lv,$sb]=level_for_total($tot);}else{$lv=max(1,(int)$p['level']);$sb=min(3,max(1,(int)($p['sub']??1)));}
 return [$tot,$bal,$lv,$sb];};
if($P){$d=$_POST['do']??'';$m='Done';
 if($d==='d_add'){$nm=mb_substr(trim((string)($_POST['name']??'')),0,60);if($nm==='')redir('Enter a name','?p=demo');
  [$tot,$bal,$lv,$sb]=$norm($_POST);$days=max(0,min(365,(int)($_POST['days']??0)));$av=preg_match('/^p[1-8]$/',(string)($_POST['avatar']??''))?$_POST['avatar']:'p'.random_int(1,8);
  q('INSERT INTO te_users (tg_id,name,balance,total,level,sub,avatar,is_demo,created_at,last_seen) VALUES (?,?,?,?,?,?,?,1,NOW()-INTERVAL ? DAY,NULL)',[new_demo_id(),$nm,$bal,$tot,$lv,$sb,$av,$days]);$m='Demo user added';}
 elseif($d==='d_gen'){$n=max(1,min(50,(int)($_POST['n']??10)));$a=max(0,(float)($_POST['min']??0));$b=max($a,(float)($_POST['max']??1000));
  for($i=0;$i<$n;$i++){$tot=round($a+lcg_value()*($b-$a),2);[$lv,$sb]=level_for_total($tot);$bal=round($tot*lcg_value()*.4,2);
   q('INSERT INTO te_users (tg_id,name,balance,total,level,sub,avatar,is_demo,created_at) VALUES (?,?,?,?,?,?,?,1,NOW()-INTERVAL ? DAY)',[new_demo_id(),$NAMES[array_rand($NAMES)].' '.chr(random_int(65,90)).'.',$bal,$tot,$lv,$sb,'p'.random_int(1,8),random_int(0,30)]);}
  $m=$n.' demo users created';}
 elseif($d==='d_save'){$id=(int)$_POST['id'];$nm=mb_substr(trim((string)($_POST['name']??'')),0,60);if($nm==='')redir('Enter a name','?p=demo');
  [$tot,$bal,$lv,$sb]=$norm($_POST);q('UPDATE te_users SET name=?,balance=?,total=?,level=?,sub=? WHERE tg_id=? AND is_demo=1',[$nm,$bal,$tot,$lv,$sb,$id]);$m='Saved';}
 elseif($d==='d_del'){q('DELETE FROM te_users WHERE tg_id=? AND is_demo=1',[(int)$_POST['id']]);$m='Deleted';}
 elseif($d==='d_all'){q('DELETE FROM te_users WHERE is_demo=1');$m='All demo users deleted';}
 elseif($d==='d_lb'){q("INSERT INTO te_settings (k,v) VALUES ('demo_lb',?) ON DUPLICATE KEY UPDATE v=VALUES(v)",[!empty($_POST['on'])?'1':'0']);$m='Saved';}
 redir($m,'?p=demo');}
top('Demo users','demo');
$on=setting('demo_lb','0')==='1';$cnt=(int)q('SELECT COUNT(*) FROM te_users WHERE is_demo=1')->fetchColumn();
echo '<div class="c"><h2>About demo users</h2><p class="mu">Demo users are <b>test accounts for you</b>. Use them to check the leaderboard, levels and ranks. They are <b>not counted</b> in your user totals, live count, payouts or notifications, and they cannot log in or withdraw. By default real users <b>cannot see them</b>. If you turn on the option below, they appear in the leaderboard with a visible <b>Demo</b> label, so nobody is misled.</p>
 <form method="post" class="f" style="margin-top:10px">'.$tok.'<input type="hidden" name="do" value="d_lb"><label style="flex-direction:row;gap:8px;align-items:center"><input type="checkbox" name="on" value="1"'.($on?' checked':'').' style="width:auto"> Show demo users in the user leaderboard (labelled "Demo")</label><button>Save</button></form></div>';
echo '<div class="g2"><div class="c"><h2>Add one demo user</h2><form method="post" class="f">'.$tok.'<input type="hidden" name="do" value="d_add">
 <label>Name<input name="name" required maxlength="60"></label><label>Total earned<input name="total" type="number" step="any" min="0" value="0" style="width:110px"></label><label>Balance<input name="balance" type="number" step="any" min="0" value="0" style="width:110px"></label>
 <label>Joined (days ago)<input name="days" type="number" min="0" max="365" value="0" style="width:90px"></label><label>Level<input name="level" type="number" min="1" placeholder="auto" style="width:80px"></label><label>Rank (1-3)<input name="sub" type="number" min="1" max="3" value="1" style="width:80px"></label>
 <label style="flex-direction:row;gap:8px;align-items:center"><input type="checkbox" name="auto" value="1" checked style="width:auto"> Level and rank automatically from total</label><button>Add</button></form></div>
 <div class="c"><h2>Generate several</h2><form method="post" class="f">'.$tok.'<input type="hidden" name="do" value="d_gen"><label>How many (1-50)<input name="n" type="number" min="1" max="50" value="10" style="width:90px"></label>
 <label>Total earned from<input name="min" type="number" min="0" value="0" style="width:110px"></label><label>to<input name="max" type="number" min="0" value="1000" style="width:110px"></label><button>Generate</button></form></div></div>';
echo '<div class="c sc"><div class="f" style="justify-content:space-between"><h2>Demo users ('.$cnt.')</h2>'.($cnt?F('d_all','','Delete all demo users','bad'):'').'</div><table><tr><th>User</th><th>Total earned</th><th>Balance</th><th>Level / rank</th><th></th></tr>';
foreach(q('SELECT * FROM te_users WHERE is_demo=1 ORDER BY total DESC LIMIT 200') as $r){$fm=' form="s'.(int)$r['tg_id'].'"';
 echo '<tr><td>'.av_html($r,30).' <input name="name" value="'.e($r['name']).'" maxlength="60" style="width:130px"'.$fm.'> <span class="tag dm">Demo</span></td>
 <td><input name="total" type="number" step="any" min="0" value="'.e($r['total']).'" style="width:100px"'.$fm.'></td><td><input name="balance" type="number" step="any" min="0" value="'.e($r['balance']).'" style="width:100px"'.$fm.'></td>
 <td><input name="level" type="number" min="1" value="'.(int)$r['level'].'" style="width:60px"'.$fm.'> / <input name="sub" type="number" min="1" max="3" value="'.(int)$r['sub'].'" style="width:50px"'.$fm.'> <small class="mu">'.e(tier_name((int)$r['level'])).'</small></td>
 <td class="f"><form method="post" id="s'.(int)$r['tg_id'].'">'.$tok.'<input type="hidden" name="do" value="d_save"><input type="hidden" name="id" value="'.$r['tg_id'].'"><button>Save</button></form>'.F('d_del','<input type="hidden" name="id" value="'.$r['tg_id'].'">','Delete','bad').'</td></tr>';}
if(!$cnt)echo '<tr><td colspan="5" class="mu">No demo users yet.</td></tr>';
echo '</table></div>';bot();
