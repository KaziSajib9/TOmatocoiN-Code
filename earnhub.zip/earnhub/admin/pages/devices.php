<?php top('Devices','devices');
$grp=function(string $col,string $key,int $lim){return q("SELECT d.$col k,COUNT(DISTINCT d.tg_id) n,COUNT(DISTINCT d.dev) dv,MAX(d.last_seen) ls FROM te_devices d JOIN te_users u ON u.tg_id=d.tg_id AND u.is_demo=0 WHERE d.$col IS NOT NULL GROUP BY d.$col HAVING n>1 ORDER BY n DESC,ls DESC LIMIT $lim")->fetchAll();};
$members=function(string $col,string $v){return q("SELECT DISTINCT u.* FROM te_devices d JOIN te_users u ON u.tg_id=d.tg_id WHERE d.$col=? AND u.is_demo=0 ORDER BY u.created_at",[$v])->fetchAll();};
$tot=(int)q('SELECT COUNT(DISTINCT tg_id) FROM te_devices')->fetchColumn();$blocked=(int)q('SELECT COUNT(*) FROM te_users WHERE ref_blocked=1 AND is_demo=0')->fetchColumn();
echo '<div class="c"><h2>How device checks work</h2><p class="mu">Each phone gets a random device ID the first time it opens the app. If someone opens a referral link on the <b>same device</b> as the person who invited them, the referral is <b>not counted</b>. Users who share a device are listed below so you can review them. Note: a determined user can clear the app data to get a new ID, so treat this as a strong signal, not a guarantee. '.$tot.' users have a device recorded. Blocked referrals so far: <b>'.$blocked.'</b>.</p></div>';
$A=$grp('dev','dev',100);
echo '<div class="c sc"><h2>Accounts on the same device ('.count($A).')</h2>';
if(!$A)echo '<p class="mu">No shared devices found.</p>';else{echo '<table><tr><th>Device</th><th>Accounts</th><th>Users</th><th>Last seen</th></tr>';
 foreach($A as $g){echo '<tr><td><code>'.e(substr($g['k'],0,8)).'</code></td><td><span class="tag off">'.(int)$g['n'].' accounts</span></td><td><div style="display:flex;flex-wrap:wrap;gap:12px">';
  foreach($members('dev',$g['k']) as $r)echo ulink($r,32).($r['ref_blocked']?'<span class="tag">Referral blocked</span>':'').($r['banned']?'<span class="tag off">Blocked</span>':'');
  echo '</div></td><td class="mu">'.e(substr((string)$g['ls'],0,16)).'</td></tr>';}
 echo '</table>';}
echo '</div>';
$B=$grp('fp','fp',50);
echo '<div class="c sc"><h2>Similar devices ('.count($B).')</h2><p class="mu" style="margin-bottom:8px">Same hardware fingerprint but different device IDs. This can also be different people with the same phone model, so check before taking action.</p>';
if(!$B)echo '<p class="mu">Nothing found.</p>';else{echo '<table><tr><th>Fingerprint</th><th>Accounts</th><th>Users</th></tr>';
 foreach($B as $g){if((int)$g['dv']<2)continue;echo '<tr><td><code>'.e(substr($g['k'],0,8)).'</code></td><td>'.(int)$g['n'].'</td><td><div style="display:flex;flex-wrap:wrap;gap:12px">';foreach($members('fp',$g['k']) as $r)echo ulink($r,32);echo '</div></td></tr>';}
 echo '</table>';}
echo '</div>';
echo '<div class="c sc"><h2>Blocked referrals (latest 30)</h2><table><tr><th>New user</th><th>Joined</th></tr>';
foreach(q('SELECT * FROM te_users WHERE ref_blocked=1 AND is_demo=0 ORDER BY created_at DESC LIMIT 30') as $r)echo '<tr><td>'.ulink($r,32).'</td><td class="mu">'.e(substr($r['created_at'],0,16)).'</td></tr>';
echo '</table></div>';bot();
