<?php top('Risk monitor','risk');
echo '<p class="mu" style="margin-bottom:12px">Automatic checks. A flag is a hint, not proof, so review a user before blocking.</p>';
$T=[['New accounts that already requested a withdrawal (last 2 days)',"SELECT u.*,COUNT(w.id) x FROM te_users u JOIN te_wd w ON w.tg_id=u.tg_id WHERE u.is_demo=0 AND u.created_at>NOW()-INTERVAL 2 DAY AND u.banned=0 GROUP BY u.tg_id ORDER BY u.created_at DESC LIMIT 30",'Requests'],
 ['Heavy farmers: hit the daily reward-ad limit on 5+ of the last 7 days',"SELECT u.*,COUNT(*) x FROM te_adlog a JOIN te_users u ON u.tg_id=a.tg_id JOIN te_levels l ON l.level=u.level WHERE a.d>=CURDATE()-INTERVAL 6 DAY AND l.ad_limit>0 AND a.n>=l.ad_limit AND u.banned=0 GROUP BY u.tg_id HAVING x>=5 ORDER BY x DESC LIMIT 30",'Days at limit'],
 ['Referrers with 10+ new invites in the last 24 hours',"SELECT u.*,COUNT(r.tg_id) x FROM te_users r JOIN te_users u ON u.tg_id=r.ref_by WHERE r.created_at>NOW()-INTERVAL 1 DAY AND u.banned=0 GROUP BY u.tg_id HAVING x>=10 ORDER BY x DESC LIMIT 30",'New invites']];
foreach($T as [$t,$sq,$col]){echo '<div class="c sc"><h2>'.$t.'</h2><table><tr><th>User</th><th>Level</th><th>Earned</th><th>'.$col.'</th><th></th></tr>';
 foreach(q($sq) as $r)echo '<tr><td>'.ulink($r,34).'</td><td>'.(int)$r['level'].'</td><td>'.number_format((float)$r['total']).'</td><td>'.(int)$r['x'].'</td><td><a class="b gh" href="?p=user&id='.$r['tg_id'].'">Review</a></td></tr>';
 echo '</table></div>';}
bot();
