<?php if($P&&($_POST['do']??'')==='wd'){$pdo=db();$pdo->beginTransaction();$r=q('SELECT * FROM te_wd WHERE id=? FOR UPDATE',[(int)$_POST['id']])->fetch();
 $to=['p'=>'Processing','v'=>'Verifying','ok'=>'Paid','no'=>'Rejected'][$_POST['act']??'']??null;
 if($r&&$to&&in_array($r['status'],['Pending','Processing','Verifying'],true)){
  q('UPDATE te_wd SET status=?,note=?,tx=? WHERE id=?',[$to,mb_substr(trim((string)$_POST['note']),0,250),$to==='Paid'?mb_substr(trim((string)$_POST['tx']),0,80):$r['tx'],$r['id']]);
  if($to==='Rejected')q('UPDATE te_users SET balance=balance+? WHERE tg_id=?',[$r['amount'],$r['tg_id']]);
  $pdo->commit();redir('Withdrawal #'.$r['id'].' set to '.$to,'?p=wd&s='.urlencode($_GET['s']??'Open'));}
 $pdo->rollBack();redir('Already finalized','?p=wd');}
top('Withdrawals','wd');$st=$_GET['s']??'Open';$LB=['Pending'=>'Pending','Processing'=>'Processing','Verifying'=>'Withdraw Verify','Paid'=>'Paid','Rejected'=>'Rejected'];
$base='SELECT w.*,u.avatar,u.photo,u.level,u.email_ok,(SELECT COUNT(*)+1 FROM te_users x WHERE x.banned=0 AND '.dsql('x.').' AND x.total>u.total) rk FROM te_wd w LEFT JOIN te_users u ON u.tg_id=w.tg_id ';
$rows=isset($LB[$st])?q($base.'WHERE w.status=? ORDER BY w.id DESC LIMIT 100',[$st]):($st==='All'?q($base.'ORDER BY w.id DESC LIMIT 100'):q($base."WHERE w.status IN ('Pending','Processing','Verifying') ORDER BY w.id ASC LIMIT 100"));
echo '<div class="f" style="margin-bottom:14px">';foreach(['Open'=>'Open']+$LB+['All'=>'All'] as $k=>$lb)echo '<a class="b '.($k===$st?'':'gh').'" href="?p=wd&s='.$k.'">'.$lb.'</a>';
echo '</div><div class="c sc"><table><tr><th>#</th><th>User</th><th>Rank</th><th>Wallet (TON network)</th><th>Points</th><th>USDT</th><th>Status</th><th>Action</th></tr>';
foreach($rows as $r){$open=in_array($r['status'],['Pending','Processing','Verifying'],true);
 echo '<tr><td>'.$r['id'].'</td><td>'.ulink($r,38).'</td><td><b>#'.(int)$r['rk'].'</b><br><small class="mu">Lv '.(int)$r['level'].'</small></td><td style="max-width:230px;word-break:break-all"><small>'.e($r['number']).'</small>'.($r['memo']?'<br><small>Memo: '.e($r['memo']).'</small>':'').'</td>
 <td>'.number_format((float)$r['amount']).'</td><td>'.(rtrim(rtrim(number_format((float)$r['ton'],6),'0'),'.')?:'0').'</td><td><span class="tag '.($r['status']==='Paid'?'on':($r['status']==='Rejected'?'off':'')).'">'.e($LB[$r['status']]??$r['status']).'</span><br><small class="mu">'.e($r['created_at']).'</small></td><td>';
 if($open)echo '<form method="post" class="f">'.$tok.'<input type="hidden" name="do" value="wd"><input type="hidden" name="id" value="'.$r['id'].'"><input name="tx" placeholder="TX hash (for Paid)" size="14"><input name="note" placeholder="Note" size="10"><button name="act" value="p" class="gh">Processing</button><button name="act" value="v" class="gh">Verify</button><button name="act" value="ok">Paid</button><button name="act" value="no" class="bad" onclick="return confirm(\'Reject and refund?\')">Reject</button></form>';
 else echo '<small>'.e(trim($r['tx'].' '.$r['note'])).'</small>';
 echo '</td></tr>';}
echo '</table></div>';bot();
