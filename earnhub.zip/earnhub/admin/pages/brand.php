<?php
function brand_files(string $slot): array{return ['logo'=>[['logo.png',256]],'favicon'=>[['favicon.png',64]],'admin_logo'=>[['admin-logo.png',128]],'admin_icon'=>[['admin-icon-192.png',192],['admin-icon-512.png',512],['admin-icon-180.png',180]],'push_badge'=>[['push-badge.png',96]]][$slot];}
function brand_set(string $slot,string $v){q('INSERT INTO te_settings (k,v) VALUES (?,?) ON DUPLICATE KEY UPDATE v=VALUES(v)',['brand_'.$slot,$v]);}
function brand_save(string $slot,string $tmp): ?string{
 if(!function_exists('imagecreatefromstring'))return 'Image processing (GD) is not available on this server';
 $inf=@getimagesize($tmp);if(!$inf||!in_array($inf[2],[IMAGETYPE_PNG,IMAGETYPE_JPEG,IMAGETYPE_GIF,IMAGETYPE_WEBP],true))return 'Please upload a PNG, JPG, GIF or WEBP image';
 if($inf[0]>4000||$inf[1]>4000||$inf[0]<32||$inf[1]<32)return 'The image must be between 32 and 4000 pixels';
 $src=@imagecreatefromstring((string)file_get_contents($tmp));if(!$src)return 'Could not read that image';
 $w=imagesx($src);$h=imagesy($src);$s=min($w,$h);$sx=(int)(($w-$s)/2);$sy=(int)(($h-$s)/2);
 $dir=__DIR__.'/../../uploads/brand';if(!is_dir($dir))@mkdir($dir,0755,true);if(!is_dir($dir)||!is_writable($dir))return 'The uploads/brand folder is not writable (set its permission to 755)';
 foreach(brand_files($slot) as [$name,$px]){$o=imagecreatetruecolor($px,$px);
  if($slot==='admin_icon')imagefill($o,0,0,imagecolorallocate($o,11,18,32));else{imagealphablending($o,false);imagesavealpha($o,true);imagefill($o,0,0,imagecolorallocatealpha($o,0,0,0,127));}
  imagecopyresampled($o,$src,0,0,$sx,$sy,$px,$px,$s,$s);if(!@imagepng($o,$dir.'/'.$name,6))return 'Could not save the image';}
 brand_set($slot,(string)time());return null;}
function brand_reset(string $slot){foreach(brand_files($slot) as [$name])@unlink(__DIR__.'/../../uploads/brand/'.$name);brand_set($slot,'');}
$SL=['logo'=>['App logo','Shown in the header of the user app. Square, at least 256 x 256. Transparent PNG works best.','logo'],'favicon'=>['Favicon','The small icon in the browser tab and bookmarks. Square, at least 64 x 64.','favicon'],
 'admin_logo'=>['Admin panel logo','Shown in the sidebar and on the sign-in page.','admin_logo'],'admin_icon'=>['Admin app icon','Used when the admin panel is installed as an app or added to the home screen. Square, at least 512 x 512.','a512'],
 'push_badge'=>['Push notification icon','The small icon in the phone status bar for admin push notifications. Android shows only its shape, so use a simple <b>white shape on a transparent background</b> (PNG). Square, at least 96 x 96.','pbadge']];
if($P){$sl=(string)($_POST['slot']??'');if(!isset($SL[$sl]))redir('Unknown image','?p=brand');$d=$_POST['do']??'';
 if($d==='brand_up'){$f=$_FILES['img']??null;if(!$f||$f['error']!==UPLOAD_ERR_OK)redir('Choose an image first (max 2 MB)','?p=brand');if($f['size']>2097152)redir('That image is too large (max 2 MB)','?p=brand');redir(brand_save($sl,$f['tmp_name'])?:'Image updated','?p=brand');}
 if($d==='brand_reset'){brand_reset($sl);redir('Reset to the default image','?p=brand');}
 redir('Nothing changed','?p=brand');}
top('Branding','brand');
echo '<p class="mu" style="margin-bottom:12px">Upload your own images. Click "Reset to default" to go back to the original image. Changes may take a moment to appear in Telegram, so reopen the app after saving.</p><div class="bc">';
foreach($SL as $k=>[$t,$ds,$pv]){$custom=setting('brand_'.$k)!=='';
 echo '<div class="c"><h2>'.$t.' '.($custom?'<span class="tag on">Custom</span>':'<span class="tag gy">Default</span>').'</h2><p class="mu">'.$ds.'</p><div class="bp"><img src="../'.e(brand($pv)).'" alt="Current '.e($t).'"'.($k==='push_badge'?' style="background:#0B1220;border-radius:12px;padding:8px"':'').'><small class="mu">Current image</small></div>
  <form method="post" enctype="multipart/form-data" class="f">'.$tok.'<input type="hidden" name="slot" value="'.$k.'"><input type="hidden" name="do" value="brand_up"><input type="file" name="img" accept="image/png,image/jpeg,image/gif,image/webp" required><button>Upload</button></form>
  <form method="post" style="margin-top:8px" onsubmit="return confirm(\'Reset this image to the default?\')">'.$tok.'<input type="hidden" name="slot" value="'.$k.'"><input type="hidden" name="do" value="brand_reset"><button class="gh"'.($custom?'':' disabled style="opacity:.5;cursor:default"').'>Reset to default</button></form></div>';}
echo '</div>';bot();
