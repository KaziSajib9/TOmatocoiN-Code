<?php if($P&&($_POST['do']??'')==='notice'){$to=(int)preg_replace('/\D/','',(string)($_POST['to']??''));$t=mb_substr(trim((string)$_POST['title']),0,120);$b=mb_substr(trim((string)$_POST['body']),0,2000);
 $u=$to?q('SELECT tg_id FROM te_users WHERE tg_id=?',[$to])->fetch():null;if(!$u||$t===''||$b==='')redir('Enter a valid Telegram ID of an existing user, a title and a message','?p=notices');
 q('INSERT INTO te_notices (tg_id,title,body) VALUES (?,?,?)',[$to,$t,$b]);$m='Notice sent to '.$to;
 if(isset($_POST['tgdm'])){$ok=tg('sendMessage',['chat_id'=>$to,'text'=>$t."\n\n".$b]);$m.=$ok?' (also delivered on Telegram)':' (Telegram message could not be delivered, the user has not started the bot)';}
 redir($m,'?p=notices');}
top('Notices','notices');
echo '<div class="c"><h2>Send a notice to one user</h2><p class="mu">The user sees it under the bell icon in the app. Open a user\'s page to send from there.</p><form method="post" class="fm" style="margin-top:10px">'.$tok.'<input type="hidden" name="do" value="notice">
 <label>Telegram ID<input name="to" value="'.e($_GET['to']??'').'" required inputmode="numeric"></label><label>Title<input name="title" required maxlength="120"></label><label>Message<textarea name="body" rows="4" required maxlength="2000"></textarea></label>
 <label class="ck"><input type="checkbox" name="tgdm" checked> Also send as a Telegram message</label><button>Send notice</button></form></div>';
echo '<div class="c sc"><h2>Recent notices</h2><table><tr><th>User</th><th>Title</th><th>Message</th><th>Sent</th><th>Read</th></tr>';
foreach(q('SELECT n.*,u.name,u.avatar,u.photo FROM te_notices n LEFT JOIN te_users u ON u.tg_id=n.tg_id ORDER BY n.id DESC LIMIT 40') as $r)
 echo '<tr><td>'.ulink($r,30,false).'</td><td><b>'.e($r['title']).'</b></td><td style="max-width:320px"><small>'.e(mb_substr($r['body'],0,160)).'</small></td><td><small>'.e($r['created_at']).'</small></td><td>'.($r['read_at']?'<span class="tag on">Read</span>':'<span class="tag">Unread</span>').'</td></tr>';
echo '</table></div>';bot();
