<?php require __DIR__.'/inc.php'; if(empty($_SESSION['a'])) out(['error'=>'auth'],401);
$w=q('SELECT w.id,w.name,w.amount,w.ton FROM te_wd w ORDER BY w.id DESC LIMIT 1')->fetch();
out(['live'=>live_count(),'users'=>(int)q('SELECT COUNT(*) FROM te_users WHERE is_demo=0')->fetchColumn(),'wd_max'=>$w?(int)$w['id']:0,'open'=>(int)q("SELECT COUNT(*) FROM te_wd WHERE status IN ('Pending','Processing','Verifying')")->fetchColumn(),
 'help_open'=>(int)q("SELECT COUNT(*) FROM te_tickets WHERE status='Open'")->fetchColumn(),'tk_max'=>(int)q("SELECT COALESCE(MAX(id),0) FROM te_tmsg WHERE sender='user'")->fetchColumn(),
 'dv_n'=>(int)q('SELECT (SELECT COUNT(*) FROM te_devs)+(SELECT COUNT(*) FROM te_dev_dep)+(SELECT COUNT(*) FROM te_camps)+(SELECT COUNT(*) FROM te_conv WHERE status=\'Flagged\')')->fetchColumn(),
 'dv_pen'=>(int)q("SELECT (SELECT COUNT(*) FROM te_dev_dep WHERE status='Pending')+(SELECT COUNT(*) FROM te_camps WHERE status='Pending')")->fetchColumn(),
 'last'=>$w?$w['name'].' requested '.number_format((float)$w['amount']).' pts ('.(float)$w['ton'].' USDT)':'']);
