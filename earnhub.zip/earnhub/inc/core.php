<?php
declare(strict_types=1);
date_default_timezone_set('Asia/Dhaka');
$cfg=require __DIR__.'/../config.php';
function db(): PDO{global $cfg;static $p;if(!$p){$p=new PDO("mysql:host={$cfg['h']};dbname={$cfg['n']};charset=utf8mb4",$cfg['u'],$cfg['p'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);$p->exec("SET time_zone='+06:00'");}return $p;}
function q(string $s,array $a=[]): PDOStatement{$t=db()->prepare($s);$t->execute($a);return $t;}
function setting(string $k,string $d=''): string{static $c;$c=$c??q('SELECT k,v FROM te_settings')->fetchAll(PDO::FETCH_KEY_PAIR);return $c[$k]??$d;}
function out(array $d,int $c=200){http_response_code($c);header('Content-Type: application/json');echo json_encode($d,JSON_UNESCAPED_UNICODE);exit;}
function tg(string $m,array $p=[]){global $cfg;$c=curl_init("https://api.telegram.org/bot{$cfg['t']}/$m");curl_setopt_array($c,[CURLOPT_RETURNTRANSFER=>1,CURLOPT_POSTFIELDS=>$p,CURLOPT_TIMEOUT=>8]);$r=curl_exec($c);return json_decode((string)$r,true)['result']??null;}
// Verifies Telegram's signature on initData, so a user id can't be faked.
function me(): array{global $cfg;
 parse_str($_SERVER['HTTP_X_INIT_DATA']??'',$f);$h=(string)($f['hash']??'');unset($f['hash']);ksort($f);
 $chk=implode("\n",array_map(fn($k,$v)=>"$k=$v",array_keys($f),$f));
 if(!$h||!hash_equals(hash_hmac('sha256',$chk,hash_hmac('sha256',$cfg['t'],'WebAppData',true)),$h)||time()-(int)($f['auth_date']??0)>86400) out(['error'=>'Please open this app from Telegram'],401);
 $t=json_decode((string)($f['user']??''),true);if(!is_array($t)||!isset($t['id'])) out(['error'=>'Please open this app from Telegram'],401);
 $id=(int)$t['id'];$name=(string)($t['username']??trim(($t['first_name']??'').' '.($t['last_name']??'')));if($name==='')$name='User';
 $ph=(string)($t['photo_url']??'');if(strpos($ph,'https://')!==0)$ph='';
 $r=(string)($f['start_param']??'');$ref=preg_match('/^\d{5,15}$/',$r)&&(int)$r!==$id?(int)$r:null;
 $dv='';$fp='';if(preg_match('/^([a-f0-9]{32})\.([a-f0-9]{32})$/',(string)($_SERVER['HTTP_X_DEVICE']??''),$dm)){$dv=$dm[1];$fp=$dm[2];}
 $blk=0;if($ref&&$dv!==''&&q('SELECT 1 FROM te_devices WHERE tg_id=? AND dev=? LIMIT 1',[$ref,$dv])->fetchColumn()){$ref=null;$blk=1;}
 $ins=q('INSERT INTO te_users (tg_id,name,ref_by,photo) VALUES (?,?,?,?) ON DUPLICATE KEY UPDATE name=VALUES(name),photo=VALUES(photo)',[$id,$name,$ref,mb_substr($ph,0,255)]);
 q('UPDATE te_users SET last_seen=NOW() WHERE tg_id=? AND (last_seen IS NULL OR last_seen<NOW()-INTERVAL 20 SECOND)',[$id]);
 $same=0;if($dv!==''){q('INSERT INTO te_devices (tg_id,dev,fp,last_seen) VALUES (?,?,?,NOW()) ON DUPLICATE KEY UPDATE fp=VALUES(fp),last_seen=IF(last_seen IS NULL OR last_seen<NOW()-INTERVAL 60 SECOND,NOW(),last_seen)',[$id,$dv,$fp]);
  if($ins->rowCount()===1)$same=(int)q('SELECT COUNT(DISTINCT tg_id) FROM te_devices WHERE dev=? AND tg_id<>?',[$dv,$id])->fetchColumn();}
 if($ins->rowCount()===1&&$blk)q('UPDATE te_users SET ref_blocked=1 WHERE tg_id=?',[$id]);
 if($ins->rowCount()===1)notify_admin('notify_user',"New user joined\nName: $name\nTelegram ID: $id\nReferred by: ".($ref?:'none').($blk?' (referral blocked: same device)':'').($same>0?"\nSame device as $same other account(s)":'')."\nTotal users: ".q('SELECT COUNT(*) FROM te_users WHERE is_demo=0')->fetchColumn());
 if($ins->rowCount()===1){$ln=(int)setting('launch_n','0');$lp=(float)setting('launch_pts','0');
  if($ln>0&&$lp>0&&(int)q('SELECT COUNT(*) FROM te_users WHERE is_demo=0')->fetchColumn()<=$ln&&q('UPDATE te_users SET balance=balance+?,total=total+?,early=1 WHERE tg_id=? AND early=0',[$lp,$lp,$id])->rowCount()===1)
   q('INSERT INTO te_notices (tg_id,title,body) VALUES (?,?,?)',[$id,'Early member bonus','Welcome! As one of our first '.$ln.' members you received '.rtrim(rtrim(number_format($lp,2,'.',''),'0'),'.').' bonus points.']);}
 unban_expired();$u=q('SELECT * FROM te_users WHERE tg_id=?',[$id])->fetch();
 if($u['banned']){$l=$u['ban_until']?max(0,strtotime((string)$u['ban_until'])-time()):null;out(['error'=>'Your account is blocked','blocked'=>true,'reason'=>(string)$u['ban_reason'],'until'=>$u['ban_until'],'left'=>$l],403);}
 return auto_level($u);}
function credit(array $u,float $r){q('UPDATE te_users SET balance=balance+?,total=total+? WHERE tg_id=?',[$r,$r,$u['tg_id']]);$pc=(float)setting('ref_percent','0');
 if($u['ref_by']&&$pc>0){$c=round($r*$pc/100,2);if($c>0)q('UPDATE te_users SET balance=balance+?,ref_earn=ref_earn+? WHERE tg_id=?',[$c,$c,$u['ref_by']]);}}
function lvl(int $l){return q('SELECT * FROM te_levels WHERE level=?',[$l])->fetch()?:['ad_limit'=>0,'ad_reward'=>0,'upgrade_cost'=>0];}
function today(int $id){q('INSERT IGNORE INTO te_adlog (tg_id,d) VALUES (?,CURDATE())',[$id]);return q('SELECT * FROM te_adlog WHERE tg_id=? AND d=CURDATE()',[$id])->fetch();}
function ad_on(): bool{return setting('ad_on')==='1'&&setting('ag_block')!=='';}
function int_on(): bool{return setting('int_on')==='1'&&setting('int_block')!=='';}
function agt_on(): bool{return setting('ag_task_on')==='1'&&setting('ag_task_block')!=='';}
// today's daily tasks: [completed, total]
function daily(array $u,array $row): array{$lv=lvl((int)$u['level']);$d=0;$t=0;
 if(ad_on()){$t++;if((int)$row['n']>=(int)$lv['ad_limit'])$d++;}
 if(int_on()){$t++;if((int)$row['i']>=(int)lvv($lv,'int_limit','int_limit','5'))$d++;}
 if(agt_on()){$t++;if((int)$row['t']>=(int)lvv($lv,'agt_limit','ag_task_limit','5'))$d++;}
 return [$d,$t];}
// start a reward-ad session ('ad') or a daily-bonus ad session ('bonus')
function ad_start(array $u,string $kind): array{if(!ad_on())return ['error'=>'Ads are currently unavailable'];
 $id=(int)$u['tg_id'];$row=today($id);$lv=lvl((int)$u['level']);
 if($kind==='ad'){if((int)$row['n']>=(int)$lv['ad_limit'])return ['error'=>'Daily ad limit reached'];
  if(time()-(int)$row['last_at']<(int)setting('ad_cd','30'))return ['error'=>'Please wait a moment and try again'];}
 else{[$d,$t]=daily($u,$row);if($d<$t)return ['error'=>'Complete all daily tasks first'];
  if($u['last_bonus']===date('Y-m-d'))return ['error'=>'Today\'s bonus is already claimed'];if(lvv($lv,'bonus','daily_bonus','0')<=0)return ['error'=>'Daily bonus is currently disabled'];}
 q('UPDATE te_adlog SET started=?,pend=? WHERE tg_id=? AND d=CURDATE()',[time(),$kind,$id]);return ['ok'=>true];}
// consume a verified ad view (AdsGram callback OR client claim). Atomic: only the first caller wins.
function finish_ad(array $u): array{$id=(int)$u['tg_id'];$row=today($id);
 if((int)$row['started']<=0)return ['error'=>'Session not found, please try again'];
 if($row['pend']==='bonus'){$c=lvv(lvl((int)$u['level']),'bonus','daily_bonus','0');[$d,$t]=daily($u,$row);
  if($c<=0||$d<$t)return ['error'=>'Complete all daily tasks first'];
  if(q("UPDATE te_adlog SET started=0,pend='' WHERE tg_id=? AND d=CURDATE() AND started>0",[$id])->rowCount()!==1)return ['error'=>'Already completed'];
  if(q('UPDATE te_users SET balance=balance+?,total=total+?,last_bonus=CURDATE() WHERE tg_id=? AND (last_bonus IS NULL OR last_bonus<CURDATE())',[$c,$c,$id])->rowCount()!==1)return ['error'=>'Today\'s bonus is already claimed'];
  return ['ok'=>true,'reward'=>$c];}
 $lv=lvl((int)$u['level']);
 if(q("UPDATE te_adlog SET n=n+1,last_at=?,started=0,pend='' WHERE tg_id=? AND d=CURDATE() AND started>0 AND n<?",[time(),$id,(int)$lv['ad_limit']])->rowCount()!==1)return ['error'=>'Daily ad limit reached'];
 credit($u,(float)$lv['ad_reward']);return ['ok'=>true,'reward'=>(float)$lv['ad_reward']];}
// ---- auto-migration: safe to re-run, upgrades any earlier install ----
if(setting('sv','1')!=='23'){foreach([
 'CREATE TABLE IF NOT EXISTS te_devs (tg_id BIGINT PRIMARY KEY, company VARCHAR(80), contact VARCHAR(120), status VARCHAR(10) NOT NULL DEFAULT \'Active\', balance DECIMAL(14,4) NOT NULL DEFAULT 0, spent DECIMAL(14,4) NOT NULL DEFAULT 0, deposited DECIMAL(14,4) NOT NULL DEFAULT 0, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)',
 'CREATE TABLE IF NOT EXISTS te_dev_dep (id INT AUTO_INCREMENT PRIMARY KEY, tg_id BIGINT NOT NULL, amount DECIMAL(14,4) NOT NULL, txid VARCHAR(120) NOT NULL, note VARCHAR(200), status VARCHAR(10) NOT NULL DEFAULT \'Pending\', admin_note VARCHAR(200), created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, done_at DATETIME NULL, UNIQUE KEY u_tx (txid), KEY(tg_id), KEY(status))',
 'CREATE TABLE IF NOT EXISTS te_camps (id INT AUTO_INCREMENT PRIMARY KEY, tg_id BIGINT NOT NULL, type VARCHAR(8) NOT NULL, title VARCHAR(120) NOT NULL, url VARCHAR(500) NOT NULL, pkg VARCHAR(120) NULL, cost DECIMAL(10,4) NOT NULL, reward DECIMAL(10,2) NOT NULL, wait INT NOT NULL DEFAULT 10, daily_cap INT NOT NULL DEFAULT 0, total_cap INT NOT NULL DEFAULT 0, ckey CHAR(24) NOT NULL, pkey CHAR(16) NOT NULL, status VARCHAR(12) NOT NULL DEFAULT \'Pending\', note VARCHAR(200) NULL, task_id INT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, KEY(tg_id), KEY(status))',
 'CREATE TABLE IF NOT EXISTS te_conv (id INT AUTO_INCREMENT PRIMARY KEY, camp_id INT NOT NULL, tg_id BIGINT NOT NULL, dev_id BIGINT NOT NULL, src VARCHAR(8) NOT NULL, cost DECIMAL(10,4) NOT NULL, reward DECIMAL(10,2) NOT NULL, status VARCHAR(10) NOT NULL DEFAULT \'OK\', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, UNIQUE KEY u_cu (camp_id,tg_id), KEY(dev_id,created_at), KEY(camp_id,created_at))',
 'ALTER TABLE te_log ADD COLUMN token CHAR(16) NULL','ALTER TABLE te_tasks ADD COLUMN camp_id INT NULL','ALTER TABLE te_tasks ADD KEY idx_camp (camp_id)',
 "ALTER TABLE te_tasks ADD COLUMN verify VARCHAR(10) NOT NULL DEFAULT 'postback'","CREATE TABLE IF NOT EXISTS te_apps (tg_id BIGINT NOT NULL, task_id INT NOT NULL, proof VARCHAR(200), status VARCHAR(10) NOT NULL DEFAULT 'Pending', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(tg_id,task_id))","INSERT IGNORE INTO te_settings (k,v) VALUES ('pb_secret','".bin2hex(random_bytes(12))."')",
 'CREATE TABLE IF NOT EXISTS te_devices (tg_id BIGINT NOT NULL, dev CHAR(32) NOT NULL, fp CHAR(32) NULL, first_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP, last_seen DATETIME NULL, PRIMARY KEY(tg_id,dev), KEY idx_dev(dev), KEY idx_fp(fp))',
 'CREATE TABLE IF NOT EXISTS te_agt (tg_id BIGINT PRIMARY KEY, started INT NOT NULL DEFAULT 0)','ALTER TABLE te_users ADD COLUMN ref_blocked TINYINT(1) NOT NULL DEFAULT 0',"INSERT IGNORE INTO te_settings (k,v) VALUES ('ag_task_wait','10')",
 'ALTER TABLE te_users ADD COLUMN early TINYINT(1) NOT NULL DEFAULT 0',"INSERT IGNORE INTO te_settings (k,v) VALUES ('launch_n','0'),('launch_pts','0'),('show_paid','0')",
 'ALTER TABLE te_users ADD COLUMN is_demo TINYINT(1) NOT NULL DEFAULT 0','ALTER TABLE te_users ADD KEY idx_demo (is_demo)',"INSERT IGNORE INTO te_settings (k,v) VALUES ('demo_lb','0')",
 'ALTER TABLE te_users ADD COLUMN level INT NOT NULL DEFAULT 1','ALTER TABLE te_users ADD COLUMN last_bonus DATE NULL',
 'ALTER TABLE te_users ADD COLUMN photo VARCHAR(255) NULL',"ALTER TABLE te_users ADD COLUMN avatar VARCHAR(40) NOT NULL DEFAULT 'tg'",
 'CREATE TABLE IF NOT EXISTS te_levels (level INT PRIMARY KEY, ad_limit INT NOT NULL DEFAULT 0, ad_reward DECIMAL(10,2) NOT NULL DEFAULT 0, upgrade_cost INT NOT NULL DEFAULT 0)',
 'CREATE TABLE IF NOT EXISTS te_adlog (tg_id BIGINT, d DATE, n INT NOT NULL DEFAULT 0, last_at INT NOT NULL DEFAULT 0, started INT NOT NULL DEFAULT 0, PRIMARY KEY(tg_id,d))',
 'ALTER TABLE te_adlog ADD COLUMN t INT NOT NULL DEFAULT 0',"ALTER TABLE te_adlog ADD COLUMN pend VARCHAR(8) NOT NULL DEFAULT ''",'ALTER TABLE te_adlog ADD COLUMN i INT NOT NULL DEFAULT 0','ALTER TABLE te_adlog ADD COLUMN i_last INT NOT NULL DEFAULT 0','ALTER TABLE te_adlog ADD COLUMN i_start INT NOT NULL DEFAULT 0',
 'CREATE TABLE IF NOT EXISTS te_cb (id INT AUTO_INCREMENT PRIMARY KEY, at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, ip VARCHAR(45), qs VARCHAR(255), res VARCHAR(60))',
 'ALTER TABLE te_wd MODIFY number VARCHAR(100)','ALTER TABLE te_wd ADD COLUMN memo VARCHAR(40) NULL','ALTER TABLE te_wd ADD COLUMN ton DECIMAL(18,6) NOT NULL DEFAULT 0','ALTER TABLE te_wd ADD COLUMN tx VARCHAR(80) NULL',"ALTER TABLE te_wd MODIFY status VARCHAR(12) NOT NULL DEFAULT 'Pending'",
 'CREATE TABLE IF NOT EXISTS te_tickets (id INT AUTO_INCREMENT PRIMARY KEY, tg_id BIGINT, reason VARCHAR(60), custom VARCHAR(120) NULL, wd_id INT NULL, status VARCHAR(10) NOT NULL DEFAULT \'Open\', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP NULL, KEY(tg_id), KEY(status))',
 'CREATE TABLE IF NOT EXISTS te_tmsg (id INT AUTO_INCREMENT PRIMARY KEY, ticket_id INT, sender VARCHAR(5), body TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, KEY(ticket_id))',
 "INSERT IGNORE INTO te_settings (k,v) VALUES ('notify_help','1')",
 'ALTER TABLE te_users ADD COLUMN last_seen DATETIME NULL','ALTER TABLE te_users ADD COLUMN email VARCHAR(120) NULL','ALTER TABLE te_users ADD COLUMN email_norm VARCHAR(120) NULL','ALTER TABLE te_users ADD COLUMN email_ok TINYINT(1) NOT NULL DEFAULT 0',
 'ALTER TABLE te_users ADD COLUMN ton_addr VARCHAR(100) NULL','ALTER TABLE te_users ADD COLUMN ton_memo VARCHAR(40) NULL','ALTER TABLE te_users ADD KEY idx_total (total)','ALTER TABLE te_users ADD KEY idx_seen (last_seen)','ALTER TABLE te_users ADD KEY idx_email (email_norm)',
 'ALTER TABLE te_tasks ADD COLUMN repeat_h INT NOT NULL DEFAULT 0','ALTER TABLE te_tasks ADD COLUMN repeat_m INT NOT NULL DEFAULT 0','UPDATE te_tasks SET repeat_m=repeat_h*60,repeat_h=0 WHERE repeat_m=0 AND repeat_h>0','ALTER TABLE te_log ADD COLUMN done_at INT NOT NULL DEFAULT 0','UPDATE te_log SET done_at=UNIX_TIMESTAMP() WHERE done=1 AND done_at=0',
 'CREATE TABLE IF NOT EXISTS te_codes (tg_id BIGINT, purpose VARCHAR(8), code_hash CHAR(64), ctx VARCHAR(200), expires INT NOT NULL DEFAULT 0, tries INT NOT NULL DEFAULT 0, sent INT NOT NULL DEFAULT 0, day DATE NULL, cnt INT NOT NULL DEFAULT 0, PRIMARY KEY(tg_id,purpose))',
 'CREATE TABLE IF NOT EXISTS te_notices (id INT AUTO_INCREMENT PRIMARY KEY, tg_id BIGINT, title VARCHAR(120), body TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, read_at TIMESTAMP NULL, KEY(tg_id))',
 "INSERT IGNORE INTO te_settings (k,v) VALUES ('admin_chat',''),('notify_user','1'),('notify_wd','1'),('smtp_host',''),('smtp_port','465'),('smtp_user',''),('smtp_pass',''),('mail_from','')",
 'ALTER TABLE te_levels ADD COLUMN int_limit INT NULL','ALTER TABLE te_levels ADD COLUMN int_reward DECIMAL(10,2) NULL','ALTER TABLE te_levels ADD COLUMN agt_limit INT NULL','ALTER TABLE te_levels ADD COLUMN agt_reward DECIMAL(10,2) NULL','ALTER TABLE te_levels ADD COLUMN task_pct INT NOT NULL DEFAULT 100','ALTER TABLE te_levels ADD COLUMN bonus DECIMAL(10,2) NULL',
 'INSERT IGNORE INTO te_levels (level,ad_limit,ad_reward,upgrade_cost) VALUES (1,10,5,0),(2,20,6,1000),(3,40,7,3000)',
 'ALTER TABLE te_levels ADD COLUMN name VARCHAR(30) NULL',"UPDATE te_levels SET name='Bronze' WHERE level=1 AND name IS NULL","UPDATE te_levels SET name='Silver' WHERE level=2 AND name IS NULL","UPDATE te_levels SET name='Gold' WHERE level=3 AND name IS NULL",
 "INSERT IGNORE INTO te_levels (level,ad_limit,ad_reward,upgrade_cost,name) VALUES (4,60,8,10000,'Diamond')",
 'ALTER TABLE te_levels ADD COLUMN rank2_pts INT NULL','ALTER TABLE te_levels ADD COLUMN rank3_pts INT NULL','ALTER TABLE te_users ADD COLUMN sub TINYINT NOT NULL DEFAULT 1',
 'CREATE TABLE IF NOT EXISTS te_push (id INT AUTO_INCREMENT PRIMARY KEY, h CHAR(40) UNIQUE, endpoint TEXT, p256dh VARCHAR(120), auth VARCHAR(40), admin VARCHAR(50), ua VARCHAR(120), created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)',
 'ALTER TABLE te_users ADD COLUMN ban_until DATETIME NULL','ALTER TABLE te_users ADD COLUMN ban_reason VARCHAR(200) NULL','ALTER TABLE te_users ADD KEY idx_ban (banned,ban_until)','ALTER TABLE te_log ADD COLUMN away INT NOT NULL DEFAULT 0',
 "INSERT IGNORE INTO te_settings (k,v) VALUES ('daily_bonus','50'),('ad_on','0'),('ad_cd','30'),('ad_min','5'),('ag_block',''),('ag_pb','0'),('ag_task_on','0'),('ag_task_block',''),('ag_task_reward','10'),('ag_task_limit','5'),('int_on','0'),('int_block',''),('int_limit','5'),('int_reward','3'),('int_cd','60'),('int_min','5'),('bonus_ad','1'),('points_per_ton','1000')",
 'ALTER TABLE te_tasks MODIFY reward DECIMAL(10,2) NOT NULL DEFAULT 0','ALTER TABLE te_tasks MODIFY kind VARCHAR(12)',
 'ALTER TABLE te_camps ADD COLUMN repeat_m INT NOT NULL DEFAULT 0','ALTER TABLE te_conv DROP INDEX u_cu','ALTER TABLE te_conv ADD KEY k_cu (camp_id,tg_id)',
 'ALTER TABLE te_users ADD COLUMN home_bonus TINYINT NOT NULL DEFAULT 0',
 'ALTER TABLE te_tmsg ADD COLUMN img VARCHAR(60) NULL','ALTER TABLE te_users ADD COLUMN tgn TINYINT NOT NULL DEFAULT 1','ALTER TABLE te_log ADD COLUMN rn_at INT NOT NULL DEFAULT 0',
 'CREATE TABLE IF NOT EXISTS te_bq (id INT AUTO_INCREMENT PRIMARY KEY, tg_id BIGINT NOT NULL, txt TEXT NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, KEY(id))',
 "INSERT IGNORE INTO te_settings (k,v) VALUES ('tg_task_new','1'),('tg_task_reset','1'),('tg_task_again','1'),('help_img_on','1'),('bq_scan_at','0')",
 "UPDATE te_log SET rn_at=done_at WHERE done=1",
 "ALTER TABLE te_camps ADD COLUMN store VARCHAR(5) NOT NULL DEFAULT 'play'",'ALTER TABLE te_camps ADD COLUMN icon VARCHAR(255) NULL','ALTER TABLE te_camps ADD COLUMN vstat TINYINT NOT NULL DEFAULT 0','ALTER TABLE te_camps ADD COLUMN v_at DATETIME NULL','ALTER TABLE te_camps ADD COLUMN test TINYINT NOT NULL DEFAULT 0',
 'ALTER TABLE te_log ADD COLUMN fail_at INT NOT NULL DEFAULT 0','ALTER TABLE te_camps ADD COLUMN notified TINYINT NOT NULL DEFAULT 0',"UPDATE te_camps SET notified=1 WHERE status<>'Draft'","UPDATE te_camps SET vstat=1 WHERE type='bot' AND status IN ('Active','Paused','Finished','Pending')",'ALTER TABLE te_tasks ADD COLUMN icon VARCHAR(255) NULL','ALTER TABLE te_tasks ADD COLUMN test_only TINYINT NOT NULL DEFAULT 0',"UPDATE te_camps SET vstat=1 WHERE type='visit' AND status IN ('Active','Paused','Finished')",
 "INSERT IGNORE INTO te_settings (k,v) VALUES ('ag_secret','".bin2hex(random_bytes(12))."')"] as $s){try{db()->exec($s);}catch(Throwable $e){}}
 try{fill_ranks();}catch(Throwable $e){}
 require_once __DIR__.'/dev.php';foreach(dev_setting_defaults() as $dk=>$dv){try{q('INSERT IGNORE INTO te_settings (k,v) VALUES (?,?)',[$dk,$dv]);}catch(Throwable $e){}}
 q("INSERT INTO te_settings (k,v) VALUES ('sv','23') ON DUPLICATE KEY UPDATE v='23'");}

// ---- admin push (Telegram DM to the admin chat ids), runs after the response is sent ----
function notify_admin(string $key,string $text){if(setting($key,'1')!=='1')return;$ids=array_filter(array_map('trim',explode(',',setting('admin_chat'))));
 register_shutdown_function(function() use($ids,$text,$key){if(function_exists('fastcgi_finish_request'))@fastcgi_finish_request();
  foreach($ids as $i)tg('sendMessage',['chat_id'=>$i,'text'=>$text]);
  $T=['notify_user'=>'New user joined','notify_wd'=>'New withdrawal request','notify_help'=>'Help desk message','notify_dev'=>'Developer Programme'];$U=['notify_user'=>'?p=users','notify_wd'=>'?p=wd','notify_help'=>'?p=help','notify_dev'=>'?p=devs'];
  try{push_all($T[$key]??'Notification',$text,$U[$key]??'./');}catch(Throwable $e){}});}
// ---- email: SMTP if configured, otherwise PHP mail() ----
function send_mail(string $to,string $subject,string $body): bool{
 $host=setting('smtp_host');$user=setting('smtp_user');$from=setting('mail_from')?:($user?:'no-reply@'.preg_replace('/^www\./','',$_SERVER['HTTP_HOST']??'localhost'));
 $hdr="From: ".setting('site_name','TOmatocoiN')." <$from>\r\nMIME-Version: 1.0\r\nContent-Type: text/plain; charset=UTF-8\r\n";
 if($host==='')return @mail($to,$subject,$body,$hdr);
 $port=(int)setting('smtp_port','465');$fp=@stream_socket_client(($port===465?'ssl://':'tcp://').$host.':'.$port,$en,$es,10);if(!$fp)return false;stream_set_timeout($fp,10);
 $rd=function() use($fp){$o='';while(($l=fgets($fp,515))!==false){$o.=$l;if(strlen($l)<4||$l[3]===' ')break;}return $o;};
 $cmd=function(string $c,string $ok) use($fp,$rd){fwrite($fp,$c."\r\n");return strpos($rd(),$ok)===0;};
 $hn=$_SERVER['HTTP_HOST']??'localhost';$rd();
 if(!$cmd("EHLO $hn",'250')){fclose($fp);return false;}
 if($port!==465){if(!$cmd('STARTTLS','220')||!stream_socket_enable_crypto($fp,true,STREAM_CRYPTO_METHOD_TLS_CLIENT)){fclose($fp);return false;}$cmd("EHLO $hn",'250');}
 if($user!==''&&(!$cmd('AUTH LOGIN','334')||!$cmd(base64_encode($user),'334')||!$cmd(base64_encode(setting('smtp_pass')),'235'))){fclose($fp);return false;}
 if(!$cmd("MAIL FROM:<$from>",'250')||!$cmd("RCPT TO:<$to>",'250')||!$cmd('DATA','354')){fclose($fp);return false;}
 $b=preg_replace('/^\./m','..',str_replace(["\r\n","\r"],"\n",$body));$b=str_replace("\n","\r\n",$b);
 $ok=$cmd("Subject: =?UTF-8?B?".base64_encode($subject)."?=\r\nTo: <$to>\r\n".$hdr."\r\n".$b."\r\n.",'250');$cmd('QUIT','221');fclose($fp);return $ok;}
// ---- one-time codes (email verification, withdrawal confirmation) ----
function gmail_ok(string $e): bool{return (bool)preg_match('/^[a-z0-9._%+\-]{3,64}@(gmail|googlemail)\.com$/',$e);}
function gmail_norm(string $e): string{[$l]=explode('@',$e,2);$l=explode('+',$l,2)[0];return str_replace('.','',$l).'@gmail.com';}
function mask_mail(string $e): string{[$l,$d]=explode('@',$e,2);return mb_substr($l,0,2).'***@'.$d;}
function code_send(int $id,string $purpose,string $ctx,string $to,string $subject,string $tpl): ?string{global $cfg;
 $r=q('SELECT * FROM te_codes WHERE tg_id=? AND purpose=?',[$id,$purpose])->fetch();
 if($r&&time()-(int)$r['sent']<60)return 'Please wait a minute before requesting another code';
 $cnt=($r&&$r['day']===date('Y-m-d'))?(int)$r['cnt']:0;if($cnt>=10)return 'Daily code limit reached, try again tomorrow';
 $code=(string)random_int(100000,999999);
 if(!send_mail($to,$subject,str_replace('{code}',$code,$tpl)))return 'Could not send the email. Please try again later';
 q('REPLACE INTO te_codes (tg_id,purpose,code_hash,ctx,expires,tries,sent,day,cnt) VALUES (?,?,?,?,?,0,?,CURDATE(),?)',[$id,$purpose,hash_hmac('sha256',$code.'|'.$ctx,$cfg['t']),mb_substr($ctx,0,200),time()+600,time(),$cnt+1]);return null;}
function code_check(int $id,string $purpose,string $ctx,string $code): ?string{global $cfg;
 $r=q('SELECT * FROM te_codes WHERE tg_id=? AND purpose=?',[$id,$purpose])->fetch();
 if(!$r||(int)$r['expires']<time())return 'Code expired. Please request a new one';
 if((int)$r['tries']>=5)return 'Too many attempts. Please request a new code';
 if(!hash_equals((string)$r['code_hash'],hash_hmac('sha256',$code.'|'.$ctx,$cfg['t']))){q('UPDATE te_codes SET tries=tries+1 WHERE tg_id=? AND purpose=?',[$id,$purpose]);return 'Incorrect code, or the details were changed';}
 if(q('UPDATE te_codes SET expires=0,tries=99 WHERE tg_id=? AND purpose=? AND expires>=? AND tries<5',[$id,$purpose,time()])->rowCount()!==1)return 'Code expired. Please request a new one';return null;}

// ---- branding images: custom upload if present, otherwise the bundled default ----
function brand(string $k): string{$D=['logo'=>'assets/brand-default/logo.png','favicon'=>'assets/brand-default/favicon.png','admin_logo'=>'admin/icons/logo-default.png','a192'=>'admin/icons/icon-192.png','a512'=>'admin/icons/icon-512.png','a180'=>'admin/icons/icon-180.png','pbadge'=>'admin/icons/badge-default.png'];
 $F=['logo'=>['logo','logo.png'],'favicon'=>['favicon','favicon.png'],'admin_logo'=>['admin_logo','admin-logo.png'],'a192'=>['admin_icon','admin-icon-192.png'],'a512'=>['admin_icon','admin-icon-512.png'],'a180'=>['admin_icon','admin-icon-180.png'],'pbadge'=>['push_badge','push-badge.png']];
 [$flag,$file]=$F[$k];$v=setting('brand_'.$flag);return ($v!==''&&is_file(__DIR__.'/../uploads/brand/'.$file))?'uploads/brand/'.$file.'?v='.$v:$D[$k];}
function help_reasons(): array{return ['Withdrawal not processed','Withdrawal taking too long','Wrong wallet address submitted','Payment not received','Account or verification issue','Confirmation code not received','Ads or rewards problem','Task problem','Referral problem','Bug or technical issue','Developer: my deposit is not credited','Developer: points deposit problem','Developer: campaign not approved or stopped','Developer: installs or visits are not counted','Developer: website script check fails','Developer: app SDK or integration problem','Developer: wrong or fake action to report','Others'];}
function home_need(array $u): string{$d=(int)setting('home_min_days','0');$t=(int)setting('home_min_tasks','0');$m=[];
 if($d>0&&strtotime((string)$u['created_at'])>time()-86400*$d)$m[]='use the app for at least '.$d.' day'.($d>1?'s':'');
 if($t>0&&(int)q('SELECT COUNT(*) FROM te_log WHERE tg_id=? AND done=1',[$u['tg_id']])->fetchColumn()<$t)$m[]='complete at least '.$t.' task'.($t>1?'s':'');
 return $m?'To get this reward, first '.implode(' and ',$m).'.':'';}
function help_tips(): array{return [
 'Developer: my deposit is not credited'=>'Deposits are checked by hand. Make sure you sent USDT on the TON network to the exact address shown, and that the amount and TXID you entered are correct. Add a screenshot of the transfer.',
 'Developer: points deposit problem'=>'Points are converted at the rate shown in Deposit. Check that you have enough points and that the minimum is reached. Add a screenshot of the message you see.',
 'Developer: campaign not approved or stopped'=>'Campaigns pause when the balance is lower than the price of one action, or when the daily or total limit is reached. Add funds and press Resume. Rejected campaigns show a reason in your notices.',
 'Developer: installs or visits are not counted'=>'Members must start the task in the app and install from that task link. Check the campaign number and the public key in the Integration tab. For websites, check that the script is on the page and the page is on the same website address.',
 'Developer: website script check fails'=>'Paste the line just before the closing body tag of the exact page you entered. If your site adds scripts with JavaScript, open the test link shown in the app, wait for the green message, then check again.',
 'Developer: app SDK or integration problem'=>'Pass the Activity to TomatoCoin.init and make sure the INTERNET permission is present. Add a screenshot of the error or the Logcat lines.',
 'Developer: wrong or fake action to report'=>'You can also press Report next to an action in Reports within the dispute days. Tell us the action number.',
 'Task problem'=>'If a task is not paid, wait one or two minutes and press Check. Add a screenshot of the task.'];}
function help_img_save(string $du): ?string{if(!preg_match('#^data:image/(png|jpe?g|webp|gif);base64,([A-Za-z0-9+/=\s]+)$#',$du,$m))return null;$b=base64_decode($m[2],true);if(!$b||strlen($b)>3000000)return null;
 $i=@getimagesizefromstring($b);if(!$i||$i[0]>6000||$i[1]>6000||!function_exists('imagecreatefromstring'))return null;$im=@imagecreatefromstring($b);if(!$im)return null;$w=imagesx($im);$h=imagesy($im);$k=min(1,1280/max($w,$h));$nw=max(1,(int)($w*$k));$nh=max(1,(int)($h*$k));
 $o=imagecreatetruecolor($nw,$nh);imagefill($o,0,0,0xFFFFFF);imagecopyresampled($o,$im,0,0,0,0,$nw,$nh,$w,$h);$d=__DIR__.'/../uploads/help';if(!is_dir($d))@mkdir($d,0755,true);if(!is_dir($d)||!is_writable($d))return null;
 $n=bin2hex(random_bytes(10)).'.jpg';return @imagejpeg($o,"$d/$n",80)?$n:null;}
// ---- Telegram broadcast queue: messages are sent a few at a time so large user lists never time out ----
function tg_send(int $chat,string $text): int{global $cfg;$c=curl_init("https://api.telegram.org/bot{$cfg['t']}/sendMessage");
 curl_setopt_array($c,[CURLOPT_RETURNTRANSFER=>1,CURLOPT_TIMEOUT=>8,CURLOPT_POSTFIELDS=>['chat_id'=>$chat,'text'=>$text,'disable_web_page_preview'=>1,'reply_markup'=>json_encode(['inline_keyboard'=>[[['text'=>'Open app','web_app'=>['url'=>rtrim(setting('site_url'),'/').'/']]]]])]]);
 curl_exec($c);$code=(int)curl_getinfo($c,CURLINFO_HTTP_CODE);curl_close($c);return $code;}
function bq_all(string $text): int{if($text==='')return 0;return (int)q("INSERT INTO te_bq (tg_id,txt) SELECT tg_id,? FROM te_users WHERE banned=0 AND is_demo=0 AND tg_id>0 AND tgn=1",[$text])->rowCount();}
function bq_one(int $id,string $text): void{q('INSERT INTO te_bq (tg_id,txt) VALUES (?,?)',[$id,$text]);}
function bq_scan(): void{// repeatable tasks that became available again
 if(setting('tg_task_again','1')!=='1')return;$rows=q("SELECT l.tg_id,l.task_id,l.done_at,t.title,t.reward FROM te_log l JOIN te_tasks t ON t.id=l.task_id JOIN te_users u ON u.tg_id=l.tg_id WHERE l.done=1 AND t.active=1 AND t.test_only=0 AND t.repeat_m>0 AND (t.camp_id IS NULL OR t.camp_id=0) AND l.rn_at<>l.done_at AND l.done_at+t.repeat_m*60<=? AND u.banned=0 AND u.tgn=1 AND u.tg_id>0 LIMIT 300",[time()])->fetchAll();
 foreach($rows as $r){if(q('UPDATE te_log SET rn_at=done_at WHERE tg_id=? AND task_id=? AND rn_at<>done_at',[$r['tg_id'],$r['task_id']])->rowCount()===1)bq_one((int)$r['tg_id'],"Task available again\n\"".mb_substr((string)$r['title'],0,80)."\" can be done again now. Reward: ".rtrim(rtrim(number_format((float)$r['reward'],2,'.',''),'0'),'.')." points.");}}
function bq_drain(int $max=25,float $secs=4.0): int{try{if(!(int)q("SELECT GET_LOCK('te_bq',0)")->fetchColumn())return 0;}catch(Throwable $e){return 0;}$n=0;$t0=microtime(true);
 try{if(time()-(int)setting('bq_scan_at','0')>=60){if(function_exists('dep_scan')&&dset('dev_auto_dep')==='1'&&dset('dev_dep_addr')!=='')try{dep_scan();}catch(Throwable $e){}q("INSERT INTO te_settings (k,v) VALUES ('bq_scan_at',?) ON DUPLICATE KEY UPDATE v=VALUES(v)",[(string)time()]);bq_scan();}
  foreach(q('SELECT * FROM te_bq ORDER BY id LIMIT '.(int)$max)->fetchAll() as $r){if(microtime(true)-$t0>$secs)break;q('DELETE FROM te_bq WHERE id=?',[$r['id']]);$c=tg_send((int)$r['tg_id'],(string)$r['txt']);$n++;
   if($c===403||$c===400)q('UPDATE te_users SET tgn=0 WHERE tg_id=?',[$r['tg_id']]);usleep(40000);}}catch(Throwable $e){}
 try{q("SELECT RELEASE_LOCK('te_bq')");}catch(Throwable $e){}return $n;}
function bq_kick(): void{register_shutdown_function(function(){if(function_exists('fastcgi_finish_request'))@fastcgi_finish_request();bq_drain();});}
// per-level value: the level's own setting if filled in, otherwise the global default
function lvv(array $lv,string $col,string $set,string $def='0'): float{return ($lv[$col]??null)!==null&&$lv[$col]!==''?(float)$lv[$col]:(float)setting($set,$def);}

// ---- temporary blocks expire automatically ----
function unban_expired(){q('UPDATE te_users SET banned=0,ban_until=NULL,ban_reason=NULL WHERE banned=1 AND ban_until IS NOT NULL AND ban_until<=NOW()');}
function lv_name(array $row,int $l): string{return ($row['name']??'')!==''?(string)$row['name']:['Bronze','Silver','Gold','Diamond'][min(max($l,1),4)-1];}
// ---- levels upgrade automatically from total earned points (never downgrades) ----
function auto_level(array $u): array{$tot=(float)$u['total'];$r=q('SELECT * FROM te_levels WHERE upgrade_cost<=? ORDER BY level DESC LIMIT 1',[$tot])->fetch();if(!$r)return $u;
 $L=(int)$r['level'];$sub=($r['rank3_pts']!==null&&$tot>=(float)$r['rank3_pts'])?3:(($r['rank2_pts']!==null&&$tot>=(float)$r['rank2_pts'])?2:1);$cl=(int)$u['level'];$cs=(int)($u['sub']??1);
 if($L>$cl||($L===$cl&&$sub>$cs)){if(q('UPDATE te_users SET level=?,sub=? WHERE tg_id=? AND (level<? OR (level=? AND sub<?))',[$L,$sub,$u['tg_id'],$L,$L,$sub])->rowCount()===1){$u['level']=$L;$u['sub']=$sub;
  q('INSERT INTO te_notices (tg_id,title,body) VALUES (?,?,?)',[$u['tg_id'],$L>$cl?'Level up!':'Rank up!','Congratulations! You reached '.lv_name($r,$L).' '.$sub.'. '.($L>$cl?'Your rewards and daily limits have been upgraded.':'Keep earning to reach the next rank.')]);}}
 return $u;}
// default rank thresholds for levels that do not have them yet: split the distance to the next level in three
function fill_ranks(){$L=q('SELECT level,upgrade_cost,rank2_pts,rank3_pts FROM te_levels ORDER BY level')->fetchAll();
 foreach($L as $i=>$r){if($r['rank2_pts']!==null&&$r['rank3_pts']!==null)continue;$a=(float)$r['upgrade_cost'];$b=isset($L[$i+1])?(float)$L[$i+1]['upgrade_cost']:$a+max(3000,$a*0.5);$st=($b-$a)/3;
  q('UPDATE te_levels SET rank2_pts=?,rank3_pts=? WHERE level=?',[(int)round($a+$st),(int)round($a+2*$st),$r['level']]);}}
function asset(string $p): string{return $p.'?v='.(int)@filemtime(__DIR__.'/../'.$p);}

// ================= Web Push (VAPID + aes128gcm, RFC 8291/8292), no external library =================
function b64u(string $s): string{return rtrim(strtr(base64_encode($s),'+/','-_'),'=');}
function b64d(string $s): string{return (string)base64_decode(strtr($s,'-_','+/').str_repeat('=',(4-strlen($s)%4)%4));}
function ec_pub_raw($key): string{$d=openssl_pkey_get_details($key);return "\x04".str_pad($d['ec']['x'],32,"\0",STR_PAD_LEFT).str_pad($d['ec']['y'],32,"\0",STR_PAD_LEFT);}
function push_vapid(): ?array{$p=setting('vapid_priv');$u=setting('vapid_pub');if($p!==''&&$u!=='')return [$p,$u];
 if(!function_exists('openssl_pkey_new'))return null;$k=@openssl_pkey_new(['private_key_type'=>OPENSSL_KEYTYPE_EC,'curve_name'=>'prime256v1']);if(!$k)return null;
 openssl_pkey_export($k,$pem);$pub=b64u(ec_pub_raw($k));q('INSERT INTO te_settings (k,v) VALUES (?,?),(?,?) ON DUPLICATE KEY UPDATE v=VALUES(v)',['vapid_priv',$pem,'vapid_pub',$pub]);return [$pem,$pub];}
function der2raw(string $d): string{$o=2;if(ord($d[1])&0x80)$o+=ord($d[1])&0x7f;$rl=ord($d[$o+1]);$r=substr($d,$o+2,$rl);$o2=$o+2+$rl;$sl=ord($d[$o2+1]);$s=substr($d,$o2+2,$sl);
 return str_pad(ltrim($r,"\0"),32,"\0",STR_PAD_LEFT).str_pad(ltrim($s,"\0"),32,"\0",STR_PAD_LEFT);}
function vapid_jwt(string $aud,string $pem): string{$h=b64u('{"typ":"JWT","alg":"ES256"}');$p=b64u(json_encode(['aud'=>$aud,'exp'=>time()+43200,'sub'=>rtrim(setting('site_url'),'/')?:'https://example.com']));
 $k=openssl_pkey_get_private($pem);openssl_sign("$h.$p",$sig,$k,OPENSSL_ALGO_SHA256);return "$h.$p.".b64u(der2raw($sig));}
// returns [http status, detail]
function push_send(array $s,string $json): array{$v=push_vapid();if(!$v)return [0,'OpenSSL EC support is missing on this server'];
 if(!function_exists('openssl_pkey_derive')||!function_exists('hash_hkdf'))return [0,'PHP 7.3 or newer is required for push'];
 $ua=b64d((string)$s['p256dh']);$auth=b64d((string)$s['auth']);if(strlen($ua)!==65||strlen($auth)<8)return [0,'invalid subscription keys'];
 $spki=hex2bin('3059301306072a8648ce3d020106082a8648ce3d030107034200').$ua;
 $peer=@openssl_pkey_get_public("-----BEGIN PUBLIC KEY-----\n".chunk_split(base64_encode($spki),64,"\n")."-----END PUBLIC KEY-----\n");if(!$peer)return [0,'invalid subscriber key'];
 $eph=openssl_pkey_new(['private_key_type'=>OPENSSL_KEYTYPE_EC,'curve_name'=>'prime256v1']);$asPub=ec_pub_raw($eph);
 $secret=openssl_pkey_derive($peer,$eph);if($secret===false||$secret==='')return [0,'key agreement failed'];
 $salt=random_bytes(16);$ikm=hash_hkdf('sha256',$secret,32,"WebPush: info\0".$ua.$asPub,$auth);
 $cek=hash_hkdf('sha256',$ikm,16,"Content-Encoding: aes128gcm\0",$salt);$nonce=hash_hkdf('sha256',$ikm,12,"Content-Encoding: nonce\0",$salt);
 $tag='';$ct=openssl_encrypt($json."\x02",'aes-128-gcm',$cek,OPENSSL_RAW_DATA,$nonce,$tag,'',16);if($ct===false)return [0,'encryption failed'];
 $body=$salt.pack('N',4096).chr(65).$asPub.$ct.$tag;$u=parse_url((string)$s['endpoint']);$aud=$u['scheme'].'://'.$u['host'].(isset($u['port'])?':'.$u['port']:'');
 $c=curl_init((string)$s['endpoint']);curl_setopt_array($c,[CURLOPT_POST=>1,CURLOPT_POSTFIELDS=>$body,CURLOPT_RETURNTRANSFER=>1,CURLOPT_TIMEOUT=>10,
  CURLOPT_HTTPHEADER=>['Content-Encoding: aes128gcm','Content-Type: application/octet-stream','TTL: 86400','Urgency: high','Authorization: vapid t='.vapid_jwt($aud,$v[0]).', k='.$v[1]]]);
 $r=curl_exec($c);$code=(int)curl_getinfo($c,CURLINFO_HTTP_CODE);$err=curl_error($c);curl_close($c);return [$code,$err?:substr((string)$r,0,120)];}
function push_all(string $title,string $body,string $url): array{$subs=q('SELECT * FROM te_push')->fetchAll();if(!$subs)return [0,[]];
 $j=json_encode(['title'=>$title,'body'=>mb_substr($body,0,400),'url'=>$url,'icon'=>'../'.brand('a192'),'badge'=>'../'.brand('pbadge')],JSON_UNESCAPED_UNICODE);$ok=0;$bad=[];
 foreach($subs as $s){[$c,$e]=push_send($s,$j);if($c>=200&&$c<300)$ok++;else{$bad[]=$c.' '.$e;if($c===404||$c===410)q('DELETE FROM te_push WHERE id=?',[$s['id']]);}}return [$ok,$bad];}

// ---- demo / test accounts (admin only; negative ids never clash with Telegram ids) ----
function dsql(string $a=''): string{return setting('demo_lb','0')==='1'?'1=1':$a.'is_demo=0';}
function new_demo_id(): int{$m=(int)q('SELECT COALESCE(MIN(tg_id),0) FROM te_users WHERE tg_id<0')->fetchColumn();return min($m,-1000000)-1;}
function level_for_total(float $tot): array{$r=q('SELECT * FROM te_levels WHERE upgrade_cost<=? ORDER BY level DESC LIMIT 1',[$tot])->fetch();if(!$r)return [1,1];
 $sub=($r['rank3_pts']!==null&&$tot>=(float)$r['rank3_pts'])?3:(($r['rank2_pts']!==null&&$tot>=(float)$r['rank2_pts'])?2:1);return [(int)$r['level'],$sub];}

require_once __DIR__.'/dev.php';
