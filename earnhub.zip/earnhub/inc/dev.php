<?php // Developer Programme: advertisers pay per verified app install or website visit; users earn points.
function dev_setting_defaults(): array{return ['dev_on'=>'1','dev_min_app'=>'0.10','dev_min_visit'=>'0.10','dev_min_channel'=>'0.05','dev_min_bot'=>'0.05','dev_share'=>'50','dev_auto_approve'=>'0','dev_dep_addr'=>'','dev_dep_net'=>'USDT (TON network)','dev_min_dep'=>'10','dev_max_camps'=>'10','dev_min_install_sec'=>'20','dev_dispute_days'=>'7','notify_dev'=>'1','dev_visit_base_sec'=>'10','dev_min_repeat'=>'30','dev_auto_dep'=>'0','dev_tonapi_key'=>'','dev_usdt_master'=>'EQCxE6mUtQJKFnGfaROTKOt1lZbDiiX1kCixRv7Nw2Id_sDs','dev_pts_dep'=>'1','dev_pts_rate'=>'100','dev_pts_min'=>'1','dev_pts_max'=>'0','dev_chan_need_admin'=>'1','dev_fail_wait'=>'20','dev_sdk_repo'=>'','dev_sdk_tag'=>'v1.0.0'];}
function camp_reward(float $cost): float{return round($cost*(float)setting('points_per_ton','0')*(float)setting('dev_share','50')/100,2);}
function camp_types(): array{return ['app'=>'App install','visit'=>'Website visit','channel'=>'Telegram channel','bot'=>'Telegram bot / Mini App'];}
function camp_label(string $t): string{return camp_types()[$t]??$t;}
// Keeps the user-facing task row in step with the campaign (Active = visible task, anything else = hidden).
function camp_sync(int $cid): void{$c=q('SELECT * FROM te_camps WHERE id=?',[$cid])->fetch();if(!$c)return;
 $kind=['app'=>'app','visit'=>'link','channel'=>'channel','bot'=>'bot'][$c['type']]??'link';$chat=$c['type']==='channel'?'@'.substr((string)parse_url((string)$c['url'],PHP_URL_PATH),1):'';
 if($c['status']==='Deleted'){q('DELETE FROM te_log WHERE task_id IN (SELECT id FROM te_tasks WHERE camp_id=?)',[$cid]);q('DELETE FROM te_tasks WHERE camp_id=?',[$cid]);q('UPDATE te_camps SET task_id=NULL WHERE id=?',[$cid]);return;}$live=$c['status']==='Active';if($live&&(int)$c['test']){q('UPDATE te_camps SET test=0 WHERE id=?',[$cid]);$c['test']=0;}
 $test=(!$live&&(int)$c['test']&&in_array($c['status'],['Pending','Paused'],true));$act=($live||$test)?1:0;$to=$test?1:0;$ti=($test?'[TEST] ':'').$c['title'];
 $t=q('SELECT id FROM te_tasks WHERE camp_id=?',[$cid])->fetch();
 if($t){q("UPDATE te_tasks SET title=?,kind=?,url=?,chat=?,reward=?,wait=?,repeat_m=?,verify='conv',active=?,icon=?,test_only=? WHERE id=?",[$ti,$kind,$c['url'],$chat,$c['reward'],$c['wait'],$kind==='link'?(int)$c['repeat_m']:0,$act,$c['icon'],$to,$t['id']]);}
 elseif($act){q("INSERT INTO te_tasks (title,kind,url,chat,reward,wait,repeat_m,verify,camp_id,active,icon,test_only) VALUES (?,?,?,?,?,?,?,'conv',?,1,?,?)",[$ti,$kind,$c['url'],$chat,$c['reward'],$c['wait'],$kind==='link'?(int)$c['repeat_m']:0,$cid,$c['icon'],$to]);
  }
 if(!$act)q('UPDATE te_tasks SET active=0 WHERE camp_id=?',[$cid]);
 if($live&&!(int)($c['notified']??0)){q('UPDATE te_camps SET notified=1 WHERE id=?',[$cid]);if(setting('tg_task_new','1')==='1')bq_all('New task: '.mb_substr((string)$c['title'],0,80)."\nReward: ".rtrim(rtrim(number_format((float)$c['reward'],2,'.',''),'0'),'.').' points. Open the app and start earning.');}
 $tid=(int)q('SELECT id FROM te_tasks WHERE camp_id=?',[$cid])->fetchColumn();if($tid)q('UPDATE te_camps SET task_id=? WHERE id=?',[$tid,$cid]);}
function admin_ids(): array{return array_values(array_filter(array_map('trim',explode(',',setting('admin_chat')))));}
function is_admin_tg(int $id): bool{return in_array((string)$id,admin_ids(),true);}
// ---- campaign icons (stored on this server, resized to 128x128 PNG) ----
function camp_icon_dir(): string{return __DIR__.'/../uploads/camps';}
function camp_icon_save(string $bin): ?string{
 if(strlen($bin)<100||strlen($bin)>2000000)return null;$inf=@getimagesizefromstring($bin);if(!$inf||!in_array($inf[2],[IMAGETYPE_PNG,IMAGETYPE_JPEG,IMAGETYPE_WEBP,IMAGETYPE_GIF],true)||$inf[0]>4000||$inf[1]>4000||$inf[0]<16||$inf[1]<16)return null;
 $d=camp_icon_dir();if(!is_dir($d))@mkdir($d,0755,true);if(!is_dir($d)||!is_writable($d))return null;$n=bin2hex(random_bytes(8)).'.png';
 if(function_exists('imagecreatefromstring')){$im=@imagecreatefromstring($bin);if(!$im)return null;$w=imagesx($im);$h=imagesy($im);$sq=min($w,$h);$o=imagecreatetruecolor(128,128);imagealphablending($o,false);imagesavealpha($o,true);imagefill($o,0,0,imagecolorallocatealpha($o,255,255,255,127));
  imagecopyresampled($o,$im,0,0,(int)(($w-$sq)/2),(int)(($h-$sq)/2),128,128,$sq,$sq);if(!@imagepng($o,"$d/$n"))return null;}
 else{if($inf[2]!==IMAGETYPE_PNG||strlen($bin)>300000)return null;if(@file_put_contents("$d/$n",$bin)===false)return null;}
 return 'uploads/camps/'.$n;}
function camp_icon_del(?string $p): void{if($p&&preg_match('#^uploads/camps/[a-f0-9]{16}\.png$#',$p))@unlink(__DIR__.'/../'.$p);}
function http_get(string $url,int $max=1500000,array $hdr=[]): ?string{if(!function_exists('curl_init'))return null;$c=curl_init($url);
 curl_setopt_array($c,[CURLOPT_RETURNTRANSFER=>1,CURLOPT_TIMEOUT=>10,CURLOPT_CONNECTTIMEOUT=>6,CURLOPT_FOLLOWLOCATION=>0,CURLOPT_ENCODING=>'',CURLOPT_USERAGENT=>'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36',CURLOPT_HTTPHEADER=>array_merge(['Accept-Language: en-US,en;q=0.9'],$hdr),
  CURLOPT_PROTOCOLS=>CURLPROTO_HTTPS|CURLPROTO_HTTP,CURLOPT_WRITEFUNCTION=>function($ch,$d) use(&$buf,$max){$buf.=$d;return strlen($buf)>$max?0:strlen($d);}]);$buf='';curl_exec($c);$code=(int)curl_getinfo($c,CURLINFO_HTTP_CODE);curl_close($c);return ($code>=200&&$code<300)?$buf:null;}
// Public-internet-only fetch for developer supplied links (blocks private and internal addresses).
function safe_fetch(string $url,int $hops=3): ?string{for($i=0;$i<=$hops;$i++){$p=parse_url($url);if(!$p||strtolower($p['scheme']??'')!=='https'||empty($p['host']))return null;$h=$p['host'];
  $ips=filter_var($h,FILTER_VALIDATE_IP)?[$h]:(array)@gethostbynamel($h);if(!$ips)return null;foreach($ips as $ip)if(!filter_var($ip,FILTER_VALIDATE_IP,FILTER_FLAG_NO_PRIV_RANGE|FILTER_FLAG_NO_RES_RANGE))return null;
  $c=curl_init($url);curl_setopt_array($c,[CURLOPT_RETURNTRANSFER=>1,CURLOPT_HEADER=>1,CURLOPT_TIMEOUT=>10,CURLOPT_CONNECTTIMEOUT=>6,CURLOPT_FOLLOWLOCATION=>0,CURLOPT_ENCODING=>'',CURLOPT_USERAGENT=>'TOmatocoiN-Verifier/1.0',CURLOPT_RESOLVE=>[$h.':'.($p['port']??443).':'.$ips[0]],CURLOPT_PROTOCOLS=>CURLPROTO_HTTPS]);
  $r=curl_exec($c);$code=(int)curl_getinfo($c,CURLINFO_HTTP_CODE);$hs=(int)curl_getinfo($c,CURLINFO_HEADER_SIZE);curl_close($c);if($r===false)return null;
  if($code>=300&&$code<400){if(!preg_match('/^location:\s*(\S+)/mi',substr($r,0,$hs),$m))return null;$l=$m[1];if(!preg_match('#^https?://#i',$l))$l=($p['scheme'].'://'.$h.(strpos($l,'/')===0?'':'/').$l);$url=$l;continue;}
  return ($code>=200&&$code<300)?substr($r,$hs,1500000):null;}return null;}
// Reads the app name and icon from a public Google Play page.
function play_info(string $pkg): ?array{if(!preg_match('/^[A-Za-z0-9._]{3,120}$/',$pkg))return null;$h=http_get('https://play.google.com/store/apps/details?id='.rawurlencode($pkg).'&hl=en&gl=US');if(!$h)return null;
 $t='';if(preg_match('#<meta[^>]+property=["\']og:title["\'][^>]+content=["\']([^"\']+)#i',$h,$m)||preg_match('#<meta[^>]+content=["\']([^"\']+)["\'][^>]+property=["\']og:title#i',$h,$m))$t=$m[1];elseif(preg_match('#<title>([^<]+)#i',$h,$m))$t=$m[1];
 $t=trim(preg_replace('/\s*[-\x{2013}]\s*Apps on Google Play\s*$/iu','',html_entity_decode($t,ENT_QUOTES|ENT_HTML5,'UTF-8')));
 $i='';if(preg_match('#<meta[^>]+property=["\']og:image["\'][^>]+content=["\']([^"\']+)#i',$h,$m)||preg_match('#<meta[^>]+content=["\']([^"\']+)["\'][^>]+property=["\']og:image#i',$h,$m))$i=html_entity_decode($m[1]);
 if($i===''&&preg_match('#https://play-lh\.googleusercontent\.com/[A-Za-z0-9_\-=%./]+#',$h,$m))$i=$m[0];
 if($t===''||stripos($t,'not found')!==false)return null;return ['title'=>mb_substr($t,0,120),'icon'=>$i];}
function play_pkg(string $s): string{$s=trim($s);if(preg_match('#[?&]id=([A-Za-z0-9._]{3,120})#',$s,$m))return $m[1];return preg_match('/^[A-Za-z][A-Za-z0-9_]*(\.[A-Za-z0-9_]+)+$/',$s)?$s:'';}
// Downloads a Play icon (only from Google image hosts) and stores a local copy.
function play_icon_local(string $u): ?string{$h=strtolower((string)parse_url($u,PHP_URL_HOST));if(!preg_match('/(^|\.)googleusercontent\.com$/',$h)||strpos($u,'https://')!==0)return null;$b=http_get($u,1500000);return $b?camp_icon_save($b):null;}
function camp_vcode(int $cid): string{return substr(hash_hmac('sha256','v'.$cid,setting('ag_secret','x').setting('vapid_pub','')),0,10);}
// Checks that the tracking script is on the campaign page.
function camp_check_script(array $c): array{$id=(int)$c['id'];$h=safe_fetch((string)$c['url']);
 if($h!==null&&preg_match('#<script[^>]+track\.js[^>]*>#i',$h,$m)&&preg_match('#data-campaign\s*=\s*["\']?'.$id.'(?![0-9])#',$m[0])){return [true,'found'];}
 if($h!==null&&preg_match('#track\.js#i',$h)&&preg_match('#data-campaign\s*=\s*["\']?'.$id.'(?![0-9])#',$h))return [true,'found'];
 return [false,$h===null?'We could not open your page. Check that the link works and is public.':'The script was not found on that page.'];}
// URL the user is sent to. Placeholders {uid} {token} {cid} {tid} are replaced; campaign links get tracking parameters added automatically.
function task_url(array $t,int $uid,string $tok): string{$u=(string)$t['url'];$cid=(int)($t['camp_id']??0);$has=strpos($u,'{')!==false;
 if($cid>0&&($t['kind']??'')==='channel')return $u;
 if($cid>0&&($t['kind']??'')==='bot'){$pl='tc_'.$uid.'_'.$tok.'_'.$cid;$p=parse_url($u);$seg=count(array_filter(explode('/',(string)($p['path']??'')),'strlen'));if(stripos((string)($p['query']??''),'start')!==false)return $u;return $u.(isset($p['query'])?'&':'?').($seg>=2?'startapp=':'start=').$pl;}
 $u=str_replace(['{uid}','{tid}','{token}','{cid}'],[(string)$uid,(string)$t['id'],$tok,(string)$cid],$u);
 if($cid>0&&!$has){$p='eh_uid='.$uid.'&eh_t='.$tok.'&eh_c='.$cid;
  if(preg_match('#^https://play\.google\.com/store/apps/details#i',$u)){if(stripos($u,'referrer=')===false)$u.=(strpos($u,'?')===false?'?':'&').'referrer='.rawurlencode($p);}
  else{$f='';$h=strpos($u,'#');if($h!==false){$f=substr($u,$h);$u=substr($u,0,$h);}$u.=(strpos($u,'?')===false?'?':'&').$p.$f;}}
 return $u;}
function camp_pause_if_needed(int $cid): void{$c=q('SELECT * FROM te_camps WHERE id=?',[$cid])->fetch();if(!$c||$c['status']!=='Active')return;
 $d=q('SELECT balance FROM te_devs WHERE tg_id=?',[$c['tg_id']])->fetch();$n=(int)q("SELECT COUNT(*) FROM te_conv WHERE camp_id=? AND status NOT IN ('Reversed','Test')",[$cid])->fetchColumn();
 if(!$d||(float)$d['balance']<(float)$c['cost']){q("UPDATE te_camps SET status='Paused',note='Out of funds. Add a deposit and resume.' WHERE id=?",[$cid]);camp_sync($cid);}
 elseif((int)$c['total_cap']>0&&$n>=(int)$c['total_cap']){q("UPDATE te_camps SET status='Finished',note='Total limit reached' WHERE id=?",[$cid]);camp_sync($cid);}}
// One verified action: charge the developer, pay the user. $secure = server-to-server call with the campaign secret key.
function conv_register(array $c,int $uid,string $src,string $tok,bool $secure): array{
 $test=((int)($c['test']??0)===1&&$c['status']!=='Active'&&is_admin_tg($uid));
 if($c['status']!=='Active'&&!$test)return ['ok'=>false,'error'=>'campaign not active'];
 if(!$test&&(int)$c['tg_id']===$uid)return ['ok'=>false,'error'=>'developers cannot earn from their own campaign'];
 $u=q('SELECT * FROM te_users WHERE tg_id=? AND banned=0'.($test?'':' AND is_demo=0'),[$uid])->fetch();if(!$u)return ['ok'=>false,'error'=>'unknown user'];
 $t=q('SELECT * FROM te_tasks WHERE camp_id=? AND active=1',[$c['id']])->fetch();if(!$t)return ['ok'=>false,'error'=>'task not available'];
 $l=q('SELECT * FROM te_log WHERE tg_id=? AND task_id=?',[$uid,$t['id']])->fetch();if(!$l||(int)$l['started']<=0||$l['done'])return ['ok'=>false,'error'=>$l&&$l['done']?'already counted':'user has not started this task'];
 if($tok!==''||!$secure){if($tok===''||!hash_equals((string)$l['token'],$tok))return ['ok'=>false,'error'=>'invalid token'];}
 if(!$test&&$c['type']!=='visit'&&(int)q("SELECT COUNT(*) FROM te_conv WHERE camp_id=? AND tg_id=? AND status<>'Test'",[$c['id'],$uid])->fetchColumn()>0)return ['ok'=>false,'error'=>'already counted'];
 $el=time()-(int)$l['started'];$min=$c['type']==='visit'?max(1,(int)$c['wait']):($c['type']==='channel'?3:max(5,(int)setting('dev_min_install_sec','20')));
 if($el<$min)return ['ok'=>false,'error'=>'too early'];
 if($c['type']==='visit'&&(int)$l['away']>0&&(int)$l['away']<(int)$c['wait']-1)return ['ok'=>false,'error'=>'visitor left too early'];
 if(!$test&&(int)$c['daily_cap']>0&&(int)q("SELECT COUNT(*) FROM te_conv WHERE camp_id=? AND created_at>=CURDATE() AND status NOT IN ('Reversed','Test')",[$c['id']])->fetchColumn()>=(int)$c['daily_cap'])return ['ok'=>false,'error'=>'daily limit reached'];
 $pdo=db();$pdo->beginTransaction();
 try{
  $d=q('SELECT * FROM te_devs WHERE tg_id=? FOR UPDATE',[$c['tg_id']])->fetch();
  if($test)$d=['status'=>'Active','balance'=>1e12];
  if(!$d||$d['status']!=='Active'||(float)$d['balance']<(float)$c['cost']){$pdo->rollBack();camp_pause_if_needed((int)$c['id']);return ['ok'=>false,'error'=>'advertiser balance too low'];}
  if(q('UPDATE te_log SET done=1,done_at=? WHERE tg_id=? AND task_id=? AND done=0',[time(),$uid,$t['id']])->rowCount()!==1){$pdo->rollBack();return ['ok'=>false,'error'=>'already counted'];}
  q('INSERT INTO te_conv (camp_id,tg_id,dev_id,src,cost,reward,status) VALUES (?,?,?,?,?,?,?)',[$c['id'],$uid,$c['tg_id'],$src,$test?0:$c['cost'],$c['reward'],$test?'Test':'OK']);
  if(!$test)q('UPDATE te_devs SET balance=balance-?,spent=spent+? WHERE tg_id=?',[$c['cost'],$c['cost'],$c['tg_id']]);
  credit($u,(float)$c['reward']);
  q('INSERT INTO te_notices (tg_id,title,body) VALUES (?,?,?)',[$uid,$c['type']==='app'?'App install confirmed':'Visit confirmed','"'.mb_substr((string)$c['title'],0,80).'" was confirmed. You received '.rtrim(rtrim(number_format((float)$c['reward'],2,'.',''),'0'),'.').' points.']);
  $pdo->commit();
 }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();return ['ok'=>false,'error'=>'already counted'];}
 if(!$test)camp_pause_if_needed((int)$c['id']);
 return ['ok'=>true,'reward'=>(float)$c['reward'],'test'=>$test];}
function dev_get(int $id){return q('SELECT * FROM te_devs WHERE tg_id=?',[$id])->fetch()?:null;}
function mask_id(int $id): string{$s=(string)$id;return str_repeat('•',max(0,strlen($s)-3)).substr($s,-3);}
function dset(string $k): string{return setting($k,dev_setting_defaults()[$k]??'');}
function dev_info(): array{return ['min_app'=>(float)dset('dev_min_app'),'min_visit'=>(float)dset('dev_min_visit'),'min_channel'=>(float)dset('dev_min_channel'),'min_bot'=>(float)dset('dev_min_bot'),'sdk_repo'=>(string)dset('dev_sdk_repo'),'sdk_tag'=>(string)(dset('dev_sdk_tag')?:'v1.0.0'),'chan_admin'=>dset('dev_chan_need_admin')==='1','bot_user'=>tg_bot_user(),'visit_base'=>max(1,(int)dset('dev_visit_base_sec')),'min_repeat'=>(int)dset('dev_min_repeat'),'auto_dep'=>dset('dev_auto_dep')==='1','usdt_master'=>dset('dev_usdt_master'),'share'=>(float)dset('dev_share'),'pts_per_usdt'=>(float)setting('points_per_ton','0'),'dep_addr'=>dset('dev_dep_addr'),'dep_net'=>dset('dev_dep_net'),'min_dep'=>(float)dset('dev_min_dep'),'auto'=>dset('dev_auto_approve')==='1','max_camps'=>(int)dset('dev_max_camps'),'site'=>rtrim(setting('site_url'),'/'),'dispute_days'=>(int)dset('dev_dispute_days'),'min_install_sec'=>(int)dset('dev_min_install_sec'),'pts_on'=>dset('dev_pts_dep')==='1','pts_rate'=>(float)dset('dev_pts_rate'),'pts_min'=>(float)dset('dev_pts_min'),'pts_max'=>(float)dset('dev_pts_max')];}
function camp_min_cost(string $type,int $wait): float{if($type==='app')return (float)dset('dev_min_app');if($type==='channel')return (float)dset('dev_min_channel');if($type==='bot')return (float)dset('dev_min_bot');$b=max(1,(int)dset('dev_visit_base_sec'));return ceil((float)dset('dev_min_visit')*max($wait,$b)/$b*10000)/10000;}
// ---- automatic USDT deposit check (TON network) ----
function ton_hash(string $a): string{$a=trim($a);if(preg_match('/^-?\d+:([0-9a-fA-F]{64})$/',$a,$m))return strtolower($m[1]);$b=base64_decode(strtr($a,'-_','+/'),true);return ($b!==false&&strlen($b)===36)?bin2hex(substr($b,2,32)):'';}
// Reads incoming USDT transfers to the admin wallet and credits developers who put their payment code (TC<id>) in the transfer comment.
function dep_scan(): array{$addr=dset('dev_dep_addr');$mh=ton_hash($addr);$jm=ton_hash(dset('dev_usdt_master'));if($mh===''||$jm==='')return ['ok'=>false,'error'=>'The wallet address or USDT token address is not valid','n'=>0];
 $hd=[];$k=trim(dset('dev_tonapi_key'));if($k!=='')$hd[]='Authorization: Bearer '.$k;
 $r=http_get('https://tonapi.io/v2/accounts/'.rawurlencode($addr).'/jettons/'.rawurlencode(dset('dev_usdt_master')).'/history?limit=60',2000000,$hd);if($r===null)return ['ok'=>false,'error'=>'Could not reach the TON network service. Try again in a minute.','n'=>0];
 $j=json_decode($r,true);if(!is_array($j)||!isset($j['events']))return ['ok'=>false,'error'=>'Unexpected answer from the TON network service','n'=>0];$n=0;
 foreach($j['events'] as $ev){$eid=(string)($ev['event_id']??'');if($eid==='')continue;foreach(($ev['actions']??[]) as $ac){if(($ac['type']??'')!=='JettonTransfer'||($ac['status']??'')!=='ok')continue;$t=$ac['JettonTransfer']??[];
   if(ton_hash((string)($t['recipient']['address']??''))!==$mh)continue;if(isset($t['jetton']['address'])&&ton_hash((string)$t['jetton']['address'])!==$jm)continue;
   if(!preg_match('/^TC(\d{5,15})$/i',trim((string)($t['comment']??'')),$m))continue;$dev=dev_get((int)$m[1]);if(!$dev)continue;
   $dec=(int)($t['jetton']['decimals']??6);$amt=round(((float)($t['amount']??0))/pow(10,$dec),4);if($amt<=0)continue;
   $pdo=db();try{$pdo->beginTransaction();q("INSERT INTO te_dev_dep (tg_id,amount,txid,note,status,admin_note,done_at) VALUES (?,?,?,?,'Approved','Verified automatically on the TON network',NOW())",[(int)$m[1],$amt,mb_substr($eid,0,120),'Automatic']);
    q('UPDATE te_devs SET balance=balance+?,deposited=deposited+? WHERE tg_id=?',[$amt,$amt,(int)$m[1]]);$pdo->commit();$n++;
    q('INSERT INTO te_notices (tg_id,title,body) VALUES (?,?,?)',[(int)$m[1],'Deposit received',rtrim(rtrim(number_format($amt,4,'.',''),'0'),'.').' USDT was added to your developer balance.']);
    foreach(q("SELECT id FROM te_camps WHERE tg_id=? AND status='Paused' AND note LIKE 'Out of funds%'",[(int)$m[1]])->fetchAll(PDO::FETCH_COLUMN) as $cid){q("UPDATE te_camps SET status='Active',note=NULL WHERE id=? AND cost<=?",[$cid,(float)q('SELECT balance FROM te_devs WHERE tg_id=?',[(int)$m[1]])->fetchColumn()]);camp_sync((int)$cid);}
   }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();}}}
 return ['ok'=>true,'n'=>$n];}
// ---- Telegram helpers for channel and bot campaigns ----
function tg_bot_user(): string{$u=setting('bot_user','');if($u!=='')return $u;$r=tg('getMe');$u=(string)($r['username']??'');if($u!==''){try{q("INSERT INTO te_settings (k,v) VALUES ('bot_user',?) ON DUPLICATE KEY UPDATE v=VALUES(v)",[$u]);}catch(Throwable $e){}}return $u;}
function tg_bot_id(): int{global $cfg;return (int)explode(':',(string)$cfg['t'])[0];}
// "@name", "name" or a t.me link -> "name" (public username) or ''
function tg_username(string $s): string{$s=trim($s);if(preg_match('#^(?:https?://)?(?:t|telegram)\.me/([A-Za-z][A-Za-z0-9_]{3,31})/?(?:\?.*)?$#i',$s,$m))return $m[1];if(preg_match('/^@?([A-Za-z][A-Za-z0-9_]{3,31})$/',$s,$m))return $m[1];return '';}
// Checks that our bot is an administrator of the channel (needed to see who joined). Returns [ok,message,title,iconPath]
function chan_check(string $name): array{$chat='@'.$name;$c=tg('getChat',['chat_id'=>$chat]);if(!$c||empty($c['id']))return [false,'We could not find this channel. Use a public channel (it has a @username).','',null];
 if(!in_array($c['type']??'',['channel','supergroup','group'],true))return [false,'This is not a channel or group. For a bot or Mini App choose "Telegram bot / Mini App".','',null];
 $m=tg('getChatMember',['chat_id'=>$chat,'user_id'=>tg_bot_id()]);$isAd=$m&&in_array($m['status']??'',['administrator','creator'],true);if(!$isAd&&dset('dev_chan_need_admin')!=='1'){$ic=null;if(!empty($c['photo']['small_file_id'])){$f=tg('getFile',['file_id'=>$c['photo']['small_file_id']]);if(!empty($f['file_path'])){global $cfg;$b=http_get('https://api.telegram.org/file/bot'.$cfg['t'].'/'.$f['file_path'],1000000);if($b)$ic=camp_icon_save($b);}}return [true,'noadmin',(string)($c['title']??$name),$ic];}if(!$isAd)return [false,'Add @'.tg_bot_user().' to your channel as an administrator (no special permissions are needed), then check again.',(string)($c['title']??''),null];
 $ic=null;if(!empty($c['photo']['small_file_id'])){$f=tg('getFile',['file_id'=>$c['photo']['small_file_id']]);if(!empty($f['file_path'])){global $cfg;$b=http_get('https://api.telegram.org/file/bot'.$cfg['t'].'/'.$f['file_path'],1000000);if($b)$ic=camp_icon_save($b);}}
 return [true,'ok',(string)($c['title']??$name),$ic];}
function dep_code(int $id): string{return 'TC'.$id;}
function pts_to_usdt(float $pts): float{$pp=(float)setting('points_per_ton','0');return $pp>0?round($pts/$pp*(float)dset('dev_pts_rate')/100,4):0.0;}
