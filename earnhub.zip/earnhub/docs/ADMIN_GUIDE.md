# Developer Programme: Owner Guide

## Turn it on
1. Admin > **Settings**: make sure *Site URL* starts with `https://` and *Points per 1 USDT* is set. Points paid to members are calculated from it.
2. Admin > **Developers > Overview**: enable the programme, set the minimum price per install and per visit, the share of the price that goes to members (the rest is your margin), your USDT deposit address (TON network), the minimum deposit and the limits.
3. Developers now see **Developer Programme** in their profile.

## Day to day
* **Deposits** tab: a developer sends USDT to your address and submits the transaction ID. Check the amount and the TXID in your wallet, then **Approve** (balance is credited) or **Reject** with a reason. Each TXID can be used once.
* **Campaigns** tab: review every new or edited campaign (title, link, what it promotes), then **Approve** or **Reject** with a reason. A campaign goes live only if the developer balance covers one action. You can pause or end any campaign.
* **Conversions** tab: every confirmed install or visit. Flagged items were reported by a developer. **Reverse** refunds the developer and removes the points from the member. **Dismiss** keeps it valid.
* **Developers** tab: suspend or reactivate a developer (suspending pauses their campaigns) and adjust balances manually with a note.
* The sidebar shows a number when deposits or campaigns wait for review, and you also get a Telegram and push notification (switch it off in the overview settings).

## Money and margin
* Developer pays **price** per verified action. Member receives `price x points per USDT x share %` points. Example: price 0.10 USDT, 1000 points per USDT, share 50% pays 50 points.
* The Overview tab shows total developer spend and the points paid to members.
* Make sure you can pay withdrawals: member points are a liability, developer balances are prepaid.

## Things to decide
* Verify deposits before approving. TON transfers are final.
* Keep a record of deposits, refunds and payouts for your own accounting. Taxes, licensing and consumer rules depend on your country and are your responsibility.
* Only approve campaigns you are comfortable promoting. Do not approve illegal, adult, scam or malware offers. Check the rules of the app stores for incentivised installs.
* Fraud: confirmations from an app or web page can be forged by a determined user who extracts the keys. The one-time token, minimum time, domain check, one action per member, device checks and the developer's Report button reduce this. For high-value campaigns ask the developer to confirm from their server (`conv.php`).

## Files
* `track.php`, `conv.php`, `track.js`: tracking endpoints and the website script.
* `sdk/`: the SDK repository, ready to upload to GitHub. `sdk/tomatocoin-sdk` is the Android library (Java, works from Kotlin). Step by step: `docs/GITHUB_GUIDE.md`.
* `sdk/flutter/tomatocoin_sdk`: Flutter plugin.
* `developers.php`: the developer guide page (also opens inside the app). Share its address with developers. `sdk.php?p=android`, `sdk.php?p=flutter` and `sdk.php?p=repo` (the whole GitHub repository) download the SDKs.

## Developer Programme: new controls
* **Back button**: fixed. The Developer Programme and the guide open as full pages with a working Back button.
* **App icon and name**: developers choose "Google Play app" (name and icon are read from the Play page automatically) or "Outside Google Play" (they type the name and upload an icon). The icon shows next to the task in the user app and in your Campaigns table. Icons are stored in `uploads/camps` (the folder must be writable). Your server needs outbound HTTPS (cURL) for the Play lookup.
* **Website campaigns**: a new website campaign starts as **Draft**. The developer adds the script line, presses "Check my website" and only then can press Publish. Existing live website campaigns are treated as verified.
* **Test it first**: in Developers > Campaigns, press "Test it first" on a Pending or Paused campaign. A [TEST] task appears only for the Telegram ID(s) in Settings > Admin notifications. Install the app (or open the page) with your admin account and tap Check. The row shows "Test passed" with the points credited. The developer is charged nothing and the test is not counted in reports. Press "Stop test" to clear it, then Approve.
* **Alerts**: Developers > Overview has "Send a test alert" (Telegram and push). Push needs the bell turned on once on each admin device (Settings). The Developers menu badge and a pop-up now also update live while the admin panel is open.

## Help desk, points deposit, Telegram alerts
* **Screenshots**: users can attach a screenshot when opening a ticket and when replying. You see it in the ticket and can click to enlarge. Turn it on or off at the bottom of the Help desk page. Images are shrunk and saved in `uploads/help` (must be writable).
* **Developer problems** are now ticket reasons, with a short tip shown to the user when they pick one.
* **Pay with points**: developers can convert their earned points into developer balance. Control it in Developers > Overview > Deposits: on/off, value of points (%), smallest payment and a daily limit. These deposits appear in Deposits as "PTS-..." and are approved automatically.
* **Telegram alerts to users** (Tasks page): new task added, task reset (new Reset button on each task), and a repeating task becoming available again. Messages are queued and sent a few at a time while users open the app. Optional: call `cron.php?key=YOUR_PB_SECRET` every minute for faster sending (the exact address is shown on the Tasks page).
* **Settings** now explain each option in plain words, and the Developers settings are grouped in four steps.

## Home Screen reward
Settings > Home Screen shortcut: set "Reward for adding it" (points, 0 = no reward). Each user gets it once, ever. Removing the shortcut and adding it again pays nothing. Telegram cannot prove to the server that the shortcut was really added, so keep the amount small.
You can also require a minimum account age (days) and a minimum number of completed tasks before the Home Screen reward can be claimed. Both are in the same Settings block.

## Website visit pricing, repeat time and automatic deposits
* **Price grows with the stay time.** Developers > Overview > "Lowest price for a website visit of the base time" (default 0.10 USDT) and "Base time" (default 10 s). A 40 s visit then costs at least 0.40 USDT. The form fills the price in automatically when the developer changes the seconds. Existing campaigns are not changed. If you installed earlier, update the lowest price to 0.10 yourself (old default was 0.01).
* **Repeat time.** A developer can let the same visitor earn again after X hours/minutes (0 = once). You set the shortest allowed repeat time (default 30 minutes). Each repeat is charged again.
* **Visitor countdown.** The tracking script shows "Stay on this page for 12 s" on the website and a green message when confirmed. Developers can hide it with `data-timer="off"`.
* **If a visitor returns early** and taps Check, they see the same "You came back after Xs..." message as normal Visit Link tasks and the task goes back to Start.
* **Automatic USDT deposits** (Developers > Overview > Deposits > "Verify USDT deposits automatically"): each developer gets a payment code like `TC<their Telegram ID>` and writes it as the transfer comment. The system reads your wallet on the TON network (through tonapi.io) and credits the balance by itself. Use "Check payments now" to test it. Manual TXID review stays as a backup. This was written from the public API description and not tested against the live network, so send a small test deposit first.

## Tracking log
Developers > Tracking log lists every call from website scripts, SDKs and developer servers with the reason it was or was not counted. The website script (v5) also shows the reason on the page itself if a visit could not be confirmed. After a visit is confirmed, the member's Check button turns into success by itself.

## Telegram Channel and Bot / Mini App campaigns, deleting campaigns
* Developers can now create four campaign types: App, Website, Telegram Channel, Telegram Bot / Mini App. Each has its own minimum price (Developers > Settings).
* **Channel:** the developer adds your bot as an admin of their public channel and taps "Check my channel" before publishing. A member is rewarded only if the bot sees them in the channel. Existing members are refused at Start. Private channels are not supported.
* **Bot / Mini App:** the developer's bot or Mini App confirms each real start using the public key (from the Mini App) or the secret key (from the bot server). The guide inside the Developer page shows ready-to-paste code. Confirmation depends on the developer's code, so use "Test it first".
* **Delete:** Developers > Campaigns > Delete (asks to confirm). The campaign disappears from members and history is kept; "Show deleted" lists them. Not tested against live Telegram.
