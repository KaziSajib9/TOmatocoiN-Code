# Publishing the SDK on GitHub (for the admin)

Goal: developers can use your SDK in two ways.

1. **Download** the zip and copy it into their project. This works from your site already (Developer Programme > Integration).
2. **Add it as a library from GitHub**, without downloading anything.
   Android (Kotlin and Java) uses **JitPack**, Flutter uses a **git dependency**.

You do this once. Later, a new version is just a new tag.

What you need: a free GitHub account. No credit card, no server.

---

## Part 1. Put the SDK on GitHub

1. Sign in at https://github.com. Press **New repository**.
2. Name it, for example `tomatocoin-sdk`. Choose **Public** (JitPack and Flutter can only read public repositories for free). Do not add a README, it already exists. Press **Create repository**.
3. Get the files. In your admin panel go to **Developers > Settings > 5. SDK on GitHub** and press **Download the ready repository (zip)**. Unzip it. You get a folder `tomatocoin-sdk-github`.
4. Upload them. Choose one way.

**Way A. With the terminal (recommended, keeps the hidden `.github` folder):**

```
cd tomatocoin-sdk-github
git init
git add .
git commit -m "First version"
git branch -M main
git remote add origin https://github.com/YOUR-NAME/tomatocoin-sdk.git
git push -u origin main
```

**Way B. In the browser:** open your new repository, press **Add file > Upload files** and drag everything inside the unzipped folder. Browsers often skip folders that start with a dot. After uploading, press **Add file > Create new file**, type `.github/workflows/release.yml` as the file name, paste the content of that file from the zip, and press **Commit**.

5. Check that you see `tomatocoin-sdk`, `flutter`, `examples`, `README.md`, `jitpack.yml` in the repository.

## Part 2. Make the first release (version)

1. In the repository press **Releases** (right side) > **Create a new release**.
2. In **Choose a tag** type `v1.0.0` and press **Create new tag**.
3. Title: `v1.0.0`. Press **Publish release**.
4. Open the **Actions** tab. A run called **Release** starts. It builds the Android library and, when it is green (about 3 minutes), adds two zip files to the release: `tomatocoin-android-sdk-v1.0.0.zip` and `tomatocoin-flutter-sdk-v1.0.0.zip`. People can download them from the Releases page.
   If it is red, open it and read the message. Send it to your developer.

## Part 3. Switch on the Android library (JitPack)

1. Open https://jitpack.io. Paste `YOUR-NAME/tomatocoin-sdk` in the box and press **Look up**.
2. Next to the tag `v1.0.0` press **Get it**. JitPack builds the library (a few minutes). A green tick means it works.
   A red icon: press **Log** and read the error.
3. The same page shows the exact line developers should add. It looks like:
   `implementation 'com.github.YOUR-NAME.tomatocoin-sdk:tomatocoin-sdk:v1.0.0'`

Flutter needs no extra step, it reads the repository directly.

## Part 4. Tell your Developer Programme

1. Admin panel > **Developers > Settings > 5. SDK on GitHub**.
2. GitHub repository: `YOUR-NAME/tomatocoin-sdk`. Release tag: `v1.0.0`. Press **Save settings**.
3. Now the Developer guide page (`developers.php`) and the Integration tab show **Option A. From GitHub** (with ready lines to copy) above the zip download.

## Releasing a new version later

1. Change the files in the repository (for example the SDK code). Commit.
2. Create a new release with a new tag such as `v1.0.1`.
3. Open JitPack once and press **Get it** for the new tag.
4. Change **Release tag** in the admin settings to `v1.0.1`.

## Good to know

* The SDK talks to your own site. Developers put your site address in `TomatoCoin.init(...)`, you do not hard-code it in the library.
* If you rename the repository, update **GitHub repository** in the admin settings.
* Android library not found by Gradle: the developer forgot to add `maven { url 'https://jitpack.io' }` to `settings.gradle`.
* Flutter cannot find the package: check the repository is **Public** and the `ref` tag exists.
* A real device or emulator is needed to try install confirmation end to end. This package was prepared without an Android SDK, so the first GitHub Actions run is your first full build. Fix any message it shows before you announce the SDK.
